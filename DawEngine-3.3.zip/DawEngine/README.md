# DawEngine – FL Mobile Edition (fixed)
Original Compose UI kept. Native C++/Oboe engine:
real low-latency stereo output, 4+ channels (tap a channel header in PLAYLIST to load audio),
per-channel volume/mute/solo, 5-band EQ, Freeverb-style stereo reverb, stereo compressor, soft limiter,
real pitch correction (YIN + pitch shifter) on channel 1. Formant shift: not implemented yet.


انظر `CHANGES.md` لتفاصيل النسخة 3.2 (مسارات ومقاطع قابلة للتحرير). اختبار المحرك على الحاسوب:
`cd app/src/main/cpp && g++ -std=c++17 -O1 -pthread -I. tests/clip_mixer_test.cpp -o /tmp/t && /tmp/t`

**3.3:** انظر `CHANGES.md`. اختبارات C++: `cd app/src/main/cpp && for t in clip_mixer_test effects_test recorder_test; do g++ -std=c++17 -O1 -pthread -I. tests/$t.cpp -o /tmp/$t && /tmp/$t; done`
