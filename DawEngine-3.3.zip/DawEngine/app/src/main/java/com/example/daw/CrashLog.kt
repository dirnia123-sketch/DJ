package com.example.daw

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.util.Date
import kotlin.coroutines.cancellation.CancellationException

/**
 * Crash diagnostics. A Java/Kotlin crash is written to a file and shown (with a Copy / Share button) on the next
 * start. On Android 11+ the system's own record of why the previous process died (native crash, ANR, out of memory,
 * killed...) is added as well, which covers crashes that no Java handler can see.
 */
object CrashLog {
    const val VERSION = "3.3"
    private var file: File? = null
    private var prefs: android.content.SharedPreferences? = null

    fun install(ctx: Context) {
        file = File(ctx.filesDir, "last_crash.txt")
        prefs = ctx.getSharedPreferences("daw_crash", Context.MODE_PRIVATE)
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { record("Uncaught exception on thread \"${t.name}\"", e) } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
    }

    fun record(where: String, e: Throwable) {
        val f = file ?: return
        val sw = StringWriter()
        e.printStackTrace(PrintWriter(sw))
        val head = "[${Date()}] v$VERSION  ${Build.MANUFACTURER} ${Build.MODEL}  Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n$where\n"
        val old = if (f.exists()) f.readText().takeLast(4000) else ""
        f.writeText(old + head + sw.toString().take(4000) + "\n\n")
    }

    /** Runs `block`; an exception is recorded and swallowed (never a CancellationException). */
    inline fun guard(where: String, block: () -> Unit) {
        try { block() }
        catch (c: CancellationException) { throw c }
        catch (e: Exception) { record(where, e); S.toast("Error: ${e.javaClass.simpleName} (see Settings > About)") }
    }

    private fun reasonName(r: Int) = when (r) {
        ApplicationExitInfo.REASON_ANR -> "ANR (app not responding)"
        ApplicationExitInfo.REASON_CRASH -> "Java crash"
        ApplicationExitInfo.REASON_CRASH_NATIVE -> "NATIVE crash (C++)"
        ApplicationExitInfo.REASON_LOW_MEMORY -> "killed: low memory"
        ApplicationExitInfo.REASON_SIGNALED -> "killed by signal"
        ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "excessive resource usage"
        ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "initialization failure"
        else -> "reason $r"
    }

    private fun exitReasonReport(ctx: Context): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val seen = prefs?.getLong("lastExitTs", 0L) ?: 0L
            val bad = setOf(ApplicationExitInfo.REASON_ANR, ApplicationExitInfo.REASON_CRASH, ApplicationExitInfo.REASON_CRASH_NATIVE,
                ApplicationExitInfo.REASON_LOW_MEMORY, ApplicationExitInfo.REASON_SIGNALED,
                ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE, ApplicationExitInfo.REASON_INITIALIZATION_FAILURE)
            val list = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 5).filter { it.timestamp > seen && it.reason in bad }
            if (list.isEmpty()) return null
            prefs?.edit()?.putLong("lastExitTs", list.maxOf { it.timestamp })?.apply()
            list.joinToString("\n") { i ->
                "[${Date(i.timestamp)}] ${reasonName(i.reason)}  status=${i.status}  ${i.description ?: ""}"
            }
        } catch (e: Throwable) { null }
    }

    /** Text to show on start-up, or null when the previous session ended normally. */
    fun pendingReport(ctx: Context): String? {
        val java = file?.takeIf { it.exists() && it.length() > 0 }?.readText()
        val sys = exitReasonReport(ctx)
        if (java == null && sys == null) return null
        return (if (sys != null) "System exit record:\n$sys\n\n" else "") + (java ?: "")
    }

    fun savedText(): String = file?.takeIf { it.exists() }?.readText() ?: ""
    fun clear() { file?.delete() }
}
