package com.example.daw

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toSize
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.tanh

private fun logN(v: Float, a: Float, b: Float) = (ln(v / a) / ln(b / a)).coerceIn(0f, 1f)
private fun expN(n: Float, a: Float, b: Float) = a * (b / a).pow(n)
private fun fmtHz(f: Float) = if (f >= 1000f) "%.2fk".format(f / 1000f) else "%.0f".format(f)
private fun fmtDb(d: Float) = "%+.1f".format(d)
private var eqSel by mutableIntStateOf(2)

@Composable
fun Panel(title: String, accent: Color, on: Boolean, bypass: Boolean, onPower: () -> Unit, onBypass: () -> Unit,
          modifier: Modifier, extra: @Composable RowScope.() -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(pd(14f))
    Box(
        modifier.fillMaxWidth().clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF2E373E), Color(0xFF1F262B))))
            .border(pd(2f), accent.copy(alpha = 0.75f), shape)
    ) {
        Canvas(Modifier.matchParentSize()) {
            val r = size.height * 0.03f.coerceAtLeast(0f) + 5f
            for (x in listOf(size.width * 0.03f, size.width * 0.97f)) {
                drawCircle(Color(0xFF59636B), r, Offset(x, size.height * 0.065f)); drawCircle(Color(0xFF262D33), r * 0.55f, Offset(x, size.height * 0.065f))
            }
        }
        Column(Modifier.fillMaxSize().padding(horizontal = pd(14f), vertical = pd(6f))) {
            Row(Modifier.fillMaxWidth().height(pd(34f)), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Color(0xFFEFF3F6), fontSize = fs(22f), fontWeight = FontWeight.Bold, maxLines = 1,
                    modifier = Modifier.padding(start = pd(14f)).weight(1f))
                extra()
                Box(Modifier.padding(start = pd(6f)).size(pd(30f)).clip(RoundedCornerShape(pd(6f))).background(C.btn).clickable(onClick = onPower),
                    contentAlignment = Alignment.Center) { Glyph(G.POWER, if (on) C.green else C.dim, Modifier.size(pd(20f))) }
                Box(Modifier.padding(start = pd(6f)).height(pd(30f)).clip(RoundedCornerShape(pd(6f))).background(Color(0xFF2B343B))
                    .clickable(onClick = onBypass).padding(horizontal = pd(10f)), contentAlignment = Alignment.Center) {
                    Text("BYPASS", color = if (bypass) C.orange else C.text, fontSize = fs(13f), fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
            content()
        }
    }
}

// ------------------------------------------------------------------ M-EQ-5 (values: 0-4 freq, 5-9 gain, 10-14 Q, 15 out)
private fun bandDb(inst: FxInst, i: Int, f: Float): Float {
    val x = ln(f / inst.v[i]); val g = inst.v[5 + i]; val q = inst.v[10 + i]
    return when (i) {
        0 -> g * 0.5f * (1f - tanh(2f * x))
        4 -> g * 0.5f * (1f + tanh(2f * x))
        else -> g * exp(-(x * x) * q * q * 0.62f)
    }
}

@Composable
private fun EqGraph(chain: Int, idx: Int, inst: FxInst, modifier: Modifier) {
    val u = LocalU.current
    val m = u * LocalDensity.current.density
    val tm = rememberTextMeasurer()
    val nodeCols = listOf(Color(0xFFE56FD0), Color(0xFFF5D04A), Color(0xFFE56FD0), Color(0xFF58E07A), Color(0xFF4FC3F7))
    fun plot(sz: Size) = Rect(46f * m, 8f * m, sz.width - 46f * m, sz.height - 24f * m)
    fun xOf(f: Float, r: Rect) = r.left + (log10(f / 20f) / 3f) * r.width
    fun yOf(g: Float, r: Rect) = r.center.y - g / 15f * r.height / 2f
    Canvas(
        modifier.clip(RoundedCornerShape(pd(8f))).background(Color(0xFF0E1215)).pointerInput(inst) {
            var active = -1
            detectDragGestures(
                onDragStart = { o ->
                    val r = plot(size.toSize()); var best = -1; var bd = 44f * m
                    for (i in 0..4) { val d = hypot(o.x - xOf(inst.v[i], r), o.y - yOf(inst.v[5 + i], r)); if (d < bd) { bd = d; best = i } }
                    active = best; if (best >= 0) eqSel = best
                },
                onDrag = { ch, _ ->
                    ch.consume()
                    if (active >= 0) {
                        val r = plot(size.toSize())
                        S.setFxValue(chain, idx, active, 20f * 10f.pow(3f * ((ch.position.x - r.left) / r.width).coerceIn(0f, 1f)))
                        S.setFxValue(chain, idx, 5 + active, (((r.center.y - ch.position.y) / (r.height / 2f)) * 15f).coerceIn(-15f, 15f))
                    }
                }
            )
        }
    ) {
        val r = plot(size)
        val ls = TextStyle(color = C.dim, fontSize = (9.5f * u).sp)
        for (j in -3..3) {   // dB grid + both axes
            val y = r.center.y - j / 3f * r.height / 2f
            drawLine(if (j == 0) Color(0xFF3A444C) else Color(0xFF1E252B), Offset(r.left, y), Offset(r.right, y), 1.2f)
            drawText(tm, "%+d".format(j * 5).replace("+0", "0"), Offset(4f * m, y - 6f * m), ls)
        }
        for ((f, lab) in listOf(20f to "20", 50f to "50", 100f to "100", 200f to "200", 500f to "500", 1000f to "1k", 2000f to "2k", 5000f to "5k", 10000f to "10k", 20000f to "20k")) {
            val x = xOf(f, r)
            drawLine(Color(0xFF1E252B), Offset(x, r.top), Offset(x, r.bottom), 1.2f)
            drawText(tm, lab, Offset(x - 8f * m, r.bottom + 4f * m), ls)
        }
        val y0 = yOf(0f, r)
        var x = r.left
        val path = Path()
        while (x <= r.right) {
            val f = 20f * 10f.pow(3f * (x - r.left) / r.width)
            var db = 0f; for (i in 0..4) db += bandDb(inst, i, f)
            val y = yOf(db.coerceIn(-15f, 15f), r)
            drawLine(if (db >= 0f) Color(0x3358E07A) else Color(0x44C9743A), Offset(x, y0), Offset(x, y), 2f)
            if (x == r.left) path.moveTo(x, y) else path.lineTo(x, y)
            x += 2f
        }
        drawPath(path, Color(0xFFF5D04A), style = Stroke(2.6f * m / 2f + 1f))
        for (i in 0..4) {
            val c = Offset(xOf(inst.v[i], r), yOf(inst.v[5 + i], r))
            val rad = (if (i == eqSel) 8.5f else 6.5f) * m
            drawCircle(Color(0xFF0E1215), rad + 2f * m, c); drawCircle(nodeCols[i], rad, c)
        }
    }
}

@Composable
private fun EqBody(chain: Int, idx: Int, inst: FxInst, scope: ColumnScope) = with(scope) {
    val spec = Fx.byId(Fx.EQ).params
    EqGraph(chain, idx, inst, Modifier.fillMaxWidth().weight(1f))
    Row(Modifier.fillMaxWidth().height(pd(86f)), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.width(pd(56f)), verticalArrangement = Arrangement.spacedBy(pd(4f))) {
            MiniBtn("BAND", false, Modifier.fillMaxWidth()) { eqSel = (eqSel + 1) % 5 }
            MiniBtn("GAIN", false, Modifier.fillMaxWidth()) { S.setFxValue(chain, idx, 5 + eqSel, 0f) }
            MiniBtn("FREQ", false, Modifier.fillMaxWidth()) { S.setFxValue(chain, idx, eqSel, spec[eqSel].def) }
        }
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly) {
            KnobCol("Freq", fmtHz(inst.v[0]), logN(inst.v[0], 20f, 500f), Color(0xFF4FA3FF)) { S.setFxValue(chain, idx, 0, expN(it, 20f, 500f)) }
            KnobCol("Gain", fmtDb(inst.v[5]), (inst.v[5] + 15f) / 30f, C.green) { S.setFxValue(chain, idx, 5, it * 30f - 15f) }
            KnobCol("Freq", fmtHz(inst.v[4]), logN(inst.v[4], 2000f, 20000f), C.green) { S.setFxValue(chain, idx, 4, expN(it, 2000f, 20000f)) }
            KnobCol("Gain", fmtDb(inst.v[9]), (inst.v[9] + 15f) / 30f, C.green) { S.setFxValue(chain, idx, 9, it * 30f - 15f) }
            val qb = if (eqSel in 1..3) eqSel else 2
            KnobCol("Q", "%.2f".format(inst.v[10 + qb]), logN(inst.v[10 + qb], 0.3f, 10f), Color(0xFF4FA3FF)) { S.setFxValue(chain, idx, 10 + qb, expN(it, 0.3f, 10f)) }
            KnobCol("Out", fmtDb(inst.v[15]), (inst.v[15] + 12f) / 24f, C.orange) { S.setFxValue(chain, idx, 15, it * 24f - 12f) }
        }
    }
}

// ------------------------------------------------------------------ generic knob panel for every other effect
private fun toNorm(sp: ParamSpec, v: Float): Float =
    if (sp.kind == KNOB_LOG) logN(v, sp.min, sp.max) else ((v - sp.min) / (sp.max - sp.min)).coerceIn(0f, 1f)
private fun fromNorm(sp: ParamSpec, n: Float): Float =
    if (sp.kind == KNOB_LOG) expN(n, sp.min, sp.max) else sp.min + n * (sp.max - sp.min)

@Composable
private fun GenericBody(chain: Int, idx: Int, inst: FxInst, scope: ColumnScope) = with(scope) {
    val specs = inst.type.params
    val knobs = specs.indices.filter { specs[it].kind <= KNOB_LOG }
    val others = specs.indices.filter { specs[it].kind >= CHOICE }
    for (row in knobs.chunked(6)) {
        Row(Modifier.fillMaxWidth().height(pd(92f)), verticalAlignment = Alignment.CenterVertically) {
            for (i in row) {
                val sp = specs[i]
                KnobCol(sp.label, sp.fmt(inst.v[i]), toNorm(sp, inst.v[i]), sp.color, Modifier.weight(1f)) { S.setFxValue(chain, idx, i, fromNorm(sp, it)) }
            }
            repeat(6 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
    if (others.isNotEmpty()) {
        Row(Modifier.fillMaxWidth().height(pd(38f)), horizontalArrangement = Arrangement.spacedBy(pd(6f)), verticalAlignment = Alignment.CenterVertically) {
            for (i in others) {
                val sp = specs[i]
                if (sp.kind == TOGGLE) MiniBtn(sp.label, inst.v[i] > 0.5f, Modifier.weight(1f)) { S.setFxValue(chain, idx, i, if (inst.v[i] > 0.5f) 0f else 1f) }
                else {
                    val n = sp.choices.size
                    val cur = inst.v[i].toInt().coerceIn(0, n - 1)
                    Stepper(sp.label + ": " + sp.choices[cur], Modifier.weight(1f).height(pd(30f)),
                        { S.setFxValue(chain, idx, i, ((cur + n - 1) % n).toFloat()) },
                        { S.setFxValue(chain, idx, i, ((cur + 1) % n).toFloat()) })
                }
            }
        }
    }
}

@Composable
private fun SmallBtn(text: String, onClick: () -> Unit) {
    Box(Modifier.size(pd(30f)).clip(RoundedCornerShape(pd(6f))).background(C.btn).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, color = C.text, fontSize = fs(16f), fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun FxPanel(chain: Int, idx: Int, inst: FxInst, count: Int) {
    val t = inst.type
    var menu by remember { mutableStateOf(false) }
    var rep by remember { mutableStateOf(false) }
    val h = if (inst.collapsed) 48f else Fx.panelHeight(t)
    Panel(t.name, t.accent, inst.on, inst.bypass, { S.toggleFxPower(chain, idx) }, { S.toggleFxBypass(chain, idx) }, Modifier.height(pd(h)),
        extra = {
            Box(Modifier.padding(start = pd(6f))) { SmallBtn(if (inst.collapsed) "+" else "-") { inst.collapsed = !inst.collapsed } }
            Box(Modifier.padding(start = pd(6f))) {
                SmallBtn("...") { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Replace with...") }, onClick = { menu = false; rep = true })
                    if (idx > 0) DropdownMenuItem(text = { Text("Move up") }, onClick = { menu = false; S.moveFx(chain, idx, -1) })
                    if (idx < count - 1) DropdownMenuItem(text = { Text("Move down") }, onClick = { menu = false; S.moveFx(chain, idx, 1) })
                    DropdownMenuItem(text = { Text("Remove effect") }, onClick = { menu = false; S.removeFx(chain, idx) })
                }
                DropdownMenu(expanded = rep, onDismissRequest = { rep = false }) {
                    Fx.all.forEach { ft ->
                        DropdownMenuItem(text = { Text(ft.name + if (ft.id == t.id) "  (current)" else "") },
                            onClick = { rep = false; S.replaceFx(chain, idx, ft.id) })
                    }
                }
            }
        }
    ) {
        if (!inst.collapsed) { if (t.id == Fx.EQ) EqBody(chain, idx, inst, this) else GenericBody(chain, idx, inst, this) }
    }
}

/** The effect rack: shows the insert chain of the master or of the selected track. */
@Composable
fun Rack(modifier: Modifier) {
    val chain = S.rackChain()
    val list = S.chainList(chain)
    var addMenu by remember { mutableStateOf(false) }
    val trackName = if (S.tracks.isEmpty()) "TRACK" else S.tracks[S.selected.coerceIn(0, S.tracks.lastIndex)].name
    Column(modifier.background(Color(0xFF12161A)).padding(pd(8f))) {
        Row(Modifier.fillMaxWidth().height(pd(40f)), horizontalArrangement = Arrangement.spacedBy(pd(6f)), verticalAlignment = Alignment.CenterVertically) {
            MiniBtn("MASTER", S.fxOnMaster) { S.fxOnMaster = true }
            MiniBtn(trackName.take(10), !S.fxOnMaster, Modifier.weight(1f)) { S.fxOnMaster = false }
            Box {
                MiniBtn("+ FX", false) { addMenu = true }
                DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                    Fx.all.forEach { t ->
                        DropdownMenuItem(
                            text = { Column { Text(t.name, fontWeight = FontWeight.SemiBold); Text(t.desc, fontSize = 11.sp) } },
                            onClick = { addMenu = false; S.addFx(chain, t.id) })
                    }
                }
            }
            MiniBtn("HIDE", false) { S.rackVisible = false; S.savePrefs() }
        }
        Spacer(Modifier.height(pd(8f)))
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(pd(10f))) {
            if (list != null) list.forEachIndexed { i, f -> key(f) { FxPanel(chain, i, f, list.size) } }
            if (list == null || list.isEmpty()) Text("No effects here.\nTap + FX to add one.", color = C.dim, fontSize = fs(18f), modifier = Modifier.padding(pd(16f)))
            Spacer(Modifier.height(pd(20f)))
        }
    }
}
