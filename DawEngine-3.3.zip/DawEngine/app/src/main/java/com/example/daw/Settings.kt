package com.example.daw

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.launch
import java.io.File

@Composable
private fun SBtn(text: String, color: Color = C.text, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(pd(40f)).clip(RoundedCornerShape(pd(8f))).background(C.btn).clickable(enabled = enabled, onClick = onClick).padding(horizontal = pd(14f)),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (enabled) color else Color(0xFF454E56), fontSize = fs(17f), fontWeight = FontWeight.SemiBold, maxLines = 1) }
}

@Composable
private fun SRow(label: String, hint: String? = null, content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = pd(6f)).defaultMinSize(minHeight = pd(48f)), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = pd(12f))) {
            Text(label, color = C.text, fontSize = fs(19f), fontWeight = FontWeight.SemiBold)
            if (hint != null) Text(hint, color = C.dim, fontSize = fs(14f))
        }
        content()
    }
}

@Composable
private fun Seg(options: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(pd(5f))) {
        options.forEachIndexed { i, o -> MiniBtn(o, i == sel, Modifier.widthIn(min = pd(72f))) { onSel(i) } }
    }
}

@Composable
private fun OnOff(v: Boolean, onChange: (Boolean) -> Unit) = Seg(listOf("On", "Off"), if (v) 0 else 1) { onChange(it == 0) }

@Composable
private fun Title(t: String) = Text(t, color = C.orange, fontSize = fs(21f), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = pd(14f), bottom = pd(4f)))

/** Full-screen settings: Audio engine, Interface, Projects, About / diagnostics. */
@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var page by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var files by remember { mutableStateOf(Project.list(ctx)) }
    var exportFile by remember { mutableStateOf<File?>(null) }
    var logTick by remember { mutableIntStateOf(0) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val f = exportFile
        if (uri != null && f != null) Toast.makeText(ctx, if (Project.copyOut(ctx, f, uri)) "Exported" else "Export failed", Toast.LENGTH_SHORT).show()
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { val f = Project.copyIn(ctx, uri); files = Project.list(ctx); Toast.makeText(ctx, if (f != null) "Imported ${f.nameWithoutExtension}" else "Import failed", Toast.LENGTH_SHORT).show() }
    }
    LaunchedEffect(Unit) { S.refreshStreamInfo() }

    Box(Modifier.fillMaxSize().background(C.bg).pointerInput(Unit) { detectTapGestures { } }) {
        Row(Modifier.fillMaxSize().padding(pd(14f))) {
            Column(Modifier.width(pd(230f)).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(pd(8f))) {
                Text("SETTINGS", color = C.text, fontSize = fs(26f), fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = pd(10f)))
                listOf("AUDIO ENGINE", "INTERFACE", "PROJECTS", "ABOUT").forEachIndexed { i, n -> MiniBtn(n, page == i, Modifier.fillMaxWidth()) { page = i } }
                Spacer(Modifier.weight(1f))
                SBtn("CLOSE", C.green, modifier = Modifier.fillMaxWidth()) { S.savePrefs(); S.settingsOpen = false }
            }
            Spacer(Modifier.width(pd(16f)))
            Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState())) {
                when (page) {
                    0 -> {
                        Title("Output")
                        SRow("Performance mode", "Low latency = fastest response, more battery") {
                            Seg(listOf("Low latency", "Normal", "Power saver"), S.perfMode) { S.perfMode = it; S.savePrefs() }
                        }
                        SRow("Stream sharing", "Exclusive gives the lowest latency (falls back to shared)") {
                            Seg(listOf("Exclusive", "Shared"), if (S.exclusive) 0 else 1) { S.exclusive = it == 0; S.savePrefs() }
                        }
                        val sr = S.streamInfo[0].takeIf { it > 0f } ?: 48000f
                        val burst = S.streamInfo[1].takeIf { it > 0f } ?: 192f
                        SRow("Buffer size", "Larger = fewer clicks, more delay") {
                            Stepper("${S.bursts} x burst  (~%.1f ms)".format(burst * S.bursts / sr * 1000f), Modifier.width(pd(250f)).height(pd(36f)),
                                { S.bursts = (S.bursts - 1).coerceAtLeast(1); S.savePrefs() }, { S.bursts = (S.bursts + 1).coerceAtMost(8); S.savePrefs() })
                        }
                        val i = S.streamInfo
                        Text(if (i[5] > 0.5f) "Device: %.0f Hz  |  burst %.0f  |  buffer %.0f frames (%.1f ms)  |  %s  |  %s".format(
                            i[0], i[1], i[2], i[2] / i[0] * 1000f, if (i[4] == 1f) "AAudio" else "OpenSL ES", if (i[3] > 0.5f) "exclusive" else "shared")
                        else "Audio output is closed", color = C.dim, fontSize = fs(15f), modifier = Modifier.padding(vertical = pd(6f)))
                        SBtn("APPLY & RESTART AUDIO", C.green) { S.applyAudioConfig() }
                        Title("Recording")
                        SRow("Latency compensation", "Shifts the recording earlier by the device round-trip delay") {
                            Seg(listOf("Auto", "Manual"), if (S.recCompMs < 0f) 0 else 1) { S.recCompMs = if (it == 0) -1f else 40f; S.savePrefs() }
                        }
                        if (S.recCompMs >= 0f) SRow("Manual compensation") {
                            Stepper("%.0f ms".format(S.recCompMs), Modifier.width(pd(200f)).height(pd(36f)),
                                { S.recCompMs = (S.recCompMs - 5f).coerceAtLeast(0f); S.savePrefs() }, { S.recCompMs = (S.recCompMs + 5f).coerceAtMost(300f); S.savePrefs() })
                        }
                        val last = NativeEngine.lastLatencyMs()
                        if (last > 0f) Text("Last measured / used: %.0f ms".format(last), color = C.dim, fontSize = fs(15f))
                        SRow("Play while recording", "REC also starts playback so you can overdub") { OnOff(S.recPlay) { S.recPlay = it; S.savePrefs() } }
                    }
                    1 -> {
                        Title("Display")
                        SRow("Text size") {
                            Stepper("${(S.textScale * 100).toInt()} %", Modifier.width(pd(200f)).height(pd(36f)),
                                { S.textScale = (S.textScale - 0.1f).coerceAtLeast(0.8f); S.savePrefs() }, { S.textScale = (S.textScale + 0.1f).coerceAtMost(1.4f); S.savePrefs() })
                        }
                        SRow("Effects panel", "Show the effect rack on the right") { OnOff(S.rackVisible) { S.rackVisible = it; S.savePrefs() } }
                        SRow("Keep screen on") { OnOff(S.keepAwake) { S.keepAwake = it; S.savePrefs() } }
                        Title("Timeline")
                        SRow("Snap to grid") { OnOff(S.snapOn) { S.snapOn = it; S.savePrefs() } }
                        SRow("Grid size") {
                            val g = listOf(0.25f, 0.125f, 0.0625f)
                            Seg(listOf("1/4 bar", "1/8 bar", "1/16 bar"), g.indexOfFirst { it == S.gridBars }.coerceAtLeast(0)) { S.gridBars = g[it]; S.savePrefs() }
                        }
                        SRow("Follow playhead", "Scrolls the timeline while playing") { OnOff(S.follow) { S.follow = it; S.savePrefs() } }
                    }
                    2 -> {
                        Title("Current project")
                        OutlinedTextField(value = S.projectName, onValueChange = { S.projectName = it.take(40) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(Modifier.padding(vertical = pd(8f)), horizontalArrangement = Arrangement.spacedBy(pd(8f))) {
                            SBtn("NEW", C.orange, !busy) { S.newProject(); S.settingsOpen = false }
                            SBtn("SAVE", C.green, !busy) {
                                busy = true
                                scope.launch {
                                    val ok = Project.save(ctx, S.projectName); S.savePrefs(); files = Project.list(ctx); busy = false
                                    Toast.makeText(ctx, if (ok) "Saved \"${S.projectName}\"" else "Save failed", Toast.LENGTH_SHORT).show()
                                }
                            }
                            SBtn("IMPORT FILE", C.text, !busy) { importLauncher.launch(arrayOf("*/*")) }
                        }
                        Title("Saved projects")
                        if (files.isEmpty()) Text("No saved projects yet.", color = C.dim, fontSize = fs(17f))
                        files.forEach { f ->
                            Row(Modifier.fillMaxWidth().padding(vertical = pd(4f)), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(pd(6f))) {
                                Column(Modifier.weight(1f)) {
                                    Text(f.nameWithoutExtension, color = C.text, fontSize = fs(18f), maxLines = 1)
                                    Text("%.1f MB".format(f.length() / 1048576f), color = C.dim, fontSize = fs(13f))
                                }
                                SBtn("OPEN", C.green, !busy) {
                                    busy = true
                                    scope.launch {
                                        val ok = Project.load(f)
                                        busy = false
                                        if (ok) { S.settingsOpen = false; Toast.makeText(ctx, "Opened", Toast.LENGTH_SHORT).show() }
                                        else Toast.makeText(ctx, "Could not open this project", Toast.LENGTH_LONG).show()
                                    }
                                }
                                SBtn("EXPORT", C.text, !busy) { exportFile = f; exportLauncher.launch(f.name) }
                                SBtn("DELETE", C.red, !busy) { f.delete(); files = Project.list(ctx) }
                            }
                        }
                        if (busy) Text("Working...", color = C.orange, fontSize = fs(17f), modifier = Modifier.padding(top = pd(8f)))
                    }
                    else -> {
                        Title("Aurora DAW  v${CrashLog.VERSION}")
                        Text("Effects: ${Fx.all.joinToString(", ") { it.name }}.\nUp to 8 effects per track and on the master. Up to 32 tracks.",
                            color = C.dim, fontSize = fs(16f))
                        Title("Diagnostics")
                        val log = remember(logTick) { CrashLog.savedText() }
                        Text(if (log.isEmpty()) "No crash has been recorded." else log.takeLast(3500), color = if (log.isEmpty()) C.dim else C.text,
                            fontSize = fs(12f), modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(pd(8f))).background(Color(0xFF0E1215)).padding(pd(10f)))
                        Row(Modifier.padding(top = pd(8f)), horizontalArrangement = Arrangement.spacedBy(pd(8f))) {
                            SBtn("COPY", C.text, log.isNotEmpty()) { clip.setText(AnnotatedString(log)); Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show() }
                            SBtn("SHARE", C.text, log.isNotEmpty()) {
                                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, log)
                                ctx.startActivity(Intent.createChooser(i, "Share crash log"))
                            }
                            SBtn("CLEAR", C.red, log.isNotEmpty()) { CrashLog.clear(); logTick++ }
                        }
                    }
                }
                Spacer(Modifier.height(pd(40f)))
            }
        }
    }
}
