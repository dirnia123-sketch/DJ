package com.example.daw

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(applicationContext)
        S.app = applicationContext
        S.loadPrefs(this)
        NativeEngine.setAudioConfig(S.perfMode, S.exclusive, S.bursts)
        setContent { DawTheme { FlxmScreen() } }
    }

    override fun onResume() {
        super.onResume()
        if (!NativeEngine.openStream()) Toast.makeText(this, "Failed to open audio stream", Toast.LENGTH_LONG).show()
        S.refreshStreamInfo()
    }

    override fun onPause() {
        super.onPause()
        try { S.stopRecording() } catch (e: Throwable) { CrashLog.record("stop recording on pause", e) }
        Project.autoSave(this)     // safety copy of the project
        S.savePrefs()
        S.pause()
        NativeEngine.closeStream()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }
}
