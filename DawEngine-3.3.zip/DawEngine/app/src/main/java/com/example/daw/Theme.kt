package com.example.daw

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object C {
    val bg = Color(0xFF181C21); val bar = Color(0xFF20262C); val btn = Color(0xFF1B2025)
    val row = Color(0xFF1F252B); val fxCell = Color(0xFF1B2126); val rowSel = Color(0xFF222C27)
    val lane = Color(0xFF171B20); val grid = Color(0xFF222930); val gridBar = Color(0xFF313A43)
    val text = Color(0xFFD4DBE2); val dim = Color(0xFF8A95A0)
    val orange = Color(0xFFF2A33A); val green = Color(0xFF3FD068); val red = Color(0xFFE5313B)
    val blue = Color(0xFF2F7BEF); val synth = Color(0xFF43D14F); val bass = Color(0xFFA24BE0)
    val vocal = Color(0xFFF0C21B); val pads = Color(0xFF22D3D3)
}

/** dp per "mockup pixel": the whole UI scales with screen height (mockup is 768 px tall). */
val LocalU = compositionLocalOf { 0.5f }
@Composable fun pd(v: Float): Dp = (v * LocalU.current).dp
@Composable fun fs(v: Float): TextUnit = (v * LocalU.current * S.textScale).sp

@Composable
fun DawTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(background = C.bg, surface = C.bar, primary = C.orange), content = content)
}
