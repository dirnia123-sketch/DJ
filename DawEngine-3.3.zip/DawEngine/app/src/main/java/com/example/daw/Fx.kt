package com.example.daw

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

const val KNOB_LIN = 0
const val KNOB_LOG = 1
const val CHOICE = 2
const val TOGGLE = 3
const val MAX_SLOTS = 8

class ParamSpec(
    val label: String, val min: Float, val max: Float, val def: Float, val kind: Int, val color: Color,
    val choices: List<String> = emptyList(), val fmt: (Float) -> String = { "%.2f".format(it) }
)

/** `id` is the native effect type; `toNative` maps the UI values to the native parameter layout (see Effects.h). */
class FxType(
    val id: Int, val name: String, val accent: Color, val params: List<ParamSpec>, val desc: String,
    val toNative: (FloatArray) -> FloatArray = { it }
) {
    val knobCount get() = params.count { it.kind <= KNOB_LOG }
    val otherCount get() = params.count { it.kind >= CHOICE }
}

class FxInst(val type: FxType) {
    val v = mutableStateListOf<Float>().also { l -> type.params.forEach { l.add(it.def) } }
    var on by mutableStateOf(true)
    var bypass by mutableStateOf(false)
    var collapsed by mutableStateOf(false)
    fun active() = on && !bypass
    fun native(): FloatArray = type.toNative(FloatArray(v.size) { v[it] })
    fun copy(): FxInst = FxInst(type).also { c ->
        for (i in v.indices) c.v[i] = v[i]
        c.on = on; c.bypass = bypass; c.collapsed = collapsed
    }
}

object Fx {
    const val EQ = 1; const val COMP = 2; const val LIMITER = 3; const val GATE = 4; const val REVERB = 5
    const val DELAY = 6; const val CHORUS = 7; const val FLANGER = 8; const val PHASER = 9; const val DIST = 10
    const val FILTER = 11; const val TREMOLO = 12; const val WIDTH = 13

    private fun hzT(f: Float) = if (f >= 1000f) "%.2fk".format(f / 1000f) else "%.0f Hz".format(f)
    private fun dbT(d: Float) = "%+.1f dB".format(d)
    private fun pctT(p: Float) = "%.0f%%".format(p * 100f)
    private fun msT(m: Float) = if (m >= 100f) "%.0f ms".format(m) else "%.1f ms".format(m)
    private fun xT(v: Float) = "%.1f:1".format(v)

    private fun lin(label: String, min: Float, max: Float, def: Float, c: Color, fmt: (Float) -> String) =
        ParamSpec(label, min, max, def, KNOB_LIN, c, emptyList(), fmt)
    private fun log(label: String, min: Float, max: Float, def: Float, c: Color, fmt: (Float) -> String) =
        ParamSpec(label, min, max, def, KNOB_LOG, c, emptyList(), fmt)
    private fun choice(label: String, def: Int, items: List<String>) =
        ParamSpec(label, 0f, (items.size - 1).toFloat(), def.toFloat(), CHOICE, C.dim, items)
    private fun toggle(label: String, def: Boolean) =
        ParamSpec(label, 0f, 1f, if (def) 1f else 0f, TOGGLE, C.dim)

    private val blue = Color(0xFF4A90D9); private val green = Color(0xFF5FB86B); private val red = Color(0xFFE5534B)
    private val gray = Color(0xFF8E9AA5); private val amber = Color(0xFFC8892B); private val teal = Color(0xFF3FB6C9)
    private val purple = Color(0xFF9B6BDB); private val pink = Color(0xFFD46BA3); private val mint = Color(0xFF6BD4B2)
    private val orange = Color(0xFFE0662B); private val yellow = Color(0xFFD4C54A); private val sky = Color(0xFF58B7E8)

    val divNames = listOf("1/4", "1/8", "3/16", "1/16", "1/2")
    private val divBeats = floatArrayOf(1f, 0.5f, 0.75f, 0.25f, 2f)
    val roomNames = listOf("Room", "Hall", "Plate", "Cathedral")

    val all: List<FxType> = listOf(
        FxType(EQ, "M-EQ-5", blue, buildList {
            val f = floatArrayOf(60f, 200f, 1000f, 5000f, 12000f); val g = floatArrayOf(-3f, 5f, -2f, 3f, 0f); val q = floatArrayOf(1f, 1.2f, 1.2f, 1f, 1f)
            for (i in 0..4) add(lin("F${i + 1}", 20f, 20000f, f[i], blue) { hzT(it) })
            for (i in 0..4) add(lin("G${i + 1}", -15f, 15f, g[i], green) { dbT(it) })
            for (i in 0..4) add(lin("Q${i + 1}", 0.3f, 10f, q[i], blue) { "%.2f".format(it) })
            add(lin("Out", -12f, 12f, 0f, orange) { dbT(it) })
        }, "5-band parametric equaliser"),
        FxType(COMP, "Compressor", green, listOf(
            lin("Thresh", -60f, 0f, -12f, green) { dbT(it) }, log("Ratio", 1f, 20f, 3f, green) { xT(it) },
            log("Attack", 0.1f, 100f, 10f, green) { msT(it) }, log("Release", 10f, 1000f, 120f, green) { msT(it) },
            lin("Makeup", 0f, 24f, 1.5f, orange) { dbT(it) }, lin("Mix", 0f, 1f, 1f, gray) { pctT(it) }
        ), "Evens out dynamics, parallel mix"),
        FxType(LIMITER, "Limiter", red, listOf(
            lin("Input", 0f, 24f, 0f, orange) { dbT(it) }, lin("Ceiling", -12f, 0f, -0.3f, red) { dbT(it) },
            log("Release", 10f, 500f, 100f, red) { msT(it) }
        ), "Look-ahead brick-wall limiter"),
        FxType(GATE, "Noise Gate", gray, listOf(
            lin("Thresh", -80f, 0f, -50f, gray) { dbT(it) }, log("Attack", 0.1f, 50f, 1f, gray) { msT(it) },
            lin("Hold", 0f, 500f, 20f, gray) { msT(it) }, log("Release", 5f, 500f, 100f, gray) { msT(it) },
            lin("Range", -80f, 0f, -80f, orange) { dbT(it) }
        ), "Silences the signal below the threshold"),
        FxType(REVERB, "M-Reverb Pro", amber, listOf(
            lin("Mix", 0f, 1f, 0.22f, amber) { pctT(it) }, lin("Decay", 0.3f, 8f, 2.5f, amber) { "%.1f s".format(it) },
            lin("Pre-delay", 0f, 100f, 20f, gray) { "%.0f ms".format(it) }, lin("Size", 0f, 1f, 0.5f, blue) { pctT(it) },
            choice("Room", 1, roomNames)
        ), "Hall / plate / room reverb"),
        FxType(DELAY, "M-Delay Multi", teal, listOf(
            lin("Time", 50f, 1000f, 250f, teal) { "%.0f ms".format(it) }, lin("Feedback", 0f, 0.95f, 0.38f, teal) { pctT(it) },
            lin("Mix", 0f, 0.8f, 0.16f, amber) { pctT(it) }, lin("Width", 0f, 1.5f, 1f, amber) { pctT(it) },
            log("HP", 20f, 500f, 20f, green) { hzT(it) }, log("LP", 1000f, 20000f, 20000f, green) { hzT(it) },
            toggle("BPM SYNC", true), choice("Div", 1, divNames), toggle("PING-PONG", true)
        ), "Stereo / ping-pong delay with tempo sync") { v ->
            val ms = if (v[6] > 0.5f) divBeats[v[7].toInt().coerceIn(0, divBeats.size - 1)] * 60000f / S.BPM else v[0]
            floatArrayOf(ms, v[1], v[2], v[3], v[4], v[5], if (v[8] > 0.5f) 1f else 0f)
        },
        FxType(CHORUS, "Chorus", purple, listOf(
            log("Rate", 0.05f, 5f, 0.8f, purple) { "%.2f Hz".format(it) }, lin("Depth", 0f, 1f, 0.5f, purple) { pctT(it) },
            lin("Mix", 0f, 1f, 0.5f, amber) { pctT(it) }, lin("Spread", 0f, 1f, 0.8f, gray) { pctT(it) }
        ), "Thickens the sound with a detuned copy"),
        FxType(FLANGER, "Flanger", pink, listOf(
            log("Rate", 0.05f, 5f, 0.25f, pink) { "%.2f Hz".format(it) }, lin("Depth", 0f, 1f, 0.7f, pink) { pctT(it) },
            lin("Feedback", -0.95f, 0.95f, 0.5f, orange) { pctT(it) }, lin("Mix", 0f, 1f, 0.5f, amber) { pctT(it) }
        ), "Jet-plane sweeping comb filter"),
        FxType(PHASER, "Phaser", mint, listOf(
            log("Rate", 0.05f, 5f, 0.4f, mint) { "%.2f Hz".format(it) }, lin("Depth", 0f, 1f, 0.7f, mint) { pctT(it) },
            lin("Feedback", 0f, 0.9f, 0.4f, orange) { pctT(it) }, lin("Mix", 0f, 1f, 0.5f, amber) { pctT(it) },
            choice("Stages", 0, listOf("4", "6", "8"))
        ), "All-pass phase sweep") { v -> floatArrayOf(v[0], v[1], v[2], v[4], v[3]) },
        FxType(DIST, "Distortion", orange, listOf(
            lin("Drive", 0f, 40f, 12f, orange) { dbT(it) }, lin("Tone", 0f, 1f, 0.6f, yellow) { pctT(it) },
            lin("Mix", 0f, 1f, 1f, amber) { pctT(it) }, lin("Output", -24f, 6f, -6f, gray) { dbT(it) },
            choice("Type", 0, listOf("Soft", "Tube", "Hard", "Fold"))
        ), "Saturation / overdrive / wave-folder") { v -> floatArrayOf(v[0], v[1], v[4], v[2], v[3]) },
        FxType(FILTER, "Filter", yellow, listOf(
            log("Cutoff", 20f, 20000f, 1000f, yellow) { hzT(it) }, log("Reso (Q)", 0.5f, 12f, 0.8f, orange) { "%.2f".format(it) },
            lin("Mix", 0f, 1f, 1f, amber) { pctT(it) }, choice("Type", 0, listOf("Low-pass", "High-pass", "Band-pass", "Notch"))
        ), "Resonant state-variable filter") { v -> floatArrayOf(v[3], v[0], v[1], v[2]) },
        FxType(TREMOLO, "Tremolo / Pan", sky, listOf(
            log("Rate", 0.1f, 20f, 4f, sky) { "%.1f Hz".format(it) }, lin("Depth", 0f, 1f, 0.6f, sky) { pctT(it) },
            choice("Shape", 0, listOf("Sine", "Triangle", "Square")), choice("Mode", 0, listOf("Tremolo", "Auto-pan"))
        ), "Amplitude or stereo movement"),
        FxType(WIDTH, "Stereo Width", sky, listOf(
            lin("Width", 0f, 2f, 1f, sky) { pctT(it) }, lin("Mid", -12f, 12f, 0f, gray) { dbT(it) }, lin("Side", -12f, 12f, 0f, gray) { dbT(it) }
        ), "Mid / side stereo widener")
    )

    fun byId(id: Int): FxType = all.firstOrNull { it.id == id } ?: all[0]

    /** Panel height in mock px for the generic knob panel. */
    fun panelHeight(t: FxType): Float {
        if (t.id == EQ) return 270f
        val rows = (t.knobCount + 5) / 6
        return 40f + rows * 92f + (if (t.otherCount > 0) 38f else 0f) + 16f
    }
    fun defaultMaster(): List<FxInst> = listOf(EQ, DELAY, REVERB, COMP).map { FxInst(byId(it)) }
}
