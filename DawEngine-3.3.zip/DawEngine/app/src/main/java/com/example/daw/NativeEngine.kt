package com.example.daw

object NativeEngine {
    init { System.loadLibrary("dawengine") }

    // ---- stream / transport
    external fun openStream(): Boolean
    external fun closeStream()
    /** perf: 0 low latency, 1 normal, 2 power saving. Applied by the next openStream(). */
    external fun setAudioConfig(perf: Int, exclusive: Boolean, bursts: Int)
    /** out = {sampleRate, framesPerBurst, bufferFrames, exclusive(0/1), api(1 AAudio, 2 OpenSL), isOpen(0/1)} */
    external fun getStreamInfo(out: FloatArray)
    external fun startEngine()          // play
    external fun stopEngine()           // pause
    external fun seek(seconds: Float)
    external fun getPosition(): Float
    /** [0..31] track peaks (index = track slot id - 1), 32 master L, 33 master R, 34 input level */
    external fun getMeters(out: FloatArray)

    // ---- samples & clips
    /** Copies decoded stereo audio into the engine; returns a sample id (> 0) or 0 on failure. */
    external fun registerSample(stereo: FloatArray, frames: Int, sampleRate: Int): Int
    external fun releaseSample(sampleId: Int)
    external fun sampleFrames(sampleId: Int): Int
    external fun sampleRate(sampleId: Int): Int
    external fun copySample(sampleId: Int, out: FloatArray): Boolean
    external fun samplePeaks(sampleId: Int, out: FloatArray)
    /** Replaces ALL clips of a track. params = {startSec, offsetSec, lenSec} for each clip, same order as sampleIds. */
    external fun setTrackClips(trackId: Int, sampleIds: IntArray, params: DoubleArray): Boolean
    external fun clearTrack(trackId: Int)

    // ---- mixer
    external fun setTrackVolume(trackId: Int, volume: Float)
    external fun setTrackMute(trackId: Int, mute: Boolean)
    external fun setTrackSolo(trackId: Int, solo: Boolean)
    external fun setTrackPan(trackId: Int, pan: Float)
    external fun setMasterGain(gain: Float)

    // ---- insert effects: chain 0 = master, 1..32 = track slot id; type 0 clears the slot
    external fun setFx(chain: Int, slot: Int, type: Int, params: FloatArray, active: Boolean): Boolean
    external fun setFxParams(chain: Int, slot: Int, params: FloatArray)
    external fun setFxActive(chain: Int, slot: Int, active: Boolean)

    // ---- recording
    external fun startRecording(): Boolean
    /** compensateMs < 0 = automatic. Returns the new sample id (0 = nothing recorded). */
    external fun stopRecording(compensateMs: Float): Int
    external fun isRecording(): Boolean
    external fun recordingSeconds(): Float
    external fun lastLatencyMs(): Float
}
