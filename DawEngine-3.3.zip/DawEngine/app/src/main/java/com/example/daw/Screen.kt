package com.example.daw

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.sin

private val Silver = Color(0xFFC9D1D8)

@Composable
private fun IconBtn(g: G, w: Float, h: Float, size: Float, color: Color = Color(0xFF9AA5AF), onClick: () -> Unit) {
    Box(Modifier.size(pd(w), pd(h)).clip(RoundedCornerShape(pd(10f))).background(C.btn).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Glyph(g, color, Modifier.size(pd(size)))
    }
}

@Composable
private fun TopTextBtn(text: String, w: Float, h: Float, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(pd(w), pd(h)).clip(RoundedCornerShape(pd(10f))).background(C.btn).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (enabled) Color(0xFF9AA5AF) else Color(0xFF454E56), fontSize = fs(17f), fontWeight = FontWeight.SemiBold, maxLines = 1) }
}

@Composable
private fun TransportBtn(g: G, color: Color, w: Float, onClick: () -> Unit) {
    Box(Modifier.size(pd(w), pd(50f)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Glyph(g, color, Modifier.size(pd(30f)), cut = C.btn)
    }
}

@Composable
private fun TextBtn(text: String, color: Color, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.height(pd(38f)).clip(RoundedCornerShape(pd(8f))).background(C.btn)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = pd(12f)),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (enabled) color else Color(0xFF454E56), fontSize = fs(17f), fontWeight = FontWeight.SemiBold, maxLines = 1) }
}

@Composable
private fun Logo(modifier: Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(pd(46f))) {
            val c = Offset(size.width / 2, size.height / 2); val r = size.width * 0.46f
            val p = Path()
            for (i in 0 until 6) { val a = Math.toRadians(30.0 + 60.0 * i); val x = c.x + r * cos(a).toFloat(); val y = c.y + r * sin(a).toFloat(); if (i == 0) p.moveTo(x, y) else p.lineTo(x, y) }
            p.close()
            drawPath(p, Color(0xFF7D8892), style = Stroke(size.width * 0.07f))
            for (i in intArrayOf(1, 3, 5)) { val a = Math.toRadians(30.0 + 60.0 * i); drawLine(Color(0xFF7D8892), c, Offset(c.x + r * cos(a).toFloat(), c.y + r * sin(a).toFloat()), size.width * 0.06f) }
        }
        Column(Modifier.padding(start = pd(10f))) {
            Text("FLXM", color = Color(0xFFCFD6DC), fontSize = fs(36f), fontWeight = FontWeight.Bold, letterSpacing = fs(2f), lineHeight = fs(36f), maxLines = 1)
            Text("MOBILE", color = C.dim, fontSize = fs(15f), letterSpacing = fs(4f), lineHeight = fs(15f), maxLines = 1)
        }
    }
}

@Composable
private fun ToggleBtn(text: String, active: Boolean, w: Float, h: Float, onClick: () -> Unit) {
    Box(
        Modifier.size(pd(w), pd(h)).clip(RoundedCornerShape(pd(10f))).background(if (active) Color(0xFF223B2B) else C.btn).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (active) C.green else Color(0xFF9AA5AF), fontSize = fs(16f), fontWeight = FontWeight.SemiBold, maxLines = 1) }
}

@Composable
private fun TopBar(modifier: Modifier, onFolder: () -> Unit, onSave: () -> Unit) {
    Box(modifier.fillMaxWidth().background(C.bar)) {
        Row(Modifier.align(Alignment.CenterStart).padding(start = pd(14f)), horizontalArrangement = Arrangement.spacedBy(pd(10f))) {
            IconBtn(G.FOLDER, 70f, 58f, 34f, onClick = onFolder)
            IconBtn(G.SAVE, 66f, 58f, 32f, onClick = onSave)
            IconBtn(G.GEAR, 66f, 58f, 34f) { S.settingsOpen = true }
            TopTextBtn("UNDO", 84f, 58f, S.canUndo) { S.undo() }
            TopTextBtn("REDO", 84f, 58f, S.canRedo) { S.redo() }
        }
        Logo(Modifier.align(Alignment.Center))
        Row(Modifier.align(Alignment.CenterEnd).padding(end = pd(14f)).clip(RoundedCornerShape(pd(10f))).background(C.btn).padding(horizontal = pd(6f))) {
            TransportBtn(G.PLAY, Silver, 62f) { S.play() }
            TransportBtn(G.PAUSE, Silver, 62f) { S.pause() }
            TransportBtn(G.PLAY, Silver, 62f) { S.playFromStart() }
            TransportBtn(G.STOP, Silver, 62f) { S.stop() }
        }
    }
}

@Composable
private fun BottomBar(modifier: Modifier, onFolder: () -> Unit, onSave: () -> Unit, onRec: () -> Unit) {
    Box(modifier.fillMaxWidth().background(C.bar)) {
        Row(Modifier.align(Alignment.CenterStart).padding(start = pd(14f)), horizontalArrangement = Arrangement.spacedBy(pd(8f)), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(G.FOLDER, 62f, 52f, 30f, onClick = onFolder)
            IconBtn(G.SAVE, 58f, 52f, 28f, onClick = onSave)
            IconBtn(G.GEAR, 58f, 52f, 30f) { S.settingsOpen = true }
            ToggleBtn("MIXER", S.mixerOpen, 92f, 52f) { S.mixerOpen = !S.mixerOpen }
            ToggleBtn("FX", S.rackVisible && !S.mixerOpen, 62f, 52f) { S.rackVisible = !S.rackVisible; S.mixerOpen = false; S.savePrefs() }
        }
        Row(Modifier.align(Alignment.Center).clip(RoundedCornerShape(pd(10f))).background(C.btn).padding(horizontal = pd(6f)), verticalAlignment = Alignment.CenterVertically) {
            TransportBtn(G.BACK, Silver, 62f) { S.seekBars(0f) }
            TransportBtn(G.PLAY, Silver, 62f) { if (S.playing) S.pause() else S.play() }
            TransportBtn(G.REC, if (S.recording) Color(0xFFFF2D2D) else C.red, 62f, onClick = onRec)
            if (S.recording) Text("%d:%02d".format(S.recSec.toInt() / 60, S.recSec.toInt() % 60), color = Color(0xFFFF5A5A), fontSize = fs(22f),
                fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(horizontal = pd(8f)))
        }
        Row(Modifier.align(Alignment.CenterEnd).padding(end = pd(14f)).clip(RoundedCornerShape(pd(10f))).background(C.btn).padding(horizontal = pd(6f)),
            verticalAlignment = Alignment.CenterVertically) {
            TransportBtn(G.PLAY, Silver, 54f) { S.play() }
            Text("${S.BPM.toInt()} BPM", color = C.text, fontSize = fs(24f), maxLines = 1, modifier = Modifier.padding(horizontal = pd(8f)))
            TransportBtn(G.STOP, Silver, 54f) { S.stop() }
        }
    }
}

@Composable
private fun MenuItem(text: String, onClick: () -> Unit) = DropdownMenuItem(text = { Text(text) }, onClick = onClick)

@Composable
private fun TrackHeader(t: Track, index: Int, modifier: Modifier) {
    val selected = S.selected == index
    val compact = t.h < 64f
    var menu by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    Row(modifier.fillMaxWidth().padding(bottom = pd(2f)).background(if (selected) C.rowSel else C.row)) {
        Box(
            Modifier.width(pd(68f)).fillMaxHeight().background(if (selected) Color(0xFF1F2B25) else C.fxCell)
                .clickable { if (index == 0) S.toggleMaster() else S.selected = index },
            contentAlignment = Alignment.Center
        ) {
            if (selected) Box(Modifier.align(Alignment.CenterStart).width(pd(6f)).fillMaxHeight().background(C.green))
            if (index == 0) Glyph(G.SPEAKER, if (S.masterMuted) Color(0xFF4A535B) else Color(0xFF9AA5AF), Modifier.size(pd(38f)), cut = C.fxCell)
            else Text("fx", color = if (selected) C.green else t.color, fontSize = fs(30f), fontStyle = FontStyle.Italic,
                fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.weight(1f).fillMaxHeight()) {
            Row(
                Modifier.fillMaxSize()
                    .pointerInput(index) { detectTapGestures(onTap = { S.selected = index }, onLongPress = { menu = true }) }
                    .padding(start = pd(14f)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Glyph(t.glyph, if (t.mute) C.dim else t.color, Modifier.size(pd(if (compact) 30f else 52f)), cut = C.row)
                Column(Modifier.weight(1f).padding(start = pd(14f), end = pd(14f))) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(t.name, color = if (t.mute) C.dim else t.color, fontSize = fs(if (compact) 17f else 21f),
                            fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                        if (t.mute) Text("  M", color = C.red, fontSize = fs(15f), fontWeight = FontWeight.Bold, maxLines = 1)
                        if (t.solo) Text("  S", color = C.orange, fontSize = fs(15f), fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                    TrackSlider(t.volume, t.color, Modifier.fillMaxWidth().height(pd(if (compact) 22f else 30f))) {
                        S.setVolume(t, it)
                    }
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                MenuItem("Rename") { menu = false; draft = t.name; renaming = true }
                MenuItem(if (t.mute) "Unmute" else "Mute") { menu = false; S.toggleMute(t) }
                MenuItem(if (t.solo) "Unsolo" else "Solo") { menu = false; S.toggleSolo(t) }
                MenuItem("Move up") { menu = false; S.moveTrack(t, -1) }
                MenuItem("Move down") { menu = false; S.moveTrack(t, 1) }
                MenuItem("Effects...") { menu = false; S.selected = index; S.fxOnMaster = false; S.rackVisible = true; S.mixerOpen = false }
                MenuItem("Duplicate track") { menu = false; S.duplicateTrack(t) }
                MenuItem("Height: " + (if (t.h < 64f) "small" else if (t.h < 100f) "normal" else "large") + "  (tap to change)") { menu = false; S.cycleHeight(t) }
                MenuItem("Delete track") { menu = false; S.removeTrack(t) }
            }
        }
    }
    if (renaming) AlertDialog(
        onDismissRequest = { renaming = false },
        title = { Text("Rename track") },
        text = { OutlinedTextField(value = draft, onValueChange = { draft = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { S.rename(t, draft); renaming = false }) { Text("OK") } },
        dismissButton = { TextButton(onClick = { renaming = false }) { Text("Cancel") } }
    )
}

@Composable
private fun ClipBar(c: Clip, modifier: Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(pd(12f))).background(Color(0xEE20262C)).padding(pd(6f)),
        horizontalArrangement = Arrangement.spacedBy(pd(6f)), verticalAlignment = Alignment.CenterVertically
    ) {
        TextBtn("SPLIT", C.text) { S.splitAtPlayhead(c) }
        TextBtn("COPY", C.text) { S.duplicateClip(c) }
        TextBtn("DELETE", C.red) { S.deleteClip(c) }
        TextBtn("DONE", C.dim) { S.selClip = null }
    }
}

@Composable
private fun CrashDialog(text: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = { },
        title = { Text("The app closed unexpectedly last time") },
        text = {
            Column {
                Text("Please copy this report and send it so the problem can be fixed.", fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Text(text.takeLast(3000), fontSize = 10.sp, modifier = Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState()))
            }
        },
        confirmButton = { TextButton(onClick = { clip.setText(AnnotatedString(text)); Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show() }) { Text("COPY") } },
        dismissButton = {
            Row {
                TextButton(onClick = {
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                    ctx.startActivity(Intent.createChooser(i, "Share crash report"))
                }) { Text("SHARE") }
                TextButton(onClick = { onClose() }) { Text("CLOSE") }
            }
        }
    )
}

@Composable
fun FlxmScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val view = LocalView.current
    var pickTrack by remember { mutableIntStateOf(-1) }
    var pickBar by remember { mutableFloatStateOf(0f) }
    var crashText by remember { mutableStateOf<String?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && pickTrack in S.tracks.indices) {
            val t = S.tracks[pickTrack]; val bar = pickBar
            scope.launch { S.loadAudio(ctx, t, uri, bar) }
        }
    }
    /** Adds an audio file to track `track` at `bar` (creates a track first when the project is empty). */
    fun pick(track: Int, bar: Float) {
        if (S.tracks.isEmpty()) { if (S.addTrack() == null) return; pickTrack = 0 }
        else pickTrack = track.coerceIn(0, S.tracks.lastIndex)
        pickBar = bar
        launcher.launch(arrayOf("audio/*"))
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) S.startRecording() else Toast.makeText(ctx, "Microphone permission is required to record", Toast.LENGTH_LONG).show()
    }
    fun toggleRec() {
        if (S.recording) { S.stopRecording(); return }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) S.startRecording()
        else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
    fun save() {
        scope.launch {
            val ok = Project.save(ctx, S.projectName); S.savePrefs()
            Toast.makeText(ctx, if (ok) "Saved \"${S.projectName}\"" else "Save failed", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) { crashText = CrashLog.pendingReport(ctx) }
    LaunchedEffect(Unit) {
        if (S.tracks.isEmpty()) S.ensureMasterDefaults()
        S.pushAll()
        if (S.tracks.isEmpty()) {
            val demo = withContext(Dispatchers.Default) { Demo.build() }
            S.loadDemo(demo)
        }
        S.refreshStreamInfo()
    }
    LaunchedEffect(Unit) {   // transport position, recording timer, level meters
        val buf = FloatArray(35)
        while (true) {
            if (S.playing) S.posSec = NativeEngine.getPosition()
            if (S.recording) { S.recSec = NativeEngine.recordingSeconds(); if (S.recSec >= 299f) S.stopRecording() }
            if (S.mixerOpen || S.playing || S.recording || S.levels.any { it > 0.003f }) S.updateMeters(buf)
            S.followPlayhead()
            delay(33)
        }
    }
    view.keepScreenOn = S.keepAwake

    BoxWithConstraints(Modifier.fillMaxSize().background(C.bg)) {
        val u = maxHeight.value / 768f
        CompositionLocalProvider(LocalU provides u) {
            Box(Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxSize()) {
                    TopBar(Modifier.weight(74f), { pick(S.selected, S.posBars()) }, { save() })
                    if (S.mixerOpen) MixerScreen(Modifier.weight(630f).fillMaxWidth())
                    else Row(Modifier.weight(630f).fillMaxWidth()) {
                        Column(Modifier.width(pd(345f)).fillMaxHeight().background(Color(0xFF12161A))) {
                            Row(
                                Modifier.fillMaxWidth().height(pd(41f)).padding(horizontal = pd(8f)),
                                horizontalArrangement = Arrangement.spacedBy(pd(8f)), verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextBtn("+ TRACK", C.green) { S.addTrack() }
                                TextBtn("+ AUDIO", C.orange) { pick(S.selected, S.posBars()) }
                            }
                            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(S.vScroll)) {
                                S.tracks.forEachIndexed { i, t -> key(t.id) { TrackHeader(t, i, Modifier.height(pd(t.h))) } }
                                Spacer(Modifier.height(pd(90f)))
                            }
                        }
                        Box(Modifier.weight(1f).fillMaxHeight()) {
                            Timeline(Modifier.fillMaxSize()) { lane, bar -> pick(lane, bar) }
                            S.selClip?.let { c -> ClipBar(c, Modifier.align(Alignment.BottomCenter).padding(bottom = pd(12f))) }
                        }
                        if (S.rackVisible) Rack(Modifier.width(pd(450f)).fillMaxHeight())
                    }
                    BottomBar(Modifier.weight(64f), { pick(S.selected, S.posBars()) }, { save() }, { toggleRec() })
                }
                if (S.settingsOpen) SettingsScreen()
                crashText?.let { CrashDialog(it) { CrashLog.clear(); crashText = null } }
            }
        }
    }
}
