package com.example.daw

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

/** Builds the demo project: every part is synthesised, rendered to audio and loaded into the engine. */
object Demo {
    private const val SR = 44100
    private val beat = 60.0 / 128.0
    private fun nf(bars: Float) = (bars * 4 * beat * SR).toInt()
    private class Abs(val beat: Float, val len: Float, val pitch: Int)

    private fun synth(total: Int, notes: List<Abs>, wave: Int, amp: Float): FloatArray {
        val out = FloatArray(total * 2)
        for (n in notes) {
            val inc = 440.0 * 2.0.pow((n.pitch - 69) / 12.0) / SR
            val s0 = (n.beat * beat * SR).toInt(); val len = (n.len * beat * SR).toInt(); val rel = (0.15 * SR).toInt()
            var ph = 0.0
            for (i in 0 until len + rel) {
                val idx = s0 + i; if (idx >= total) break
                val env = (if (i < len) minOf(1.0, i / (0.012 * SR)) else 1.0 - (i - len).toDouble() / rel).coerceAtLeast(0.0)
                val f = ph - floor(ph)
                val x = when (wave) { 0 -> sin(2 * PI * ph); 1 -> 2 * f - 1; else -> if (f < 0.5) 1.0 else -1.0 }
                val v = (x * env * amp).toFloat()
                out[2 * idx] += v; out[2 * idx + 1] += v; ph += inc
            }
        }
        return out
    }

    private fun drums(total: Int, bars: Int): FloatArray {
        val out = FloatArray(total * 2); val rnd = Random(7)
        fun add(start: Int, len: Int, f: (Double) -> Double) {
            for (i in 0 until len) { val idx = start + i; if (idx >= total) break
                val v = f(i.toDouble() / SR).toFloat(); out[2 * idx] += v; out[2 * idx + 1] += v }
        }
        for (b in 0 until bars) for (st in 0 until 16) {
            val s0 = ((b * 16 + st) * 0.25 * beat * SR).toInt()
            if (st == 0 || st == 8 || st == 10) { var ph = 0.0
                add(s0, (0.28 * SR).toInt()) { t -> ph += 2 * PI * (45 + 90 * exp(-t * 30)) / SR; sin(ph) * exp(-t * 9) * 0.9 } }
            if (st == 4 || st == 12) add(s0, (0.22 * SR).toInt()) { t ->
                (rnd.nextDouble() * 2 - 1) * exp(-t * 22) * 0.5 + sin(2 * PI * 190 * t) * exp(-t * 28) * 0.4 }
            if (st % 2 == 0) { var prev = 0.0
                add(s0, (0.07 * SR).toInt()) { t -> val x = rnd.nextDouble() * 2 - 1; val y = (x - prev) * 0.5; prev = x; y * exp(-t * 90) * 0.35 } }
        }
        return out
    }

    private fun rel(list: List<Triple<Float, Float, Int>>, shift: Int) = list.map { Note(it.first, it.second, it.third + shift) }
    private fun abs(notes: List<Note>, bar: Int) = notes.map { Abs(bar * 4 + it.beat, it.len, it.pitch) }

    private fun reg(buf: FloatArray, frames: Int): Int { val id = NativeEngine.registerSample(buf, frames, SR); S.noteSample(id); return id }
    private fun barsOf(frames: Int) = frames.toFloat() / SR / S.barSec

    /**
     * Returns the clips of each track (same order as the demo tracks). Every clip is rendered to its OWN audio
     * sample, so moving / trimming / splitting / deleting a clip really changes what you hear.
     */
    fun build(): List<List<DClip>> {
        val clips = ArrayList<List<DClip>>()

        val dn = nf(4f)
        clips.add(listOf(DClip(reg(drums(dn, 4), dn), 0, barsOf(dn), 0f, barsOf(dn))))

        val lead = listOf(Triple(0f, .75f, 76), Triple(.75f, .75f, 74), Triple(1.5f, .5f, 72), Triple(2f, 1f, 71), Triple(3f, .5f, 69), Triple(3.5f, .5f, 67))
        clips.add((0..3).map { i ->
            val notes = rel(lead, intArrayOf(0, 0, -2, -5)[i]); val fr = nf(1f)
            DClip(reg(synth(fr, abs(notes, 0), 1, 0.07f), fr), 1, barsOf(fr), i.toFloat(), barsOf(fr), notes)
        })

        val bass = listOf(Triple(0f, 1.5f, 40), Triple(2f, 1f, 43), Triple(3f, .5f, 38), Triple(3.5f, .5f, 41))
        clips.add((1..3).map { i ->
            val notes = rel(bass, intArrayOf(0, 0, -2, -5)[i]); val fr = nf(1f)
            DClip(reg(synth(fr, abs(notes, 0), 0, 0.35f), fr), 1, barsOf(fr), i.toFloat(), barsOf(fr), notes)
        })

        val vl = nf(0.34f)
        val voc = FloatArray(vl * 2); val rnd = Random(3); var y = 0.0
        val peaks = FloatArray(60)
        for (i in 0 until vl) {
            val t = i.toDouble() / vl
            y += (0.02 + 0.5 * t) * ((rnd.nextDouble() * 2 - 1) - y)
            val v = (y * sin(PI * t).pow(0.7) * 1.6).toFloat().coerceIn(-0.8f, 0.8f)
            voc[2 * i] = v; voc[2 * i + 1] = v
            val b = minOf(59, i * 60 / vl); if (kotlin.math.abs(v) > peaks[b]) peaks[b] = kotlin.math.abs(v)
        }
        val pm = peaks.max(); if (pm > 0f) for (i in peaks.indices) peaks[i] /= pm
        clips.add(listOf(DClip(reg(voc, vl), 2, barsOf(vl), 2f, barsOf(vl), peaks = peaks)))

        val chord = listOf(Triple(0f, 4f, 60), Triple(0f, 4f, 64), Triple(0f, 4f, 67), Triple(0f, 4f, 72))
        clips.add((1..3).map { i ->
            val notes = rel(chord, intArrayOf(0, 0, -3, -5)[i]); val fr = nf(1f)
            DClip(reg(synth(fr, abs(notes, 0), 0, 0.07f), fr), 1, barsOf(fr), i.toFloat(), barsOf(fr), notes)
        })
        clips.add((1..3).map { i ->
            val notes = rel(chord, intArrayOf(0, 0, -3, -5)[i] + 12); val fr = nf(1f)
            DClip(reg(synth(fr, abs(notes, 0), 2, 0.025f), fr), 1, barsOf(fr), i.toFloat(), barsOf(fr), notes)
        })
        return clips
    }
}
