package com.example.daw

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale

enum class G { FOLDER, SAVE, GEAR, PLAY, PAUSE, STOP, BACK, REC, SPEAKER, DRUM, SINE, GUITAR, MIC, LAYERS, POWER }

@Composable
fun Glyph(g: G, color: Color, modifier: Modifier, cut: Color = C.btn) {
    Canvas(modifier) {
        val s = size.minDimension / 24f
        scale(s, Offset.Zero) { drawGlyph(g, color, cut) }
    }
}

private fun DrawScope.drawGlyph(g: G, c: Color, cut: Color) {
    val st = Stroke(width = 1.8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    when (g) {
        G.FOLDER -> drawPath(Path().apply {
            moveTo(2f, 5f); lineTo(9f, 5f); lineTo(11.5f, 8f); lineTo(22f, 8f); lineTo(22f, 20f); lineTo(2f, 20f); close()
        }, c)
        G.SAVE -> {
            drawRoundRect(c, Offset(3f, 3f), Size(18f, 18f), CornerRadius(2f))
            drawRect(cut, Offset(7f, 3f), Size(9f, 6f))
            drawRect(cut, Offset(7f, 13f), Size(10f, 8f))
        }
        G.GEAR -> {
            for (k in 0 until 8) rotate(k * 45f, Offset(12f, 12f)) { drawRect(c, Offset(10.5f, 1.8f), Size(3f, 4.5f)) }
            drawCircle(c, 7f, Offset(12f, 12f)); drawCircle(cut, 3.2f, Offset(12f, 12f))
        }
        G.PLAY -> drawPath(Path().apply { moveTo(6f, 3.5f); lineTo(20.5f, 12f); lineTo(6f, 20.5f); close() }, c)
        G.PAUSE -> { drawRect(c, Offset(5.5f, 4f), Size(4.5f, 16f)); drawRect(c, Offset(14f, 4f), Size(4.5f, 16f)) }
        G.STOP -> drawRoundRect(c, Offset(5f, 5f), Size(14f, 14f), CornerRadius(1.5f))
        G.BACK -> {
            drawRect(c, Offset(4f, 5f), Size(2.6f, 14f))
            drawPath(Path().apply { moveTo(20f, 5f); lineTo(8.5f, 12f); lineTo(20f, 19f); close() }, c)
        }
        G.REC -> drawCircle(c, 8f, Offset(12f, 12f))
        G.SPEAKER -> {
            drawPath(Path().apply { moveTo(3f, 9f); lineTo(8f, 9f); lineTo(13f, 4.5f); lineTo(13f, 19.5f); lineTo(8f, 15f); lineTo(3f, 15f); close() }, c)
            drawArc(c, -50f, 100f, false, Offset(8f, 7f), Size(9f, 10f), style = st)
            drawArc(c, -55f, 110f, false, Offset(6f, 3.5f), Size(15f, 17f), style = st)
        }
        G.DRUM -> {
            drawOval(c, Offset(3f, 8f), Size(18f, 6f), style = st)
            drawLine(c, Offset(3f, 11f), Offset(3f, 18f), 1.8f, StrokeCap.Round)
            drawLine(c, Offset(21f, 11f), Offset(21f, 18f), 1.8f, StrokeCap.Round)
            drawArc(c, 0f, 180f, false, Offset(3f, 15f), Size(18f, 6f), style = st)
            drawLine(c, Offset(5f, 2f), Offset(11f, 8.5f), 1.8f, StrokeCap.Round)
            drawLine(c, Offset(19f, 2f), Offset(13f, 8.5f), 1.8f, StrokeCap.Round)
        }
        G.SINE -> drawPath(Path().apply {
            moveTo(2f, 12f); cubicTo(5f, 2f, 8.5f, 2f, 12f, 12f); cubicTo(15.5f, 22f, 19f, 22f, 22f, 12f)
        }, c, style = Stroke(2.2f, cap = StrokeCap.Round))
        G.GUITAR -> {
            drawLine(c, Offset(13f, 11f), Offset(20f, 4f), 2f, StrokeCap.Round)
            drawLine(c, Offset(19f, 2.5f), Offset(21.5f, 5f), 3.5f, StrokeCap.Round)
            drawCircle(c, 4.6f, Offset(8f, 16f)); drawCircle(c, 3.2f, Offset(12.2f, 11.8f))
            drawCircle(cut, 1.3f, Offset(8f, 16f))
        }
        G.MIC -> rotate(35f, Offset(12f, 12f)) {
            drawRoundRect(c, Offset(9f, 2f), Size(6f, 11f), CornerRadius(3f))
            drawArc(c, 0f, 180f, false, Offset(6.5f, 6f), Size(11f, 10f), style = st)
            drawLine(c, Offset(12f, 16f), Offset(12f, 21f), 1.8f, StrokeCap.Round)
            drawLine(c, Offset(8.5f, 21f), Offset(15.5f, 21f), 1.8f, StrokeCap.Round)
        }
        G.LAYERS -> for (k in 0 until 3) {
            val y = 1.5f + k * 5.5f
            drawPath(Path().apply { moveTo(12f, y); lineTo(22f, y + 5f); lineTo(12f, y + 10f); lineTo(2f, y + 5f); close() },
                c.copy(alpha = 0.45f + 0.275f * k))
        }
        G.POWER -> {
            drawArc(c, -55f, 290f, false, Offset(5f, 5.5f), Size(14f, 14f), style = st)
            drawLine(c, Offset(12f, 3f), Offset(12f, 12f), 2f, StrokeCap.Round)
        }
    }
}
