package com.example.daw

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.round

class Note(val beat: Float, val len: Float, val pitch: Int)

/**
 * A piece of audio on a track.  kind: 0 = drum blocks, 1 = note lines, 2 = audio waveform.
 * start / len / offset / srcLen are in bars. `offset` = how much of the source is trimmed from its beginning,
 * `srcLen` = full length of the source sample.  Every clip is backed by a sample inside the native engine.
 */
class Clip(
    val id: Int, val sampleId: Int, val kind: Int, val srcLen: Float,
    startBars: Float, lenBars: Float, offsetBars: Float = 0f,
    val notes: List<Note> = emptyList(), val peaks: FloatArray? = null
) {
    var start by mutableFloatStateOf(startBars)
    var len by mutableFloatStateOf(lenBars)
    var offset by mutableFloatStateOf(offsetBars)
    val end: Float get() = start + len
    fun copyWith(newId: Int, startBars: Float = start, lenBars: Float = len, offsetBars: Float = offset) =
        Clip(newId, sampleId, kind, srcLen, startBars, lenBars, offsetBars, notes, peaks)
}

class Track(val id: Int, nm: String, val color: Color, val glyph: G, vol: Float) {
    var name by mutableStateOf(nm)
    var volume by mutableFloatStateOf(vol)
    var pan by mutableFloatStateOf(0f)
    var mute by mutableStateOf(false)
    var solo by mutableStateOf(false)
    /** lane height in "mock px" (80 = normal) */
    var h by mutableFloatStateOf(80f)
    var clips by mutableStateOf<List<Clip>>(emptyList())
    val fx = mutableStateListOf<FxInst>()
}

/** Plain-data clip produced off the main thread (Compose state objects are only created on the main thread). */
class DClip(val sampleId: Int, val kind: Int, val srcLen: Float, val start: Float, val len: Float,
            val notes: List<Note> = emptyList(), val peaks: FloatArray? = null)

// ---- undo / redo snapshots (structure + mixer state)
private class FxSnap(val type: Int, val v: FloatArray, val on: Boolean, val bypass: Boolean, val collapsed: Boolean)
private class ClipSnap(val src: Clip, val start: Float, val len: Float, val offset: Float)
private class TrackSnap(
    val id: Int, val name: String, val color: Color, val glyph: G, val vol: Float, val pan: Float,
    val mute: Boolean, val solo: Boolean, val h: Float, val clips: List<ClipSnap>, val fx: List<FxSnap>
)
private class Snap(val tracks: List<TrackSnap>, val selected: Int, val masterFx: List<FxSnap>, val masterVol: Float, val masterMuted: Boolean)

object S {
    const val BPM = 128f
    const val MAX_TRACKS = 32
    val barSec = 4f * 60f / BPM
    private val NO_PARAMS = FloatArray(0)

    /** Display order. Each track owns an engine slot `id` (1..MAX_TRACKS) that never changes when reordering. */
    val tracks = mutableStateListOf<Track>()
    val masterFx = mutableStateListOf<FxInst>()
    var selected by mutableIntStateOf(1)
    var selClip by mutableStateOf<Clip?>(null)
    var playing by mutableStateOf(false)
    var posSec by mutableFloatStateOf(0f)
    var masterMuted by mutableStateOf(false)
    var masterVol by mutableFloatStateOf(1f)          // gain 0..1.5
    var projectName by mutableStateOf("Untitled")

    // ---- screens / panels
    var mixerOpen by mutableStateOf(false)
    var settingsOpen by mutableStateOf(false)
    var rackVisible by mutableStateOf(true)
    var fxOnMaster by mutableStateOf(true)

    // ---- timeline view
    var zoom by mutableFloatStateOf(202f)      // mock px per bar
    var scroll by mutableFloatStateOf(0f)      // first visible bar
    val vScroll = ScrollState(0)               // shared by the track headers and the timeline lanes
    var tlW = 0f; var tlK = 0f                 // timeline size, reported by the Timeline composable

    // ---- settings (persisted)
    var textScale by mutableFloatStateOf(1f)
    var snapOn by mutableStateOf(true)
    var gridBars by mutableFloatStateOf(0.25f)
    var follow by mutableStateOf(true)
    var keepAwake by mutableStateOf(true)
    var perfMode by mutableIntStateOf(0)
    var exclusive by mutableStateOf(true)
    var bursts by mutableIntStateOf(2)
    var recCompMs by mutableFloatStateOf(-1f)  // -1 = automatic latency compensation
    var recPlay by mutableStateOf(true)
    val streamInfo = mutableStateListOf(0f, 0f, 0f, 0f, 0f, 0f)

    // ---- metering
    val levels = mutableStateListOf<Float>().also { l -> repeat(35) { l.add(0f) } }

    var app: Context? = null
    fun toast(msg: String) { app?.let { Toast.makeText(it, msg, Toast.LENGTH_SHORT).show() } }

    private val clipSeq = AtomicInteger(0)
    fun newClipId() = clipSeq.incrementAndGet()
    private var trackSeq = 0
    private val palette = listOf(C.blue, C.synth, C.bass, C.vocal, C.pads, C.orange)
    private val glyphs = listOf(G.SINE, G.GUITAR, G.MIC, G.LAYERS, G.DRUM, G.SPEAKER)
    /** every sample registered in the engine, so a new / loaded project can release them */
    private val sampleIds: MutableSet<Int> = java.util.Collections.synchronizedSet(HashSet<Int>())
    fun noteSample(id: Int) { if (id > 0) sampleIds.add(id) }

    // ------------------------------------------------------------------------------------------ preferences
    fun loadPrefs(ctx: Context) {
        val p = ctx.getSharedPreferences("daw_prefs", Context.MODE_PRIVATE)
        textScale = p.getFloat("textScale", 1f).coerceIn(0.8f, 1.4f)
        snapOn = p.getBoolean("snapOn", true)
        gridBars = p.getFloat("gridBars", 0.25f)
        follow = p.getBoolean("follow", true)
        keepAwake = p.getBoolean("keepAwake", true)
        rackVisible = p.getBoolean("rackVisible", true)
        perfMode = p.getInt("perfMode", 0).coerceIn(0, 2)
        exclusive = p.getBoolean("exclusive", true)
        bursts = p.getInt("bursts", 2).coerceIn(1, 8)
        recCompMs = p.getFloat("recCompMs", -1f)
        recPlay = p.getBoolean("recPlay", true)
        projectName = p.getString("projectName", "Untitled") ?: "Untitled"
    }
    fun savePrefs() {
        val ctx = app ?: return
        ctx.getSharedPreferences("daw_prefs", Context.MODE_PRIVATE).edit()
            .putFloat("textScale", textScale).putBoolean("snapOn", snapOn).putFloat("gridBars", gridBars)
            .putBoolean("follow", follow).putBoolean("keepAwake", keepAwake).putBoolean("rackVisible", rackVisible)
            .putInt("perfMode", perfMode).putBoolean("exclusive", exclusive).putInt("bursts", bursts)
            .putFloat("recCompMs", recCompMs).putBoolean("recPlay", recPlay).putString("projectName", projectName).apply()
    }

    // ------------------------------------------------------------------------------------------ audio device
    fun refreshStreamInfo() {
        val a = FloatArray(6); NativeEngine.getStreamInfo(a)
        for (i in 0..5) streamInfo[i] = a[i]
    }
    /** Re-opens the audio output with the current settings. */
    fun applyAudioConfig(): Boolean {
        val wasPlaying = playing
        NativeEngine.closeStream()
        NativeEngine.setAudioConfig(perfMode, exclusive, bursts)
        val ok = NativeEngine.openStream()
        refreshStreamInfo()
        if (ok && wasPlaying) NativeEngine.startEngine()
        if (!ok) toast("Could not open the audio device")
        return ok
    }

    // ------------------------------------------------------------------------------------------ engine sync
    fun masterGain() = if (masterMuted) 0f else masterVol
    fun setMasterVol(v: Float) { masterVol = v.coerceIn(0f, 1.5f); NativeEngine.setMasterGain(masterGain()) }

    fun pushTrack(t: Track) {
        NativeEngine.setTrackVolume(t.id, t.volume * 1.2f)
        NativeEngine.setTrackPan(t.id, t.pan)
        NativeEngine.setTrackMute(t.id, t.mute)
        NativeEngine.setTrackSolo(t.id, t.solo)
        pushClips(t)
        pushChain(t.id)
    }
    fun pushClips(t: Track) {
        val cs = t.clips
        val ids = IntArray(cs.size) { cs[it].sampleId }
        val p = DoubleArray(cs.size * 3)
        val bs = barSec.toDouble()
        for (i in cs.indices) {
            p[3 * i] = cs[i].start * bs
            p[3 * i + 1] = cs[i].offset * bs
            p[3 * i + 2] = cs[i].len * bs
        }
        NativeEngine.setTrackClips(t.id, ids, p)
    }
    fun pushAll() {
        tracks.forEach { pushTrack(it) }
        pushChain(0)
        NativeEngine.setMasterGain(masterGain())
    }

    fun play() { NativeEngine.startEngine(); playing = true }
    fun pause() { NativeEngine.stopEngine(); playing = false }
    fun seekBars(b: Float) { val s = (b.coerceAtLeast(0f)) * barSec; NativeEngine.seek(s); posSec = s }
    fun stop() { pause(); seekBars(0f) }
    fun playFromStart() { seekBars(0f); play() }
    fun toggleMaster() { masterMuted = !masterMuted; NativeEngine.setMasterGain(masterGain()) }
    fun posBars() = posSec / barSec

    /** Keeps the playhead on screen while playing. */
    fun followPlayhead() {
        if (!follow || !playing || tlW <= 0f || tlK <= 0f) return
        val view = tlW / (zoom * tlK)
        val p = posBars()
        if (p > scroll + view * 0.92f || p < scroll) scroll = (p - view * 0.1f).coerceAtLeast(0f)
    }

    fun updateMeters(buf: FloatArray) {
        NativeEngine.getMeters(buf)
        for (i in 0 until 35) if (abs(levels[i] - buf[i]) > 0.003f) levels[i] = buf[i]
    }

    // ------------------------------------------------------------------------------------------ insert effects
    fun chainList(chain: Int): SnapshotStateList<FxInst>? = if (chain == 0) masterFx else tracks.firstOrNull { it.id == chain }?.fx
    /** Chain the FX rack is currently showing: 0 = master, otherwise the selected track's slot id. */
    fun rackChain(): Int = if (fxOnMaster || tracks.isEmpty()) 0 else tracks[selected.coerceIn(0, tracks.lastIndex)].id

    fun clearChainNative(chain: Int) { for (i in 0 until MAX_SLOTS) NativeEngine.setFx(chain, i, 0, NO_PARAMS, false) }
    fun pushChain(chain: Int) {
        val list = chainList(chain)
        for (i in 0 until MAX_SLOTS) {
            val f = list?.getOrNull(i)
            if (f != null) NativeEngine.setFx(chain, i, f.type.id, f.native(), f.active())
            else NativeEngine.setFx(chain, i, 0, NO_PARAMS, false)
        }
    }
    fun addFx(chain: Int, typeId: Int) {
        val l = chainList(chain) ?: return
        if (l.size >= MAX_SLOTS) { toast("Maximum $MAX_SLOTS effects per chain"); return }
        checkpoint(); l.add(FxInst(Fx.byId(typeId))); pushChain(chain)
    }
    fun removeFx(chain: Int, idx: Int) {
        val l = chainList(chain) ?: return
        if (idx !in l.indices) return
        checkpoint(); l.removeAt(idx); pushChain(chain)
    }
    fun replaceFx(chain: Int, idx: Int, typeId: Int) {
        val l = chainList(chain) ?: return
        if (idx !in l.indices) return
        checkpoint(); l[idx] = FxInst(Fx.byId(typeId)); pushChain(chain)
    }
    fun moveFx(chain: Int, idx: Int, delta: Int) {
        val l = chainList(chain) ?: return
        val j = idx + delta
        if (idx !in l.indices || j !in l.indices) return
        checkpoint(); val f = l.removeAt(idx); l.add(j, f); pushChain(chain)
    }
    fun setFxValue(chain: Int, idx: Int, param: Int, value: Float) {
        val f = chainList(chain)?.getOrNull(idx) ?: return
        f.v[param] = value
        NativeEngine.setFxParams(chain, idx, f.native())
    }
    fun toggleFxPower(chain: Int, idx: Int) {
        val f = chainList(chain)?.getOrNull(idx) ?: return
        f.on = !f.on; NativeEngine.setFxActive(chain, idx, f.active())
    }
    fun toggleFxBypass(chain: Int, idx: Int) {
        val f = chainList(chain)?.getOrNull(idx) ?: return
        f.bypass = !f.bypass; NativeEngine.setFxActive(chain, idx, f.active())
    }
    fun ensureMasterDefaults() { if (masterFx.isEmpty()) { masterFx.addAll(Fx.defaultMaster()); pushChain(0) } }

    // ------------------------------------------------------------------------------------------ undo / redo
    private val undoStack = ArrayList<Snap>()
    private val redoStack = ArrayList<Snap>()
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    private fun flags() { canUndo = undoStack.isNotEmpty(); canRedo = redoStack.isNotEmpty() }
    fun clearHistory() { undoStack.clear(); redoStack.clear(); flags() }

    private fun fxSnap(f: FxInst) = FxSnap(f.type.id, FloatArray(f.v.size) { f.v[it] }, f.on, f.bypass, f.collapsed)
    private fun fxFrom(s: FxSnap) = FxInst(Fx.byId(s.type)).also { f ->
        for (i in s.v.indices) if (i < f.v.size) f.v[i] = s.v[i]
        f.on = s.on; f.bypass = s.bypass; f.collapsed = s.collapsed
    }
    private fun snapshot() = Snap(
        tracks.map { t ->
            TrackSnap(t.id, t.name, t.color, t.glyph, t.volume, t.pan, t.mute, t.solo, t.h,
                t.clips.map { ClipSnap(it, it.start, it.len, it.offset) }, t.fx.map { fxSnap(it) })
        }, selected, masterFx.map { fxSnap(it) }, masterVol, masterMuted
    )

    /** Call BEFORE every structural edit (once per drag gesture). */
    fun checkpoint() {
        undoStack.add(snapshot())
        if (undoStack.size > 60) undoStack.removeAt(0)
        redoStack.clear(); flags()
    }
    fun undo() { if (undoStack.isEmpty()) return; redoStack.add(snapshot()); restore(undoStack.removeAt(undoStack.lastIndex)); flags() }
    fun redo() { if (redoStack.isEmpty()) return; undoStack.add(snapshot()); restore(redoStack.removeAt(redoStack.lastIndex)); flags() }
    private fun restore(sn: Snap) {
        val oldIds = tracks.map { it.id }
        val list = sn.tracks.map { ts ->
            Track(ts.id, ts.name, ts.color, ts.glyph, ts.vol).also { t ->
                t.pan = ts.pan; t.mute = ts.mute; t.solo = ts.solo; t.h = ts.h
                t.clips = ts.clips.map { cs -> cs.src.copyWith(cs.src.id, cs.start, cs.len, cs.offset) }
                t.fx.addAll(ts.fx.map { fxFrom(it) })
            }
        }
        tracks.clear(); tracks.addAll(list)
        masterFx.clear(); masterFx.addAll(sn.masterFx.map { fxFrom(it) })
        masterVol = sn.masterVol; masterMuted = sn.masterMuted
        oldIds.filter { id -> list.none { it.id == id } }.forEach { NativeEngine.clearTrack(it); clearChainNative(it) }
        list.forEach { pushTrack(it) }
        pushChain(0); NativeEngine.setMasterGain(masterGain())
        selected = sn.selected.coerceIn(0, (tracks.size - 1).coerceAtLeast(0))
        selClip = null
    }

    // ------------------------------------------------------------------------------------------ tracks
    private fun freeSlot(): Int {
        for (i in 1..MAX_TRACKS) if (tracks.none { it.id == i }) return i
        return -1
    }

    fun addTrack(): Track? {
        val id = freeSlot()
        if (id < 0) { toast("Maximum $MAX_TRACKS tracks"); return null }
        checkpoint()
        val n = tracks.size
        val t = Track(id, "TRACK ${++trackSeq}", palette[n % palette.size], glyphs[n % glyphs.size], 0.7f)
        tracks.add(t)
        selected = tracks.lastIndex; selClip = null
        pushTrack(t)
        return t
    }

    fun removeTrack(t: Track) {
        val i = tracks.indexOf(t); if (i < 0) return
        checkpoint()
        NativeEngine.clearTrack(t.id); clearChainNative(t.id)
        tracks.removeAt(i)
        if (selClip != null && t.clips.any { it === selClip }) selClip = null
        selected = selected.coerceIn(0, (tracks.size - 1).coerceAtLeast(0))
    }

    fun moveTrack(t: Track, delta: Int) {
        val i = tracks.indexOf(t); val j = i + delta
        if (i < 0 || j < 0 || j >= tracks.size) return
        checkpoint()
        tracks.removeAt(i); tracks.add(j, t)
        if (selected == i) selected = j
    }

    fun duplicateTrack(t: Track) {
        val id = freeSlot()
        if (id < 0) { toast("Maximum $MAX_TRACKS tracks"); return }
        checkpoint()
        val c = Track(id, t.name + " 2", t.color, t.glyph, t.volume)
        c.pan = t.pan; c.mute = t.mute; c.solo = t.solo; c.h = t.h
        c.clips = t.clips.map { it.copyWith(newClipId()) }
        c.fx.addAll(t.fx.map { it.copy() })
        val i = tracks.indexOf(t)
        tracks.add(i + 1, c)
        selected = i + 1; selClip = null
        pushTrack(c)
    }

    fun rename(t: Track, name: String) {
        val n = name.trim().take(16)
        if (n.isEmpty() || n == t.name) return
        checkpoint(); t.name = n
    }
    fun toggleMute(t: Track) { t.mute = !t.mute; NativeEngine.setTrackMute(t.id, t.mute) }
    fun toggleSolo(t: Track) { t.solo = !t.solo; NativeEngine.setTrackSolo(t.id, t.solo) }
    fun setVolume(t: Track, v: Float) { t.volume = v.coerceIn(0f, 1f); NativeEngine.setTrackVolume(t.id, t.volume * 1.2f) }
    fun setPan(t: Track, p: Float) { t.pan = p.coerceIn(-1f, 1f); NativeEngine.setTrackPan(t.id, t.pan) }
    fun cycleHeight(t: Track) { t.h = if (t.h < 64f) 80f else if (t.h < 100f) 120f else 48f }

    fun trackOf(c: Clip): Track? = tracks.firstOrNull { tr -> tr.clips.any { it === c } }

    // ------------------------------------------------------------------------------------------ clips
    fun endBars(): Float = tracks.maxOfOrNull { t -> t.clips.maxOfOrNull { it.end } ?: 0f } ?: 0f

    fun snapBars(bars: Float): Float = if (!snapOn || gridBars <= 0f) bars else round(bars / gridBars) * gridBars

    fun addClip(t: Track, c: Clip) { checkpoint(); t.clips = t.clips + c; selClip = c; pushClips(t) }

    fun deleteClip(c: Clip) {
        val t = trackOf(c) ?: return
        checkpoint()
        t.clips = t.clips.filter { it !== c }
        if (selClip === c) selClip = null
        pushClips(t)
    }

    fun duplicateClip(c: Clip) {
        val t = trackOf(c) ?: return
        checkpoint()
        val d = c.copyWith(newClipId(), startBars = c.end)
        t.clips = t.clips + d; selClip = d; pushClips(t)
    }

    /** Cuts the clip in two at the playhead. */
    fun splitAtPlayhead(c: Clip) {
        val t = trackOf(c) ?: return
        val p = posBars()
        if (p <= c.start + 0.05f || p >= c.end - 0.05f) { toast("Move the playhead onto the clip, then tap SPLIT"); return }
        checkpoint()
        val left = c.copyWith(newClipId(), c.start, p - c.start, c.offset)
        val right = c.copyWith(newClipId(), p, c.end - p, c.offset + (p - c.start))
        t.clips = t.clips.filter { it !== c } + left + right
        selClip = right; pushClips(t)
    }

    /** Live update while dragging (the caller has already called checkpoint()). */
    fun moveClip(c: Clip, newStart: Float, target: Track) {
        c.start = newStart.coerceAtLeast(0f)
        val from = trackOf(c)
        if (from != null && from !== target) {
            from.clips = from.clips.filter { it !== c }
            target.clips = target.clips + c
            pushClips(from); pushClips(target)
            selected = tracks.indexOf(target)
        } else pushClips(target)
    }

    fun clipsChanged(c: Clip) { trackOf(c)?.let { pushClips(it) } }

    // ------------------------------------------------------------------------------------------ recording
    var recording by mutableStateOf(false)
    var recSec by mutableFloatStateOf(0f)
    private var recTrack: Track? = null
    private var recBar = 0f
    private var recStartedPlay = false

    fun startRecording(): Boolean {
        if (recording) return true
        if (tracks.isEmpty() && addTrack() == null) return false
        recTrack = tracks[selected.coerceIn(0, tracks.lastIndex)]
        recBar = posBars()
        if (!NativeEngine.startRecording()) { recTrack = null; toast("Cannot open the microphone"); return false }
        recording = true; recSec = 0f
        recStartedPlay = recPlay && !playing
        if (recStartedPlay) play()
        return true
    }

    fun stopRecording() {
        if (!recording) return
        recording = false
        val sid = NativeEngine.stopRecording(recCompMs)
        if (recStartedPlay) pause()
        val t = recTrack; recTrack = null
        if (sid <= 0 || t == null || tracks.none { it === t }) { toast("Nothing was recorded"); return }
        noteSample(sid)
        val frames = NativeEngine.sampleFrames(sid); val sr = NativeEngine.sampleRate(sid)
        if (frames <= 0 || sr <= 0) return
        val bars = frames.toFloat() / sr / barSec
        val pk = FloatArray(240); NativeEngine.samplePeaks(sid, pk)
        addClip(t, Clip(newClipId(), sid, 2, bars, recBar, bars, 0f, peaks = pk))
        toast("Recorded %.1f s (latency %.0f ms)".format(frames.toFloat() / sr, NativeEngine.lastLatencyMs()))
    }

    // ------------------------------------------------------------------------------------------ project lifecycle
    /** Removes everything (tracks, effects, samples, history). The caller rebuilds the project afterwards. */
    fun resetProject() {
        if (recording) stopRecording()
        pause(); seekBars(0f)
        for (t in tracks.toList()) { NativeEngine.clearTrack(t.id); clearChainNative(t.id) }
        tracks.clear(); selClip = null; selected = 0
        clearChainNative(0); masterFx.clear()
        masterVol = 1f; masterMuted = false
        clearHistory()
        synchronized(sampleIds) { sampleIds.forEach { NativeEngine.releaseSample(it) }; sampleIds.clear() }
        trackSeq = 0; scroll = 0f
    }

    fun newProject(name: String = "Untitled") {
        resetProject()
        projectName = name
        masterFx.addAll(Fx.defaultMaster())
        addTrack()
        clearHistory()
        pushAll()
    }

    fun usedSampleIds(): List<Int> = tracks.flatMap { t -> t.clips.map { it.sampleId } }.distinct()
    fun bumpTrackSeq(n: Int) { if (n > trackSeq) trackSeq = n }
    fun colorIndex(n: Int) = palette[n % palette.size]

    /** Creates the demo project (once). */
    fun loadDemo(demo: List<List<DClip>>) {
        if (tracks.isNotEmpty()) return
        val defs = listOf(
            Track(1, "DRUM KIT", C.blue, G.DRUM, 0.69f),
            Track(2, "SYNTH LEAD", C.synth, G.SINE, 0.57f),
            Track(3, "BASS", C.bass, G.GUITAR, 0.66f),
            Track(4, "VOCAL FX", C.vocal, G.MIC, 0.54f),
            Track(5, "PADS", C.pads, G.LAYERS, 0.64f),
            Track(6, "PADS 2", C.pads, G.SPEAKER, 0.62f)
        )
        defs.forEachIndexed { i, t ->
            t.clips = demo.getOrElse(i) { emptyList() }.map { Clip(newClipId(), it.sampleId, it.kind, it.srcLen, it.start, it.len, 0f, it.notes, it.peaks) }
            tracks.add(t); pushTrack(t)
        }
        trackSeq = defs.size
        selected = 1
    }

    /** Decodes a file and drops it on track `t` at `atBar`. */
    suspend fun loadAudio(ctx: Context, t: Track, uri: Uri, atBar: Float) {
        try {
            class Res(val peaks: FloatArray, val sampleId: Int, val sec: Float)
            val res = withContext(Dispatchers.Default) {
                val pcm = AudioDecoder.decode(ctx, uri)
                val bins = 240
                val pk = FloatArray(bins)
                val per = maxOf(1, pcm.frames / bins)
                for (i in 0 until pcm.frames) {
                    val b = minOf(bins - 1, i / per)
                    val v = maxOf(abs(pcm.data[2 * i]), abs(pcm.data[2 * i + 1]))
                    if (v > pk[b]) pk[b] = v
                }
                val mx = pk.max()
                if (mx > 0f) for (i in pk.indices) pk[i] /= mx
                Res(pk, NativeEngine.registerSample(pcm.data, pcm.frames, pcm.sampleRate), pcm.frames.toFloat() / pcm.sampleRate)
            }
            if (res.sampleId <= 0) { Toast.makeText(ctx, "Could not load audio", Toast.LENGTH_LONG).show(); return }
            noteSample(res.sampleId)
            if (tracks.none { it === t }) { toast("The track was removed"); return }
            val bars = res.sec / barSec
            addClip(t, Clip(newClipId(), res.sampleId, 2, bars, snapBars(atBar).coerceAtLeast(0f), bars, 0f, peaks = res.peaks))
        } catch (e: Throwable) {
            CrashLog.record("loadAudio", e)
            Toast.makeText(ctx, "Load error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
