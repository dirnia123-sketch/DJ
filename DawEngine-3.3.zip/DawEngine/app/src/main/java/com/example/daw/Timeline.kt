package com.example.daw

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import kotlin.coroutines.cancellation.CancellationException
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

private const val RULER = 41f          // mock px
private const val MIN_LEN = 0.05f      // bars
private const val MIN_ZOOM = 40f
private const val MAX_ZOOM = 900f

// hit zones
private const val Z_RULER = 0
private const val Z_BODY = 1
private const val Z_LEFT = 2
private const val Z_RIGHT = 3
private const val Z_EMPTY = 4
private const val Z_NONE = 5

private class Hit(val zone: Int, val lane: Int, val clip: Clip?)

private fun hitTest(x: Float, y: Float, k: Float): Hit {
    val rulerH = RULER * k
    if (y < rulerH) return Hit(Z_RULER, -1, null)
    val barW = S.zoom * k
    var top = rulerH - S.vScroll.value
    for (i in S.tracks.indices) {
        val t = S.tracks[i]
        val h = t.h * k
        if (y >= top && y < top + h) {
            for (c in t.clips.asReversed()) {
                val x0 = (c.start - S.scroll) * barW; val w = c.len * barW
                if (x >= x0 && x <= x0 + w) {
                    val edge = min(26f * k, w / 3f)
                    val z = if (x < x0 + edge) Z_LEFT else if (x > x0 + w - edge) Z_RIGHT else Z_BODY
                    return Hit(z, i, c)
                }
            }
            return Hit(Z_EMPTY, i, null)
        }
        top += h
    }
    return Hit(Z_NONE, -1, null)
}

/** Lane index under y, or -1 when y is above / below every lane. */
private fun laneAt(y: Float, k: Float): Int {
    var top = RULER * k - S.vScroll.value
    for (i in S.tracks.indices) {
        val h = S.tracks[i].h * k
        if (y >= top && y < top + h) return i
        top += h
    }
    return -1
}

/** coerceIn that never throws when the range is empty (tiny clips). */
private fun safeClamp(v: Float, lo: Float, hi: Float): Float = if (hi < lo) lo else v.coerceIn(lo, hi)

private fun clampScroll(widthPx: Float, k: Float) {
    val view = widthPx / (S.zoom * k)
    S.scroll = S.scroll.coerceIn(0f, max(0f, S.endBars() + 8f - view))
}

private fun zoomAround(factor: Float, cx: Float, k: Float) {
    val barAt = S.scroll + cx / (S.zoom * k)
    S.zoom = (S.zoom * factor).coerceIn(MIN_ZOOM, MAX_ZOOM)
    S.scroll = barAt - cx / (S.zoom * k)
}

private const val M_NONE = 0
private const val M_SEEK = 1
private const val M_PAN = 2
private const val M_MOVE = 3
private const val M_TRIM_L = 4
private const val M_TRIM_R = 5

/**
 * Ruler + lanes + clips + playhead.
 *  - tap ruler / drag ruler: move the playhead          - tap clip: select      - tap lane: select track
 *  - drag clip body: move (also to other tracks)        - drag clip edge: trim  - double-tap empty lane: add audio
 *  - drag empty space: scroll (both directions)         - pinch: zoom           - two fingers: scroll
 * Layout units are "mock px" (ruler 41, lane 80 by default); the bar width follows S.zoom.
 */
@Composable
fun Timeline(modifier: Modifier, onAddAudio: (track: Int, bar: Float) -> Unit) {
    val tm = rememberTextMeasurer()
    val addCb by rememberUpdatedState(onAddAudio)
    val lastTap = remember { longArrayOf(0L, -1L) }   // [time, lane]
    Canvas(
        modifier.onSizeChanged { S.tlW = it.width.toFloat(); S.tlK = it.height / 630f }.pointerInput(Unit) {
            awaitEachGesture {
              try {
                val down = awaitFirstDown(requireUnconsumed = false)
                val k = size.height / 630f
                val width = size.width.toFloat()
                val slop = viewConfiguration.touchSlop
                val hit = hitTest(down.position.x, down.position.y, k)
                val mode = when (hit.zone) {
                    Z_RULER -> M_SEEK
                    Z_BODY -> M_MOVE
                    Z_LEFT -> M_TRIM_L
                    Z_RIGHT -> M_TRIM_R
                    else -> M_PAN
                }
                val clip = hit.clip
                val origStart = clip?.start ?: 0f
                val origLen = clip?.len ?: 0f
                val origOff = clip?.offset ?: 0f
                val origEnd = origStart + origLen
                val grab = (S.scroll + down.position.x / (S.zoom * k)) - origStart   // where inside the clip we touched
                var moved = false
                var pinch = false
                var totalDx = 0f; var totalDy = 0f

                do {
                    val event = awaitPointerEvent()
                    val pressed = event.changes.count { it.pressed }
                    if (pressed >= 2) {
                        pinch = true; moved = true
                        val zoom = event.calculateZoom()
                        val pan = event.calculatePan()
                        val c = event.calculateCentroid()
                        if (zoom != 1f) zoomAround(zoom, c.x, k)
                        S.scroll -= pan.x / (S.zoom * k)
                        clampScroll(width, k)
                        S.vScroll.dispatchRawDelta(-pan.y)
                        event.changes.forEach { it.consume() }
                    } else if (!pinch) {
                        val ch = event.changes.firstOrNull { it.id == down.id } ?: event.changes.first()
                        if (ch.pressed) {
                            val dx = ch.position.x - ch.previousPosition.x
                            val dy = ch.position.y - ch.previousPosition.y
                            totalDx += dx; totalDy += dy
                            if (!moved && (abs(totalDx) > slop || abs(totalDy) > slop)) {
                                moved = true
                                if (clip != null && (mode == M_MOVE || mode == M_TRIM_L || mode == M_TRIM_R)) {
                                    S.checkpoint()          // one undo step per drag
                                    S.selClip = clip
                                    if (hit.lane >= 0) S.selected = hit.lane
                                }
                            }
                            if (moved) {
                                val barW = S.zoom * k
                                val barAtFinger = S.scroll + ch.position.x / barW
                                when (mode) {
                                    M_SEEK -> S.seekBars(barAtFinger)
                                    M_PAN -> {
                                        S.scroll -= dx / barW
                                        clampScroll(width, k)
                                        S.vScroll.dispatchRawDelta(-dy)
                                    }
                                    M_MOVE -> if (clip != null) {
                                        val lane = laneAt(ch.position.y, k)
                                        val target = if (lane in S.tracks.indices) S.tracks[lane] else (S.trackOf(clip) ?: S.tracks.first())
                                        S.moveClip(clip, S.snapBars(barAtFinger - grab), target)
                                    }
                                    M_TRIM_L -> if (clip != null) {
                                        val ns = safeClamp(S.snapBars(barAtFinger), origStart - origOff, origEnd - MIN_LEN).coerceAtLeast(0f)
                                        val d = ns - origStart
                                        clip.start = ns; clip.offset = origOff + d; clip.len = origLen - d
                                        S.clipsChanged(clip)
                                    }
                                    M_TRIM_R -> if (clip != null) {
                                        val ne = safeClamp(S.snapBars(barAtFinger), origStart + MIN_LEN, origStart + (clip.srcLen - origOff))
                                        clip.len = ne - origStart
                                        S.clipsChanged(clip)
                                    }
                                }
                                ch.consume()
                            }
                        }
                    }
                } while (event.changes.any { it.pressed })

                if (!moved) {   // ---- a tap
                    val bar = S.scroll + down.position.x / (S.zoom * k)
                    when {
                        hit.zone == Z_RULER -> S.seekBars(bar)
                        hit.clip != null -> { S.selClip = hit.clip; S.selected = hit.lane }
                        hit.zone == Z_EMPTY -> {
                            S.selClip = null; S.selected = hit.lane
                            val now = System.currentTimeMillis()
                            if (now - lastTap[0] < 350L && lastTap[1] == hit.lane.toLong()) {
                                addCb(hit.lane, bar); lastTap[0] = 0L
                            } else { lastTap[0] = now; lastTap[1] = hit.lane.toLong() }
                        }
                        else -> S.selClip = null
                    }
                }
              } catch (c: CancellationException) {
                throw c
              } catch (e: Exception) {
                CrashLog.record("timeline gesture", e)
              }
            }
        }
    ) {
        val k = size.height / 630f
        if (!(k > 0f) || !(S.zoom > 0f) || !(size.width > 0f)) return@Canvas
        val barW = S.zoom * k; val rulerH = RULER * k
        val scroll = S.scroll
        val vs = S.vScroll.value.toFloat()
        val line = max(1f, 1.5f * k)

        drawRect(Color(0xFF14181C), Offset.Zero, size)

        // ---- lanes, grid, clips (clipped so they slide under the ruler)
        clipRect(top = rulerH) {
            var y = rulerH - vs
            S.tracks.forEachIndexed { r, t ->
                val h = t.h * k
                if (y + h >= rulerH && y <= size.height)
                    drawRect(if (r == S.selected) Color(0xFF1B2229) else C.lane, Offset(0f, y), Size(size.width, h - 2f * k))
                y += h
            }
            val lanesBottom = min(size.height, y)

            val perBar = if (barW > 120f * k) 4 else 1
            var s = floor(scroll * perBar).toInt()
            while (true) {
                val x = (s / perBar.toFloat() - scroll) * barW
                if (x > size.width) break
                drawLine(if (s % perBar == 0) C.gridBar else C.grid, Offset(x, rulerH), Offset(x, lanesBottom), line)
                s++
            }

            y = rulerH - vs
            S.tracks.forEach { t ->
                val h = t.h * k
                if (y + h >= rulerH && y <= size.height) {
                    val y0 = y + 2f * k; val ch = h - 6f * k
                    for (c in t.clips) {
                        val x0 = (c.start - scroll) * barW; val w = c.len * barW
                        if (x0 + w < 0f || x0 > size.width) continue
                        drawClip(c, if (t.mute) t.color.copy(alpha = 0.4f) else t.color, x0, y0, w, ch, k, barW)
                        if (c === S.selClip) drawSelection(x0, y0, w, ch, k)
                    }
                }
                y += h
            }
        }

        // ---- ruler (drawn after the lanes so it always stays on top)
        drawRect(Color(0xFF12161A), Offset.Zero, Size(size.width, rulerH))
        val sub = if (barW > 120f * k) 8 else 2
        val every = if (barW < 70f * k) 4 else if (barW < 120f * k) 2 else 1
        var e = floor(scroll * sub).toInt()
        while (true) {
            val x = (e / sub.toFloat() - scroll) * barW
            if (x > size.width) break
            val isBar = e % sub == 0
            drawLine(C.dim, Offset(x, rulerH - (if (isBar) 16f else 8f) * k), Offset(x, rulerH), line)
            if (isBar && (e / sub) % every == 0) drawText(tm, "${e / sub + 1}", Offset(x + 6f * k, 3f * k),
                TextStyle(color = C.text, fontSize = (17f * k).toSp(), fontWeight = FontWeight.Medium))
            e++
        }

        if (S.tracks.isEmpty())
            drawText(tm, "Tap + TRACK to start", Offset(24f * k, rulerH + 24f * k),
                TextStyle(color = C.dim, fontSize = (20f * k).toSp()))

        val px = (S.posSec / S.barSec - scroll) * barW
        if (px > -4f && px < size.width) {
            drawLine(C.orange, Offset(px, 0f), Offset(px, size.height), max(2f, 2.5f * k))
            drawCircle(C.orange, 9f * k, Offset(px, 30f * k))
        }
    }
}

private fun DrawScope.drawSelection(x0: Float, y0: Float, w: Float, h: Float, k: Float) {
    drawRoundRect(Color.White, Offset(x0 + 1f * k, y0), Size(w - 2f * k, h), CornerRadius(6f * k), style = Stroke(max(2f, 2.5f * k)))
    val hw = min(7f * k, w / 6f); val hh = h * 0.5f
    drawRoundRect(Color.White, Offset(x0 + 3f * k, y0 + (h - hh) / 2f), Size(hw, hh), CornerRadius(3f * k))
    drawRoundRect(Color.White, Offset(x0 + w - 3f * k - hw, y0 + (h - hh) / 2f), Size(hw, hh), CornerRadius(3f * k))
}

private fun DrawScope.drawClip(c: Clip, col: Color, x0: Float, y0: Float, w: Float, h: Float, k: Float, barW: Float) {
    val rr = CornerRadius(6f * k)
    when (c.kind) {
        0 -> {  // drum blocks
            val n = (c.len * 6f).toInt()
            for (j in 0 until n) {
                val bx = x0 + j * barW / 6f
                drawRoundRect(if (j % 3 == 1) lerp(col, Color.Black, 0.18f) else col,
                    Offset(bx + 1f * k, y0), Size(barW / 6f - 2f * k, h), CornerRadius(4f * k))
            }
        }
        1 -> {  // note lines
            drawRoundRect(col, Offset(x0 + 1f * k, y0), Size(w - 2f * k, h), rr)
            if (c.notes.isNotEmpty()) {
                val lo = c.notes.minOf { it.pitch }; val hi = c.notes.maxOf { it.pitch }
                val span = max(6, hi - lo).toFloat()
                val offBeats = c.offset * 4f; val lenBeats = c.len * 4f
                for (n in c.notes) {
                    val b = n.beat - offBeats
                    if (b + n.len <= 0f || b >= lenBeats) continue   // note is trimmed away
                    val nx = x0 + max(0f, b) * barW / 4f
                    val ny = y0 + 10f * k + (hi - n.pitch) / span * (h - 24f * k)
                    val nw = (min(b + n.len, lenBeats) - max(0f, b)) * barW / 4f
                    drawRoundRect(Color.Black.copy(alpha = 0.55f), Offset(nx, ny), Size(max(2f, nw - 2f * k), 4.5f * k), CornerRadius(2f * k))
                }
            }
        }
        else -> {  // audio waveform
            drawRoundRect(col, Offset(x0 + 1f * k, y0), Size(w - 2f * k, h), rr)
            val pk = c.peaks ?: return
            val step = max(2f, 4f * k)
            var x = 0f
            while (x < w - 4f * k) {
                val src = ((c.offset + (x / w) * c.len) / c.srcLen).coerceIn(0f, 1f)
                val a = pk[(src * pk.size).toInt().coerceIn(0, pk.size - 1)] * (h * 0.46f)
                drawLine(Color.Black.copy(alpha = 0.55f), Offset(x0 + x + 3f * k, y0 + h / 2 - a), Offset(x0 + x + 3f * k, y0 + h / 2 + a), max(1.5f, 2.4f * k))
                x += step
            }
        }
    }
}
