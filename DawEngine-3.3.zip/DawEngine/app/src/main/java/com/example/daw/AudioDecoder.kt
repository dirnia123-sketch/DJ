package com.example.daw

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.max

/** Decodes WAV / MP3 / AAC / OGG / FLAC to interleaved stereo float using Android's codecs. */
object AudioDecoder {
    private const val MAX_MINUTES = 5
    /** data.size may exceed frames * 2 (no trailing copy, saves memory); always use `frames`. */
    class Pcm(val data: FloatArray, val frames: Int, val sampleRate: Int)

    fun decode(ctx: Context, uri: Uri): Pcm {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var trackIdx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { trackIdx = i; fmt = f; break }
            }
            require(trackIdx >= 0 && fmt != null) { "No audio track found" }
            ex.selectTrack(trackIdx)

            var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0)
            codec.start()

            var data = FloatArray(1 shl 20)
            var count = 0
            val maxFloats = MAX_MINUTES * 60L * sr * 2L   // keeps memory bounded (decoded audio is float stereo)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi >= 0) {
                    val buf = codec.getOutputBuffer(oi)!!
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    val sb = buf.order(ByteOrder.nativeOrder()).asShortBuffer()
                    val tmp = ShortArray(sb.remaining())
                    sb.get(tmp)
                    val frames = tmp.size / ch
                    if (count + 2 * frames > data.size) data = data.copyOf(max(data.size * 2, count + 2 * frames))
                    for (f in 0 until frames) {
                        val l = tmp[f * ch] / 32768f
                        val r = if (ch > 1) tmp[f * ch + 1] / 32768f else l
                        data[count++] = l
                        data[count++] = r
                    }
                    codec.releaseOutputBuffer(oi, false)
                    require(count <= maxFloats) { "File is too long (max $MAX_MINUTES minutes)" }
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            require(count > 0) { "File is empty" }
            return Pcm(data, count / 2, sr)   // data may be larger than count: callers must use `frames`
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            codec?.release()
            ex.release()
        }
    }
}
