package com.example.daw

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import kotlin.math.cos
import kotlin.math.sin

/** Rotary knob, value 0..1, vertical drag. */
@Composable
fun Knob(value: Float, onChange: (Float) -> Unit, color: Color, size: Dp, modifier: Modifier = Modifier) {
    val cur = rememberUpdatedState(value)
    val cb = rememberUpdatedState(onChange)
    Canvas(
        modifier.size(size).pointerInput(Unit) {
            detectDragGestures { ch, d -> ch.consume(); cb.value((cur.value - d.y / 240f).coerceIn(0f, 1f)) }
        }
    ) {
        val w = this.size.minDimension; val sw = w * 0.11f
        val tl = Offset(sw / 2, sw / 2); val sz = Size(w - sw, w - sw)
        drawArc(Color(0xFF12161A), 135f, 270f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
        drawArc(color, 135f, 270f * value.coerceIn(0f, 1f), false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
        val c = Offset(w / 2, w / 2)
        drawCircle(Brush.radialGradient(listOf(Color(0xFF59636C), Color(0xFF1C2227)), c, w * 0.34f), w * 0.33f, c)
        val a = Math.toRadians((135f + 270f * value.coerceIn(0f, 1f)).toDouble())
        val dx = cos(a).toFloat(); val dy = sin(a).toFloat()
        drawLine(Color(0xFFF1F4F6), c + Offset(dx, dy) * (w * 0.1f), c + Offset(dx, dy) * (w * 0.3f), w * 0.05f, StrokeCap.Round)
    }
}

@Composable
fun KnobCol(label: String, valueText: String, v: Float, color: Color, modifier: Modifier = Modifier,
            knobSize: Dp = pd(40f), onChange: (Float) -> Unit) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = C.dim, fontSize = fs(12.5f), maxLines = 1, textAlign = TextAlign.Center)
        Knob(v, onChange, color, knobSize)
        Text(valueText, color = C.text, fontSize = fs(12.5f), maxLines = 1)
    }
}

/** Track volume slider: coloured fill + round thumb. */
@Composable
fun TrackSlider(value: Float, color: Color, modifier: Modifier, onChange: (Float) -> Unit) {
    val cb = rememberUpdatedState(onChange)
    fun toV(x: Float, w: Float, h: Float): Float { val r = h * 0.46f; return ((x - r) / (w - 2 * r)).coerceIn(0f, 1f) }
    Canvas(
        modifier
            .pointerInput(Unit) { detectTapGestures { o -> cb.value(toV(o.x, size.width.toFloat(), size.height.toFloat())) } }
            .pointerInput(Unit) { detectDragGestures { ch, _ -> ch.consume(); cb.value(toV(ch.position.x, size.width.toFloat(), size.height.toFloat())) } }
    ) {
        val h = size.height; val th = h * 0.26f; val cy = h / 2f; val r = h * 0.46f
        val x = r + (size.width - 2 * r) * value
        drawRoundRect(Color(0xFF2B333A), Offset(r, cy - th / 2), Size(size.width - 2 * r, th), CornerRadius(th / 2))
        drawRoundRect(color, Offset(r, cy - th / 2), Size((x - r).coerceAtLeast(0f), th), CornerRadius(th / 2))
        drawCircle(Color(0xFFE8EDF1), r, Offset(x, cy))
        drawCircle(color, r * 0.6f, Offset(x, cy))
    }
}

@Composable
fun MiniBtn(text: String, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(pd(6f))
    Box(
        modifier.clip(shape).background(if (active) Color(0xFF223B2B) else Color(0xFF2A3238))
            .border(pd(1.5f), if (active) C.green.copy(alpha = 0.8f) else Color(0xFF3A444C), shape)
            .clickable(onClick = onClick).padding(horizontal = pd(8f), vertical = pd(5f)),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (active) C.green else C.text, fontSize = fs(12.5f), fontWeight = FontWeight.SemiBold, maxLines = 1) }
}

@Composable
fun Stepper(text: String, modifier: Modifier = Modifier, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(pd(6f))).background(Color(0xFF11161A)), verticalAlignment = Alignment.CenterVertically) {
        Text("◂", color = C.text, fontSize = fs(15f), modifier = Modifier.clickable(onClick = onMinus).padding(horizontal = pd(8f), vertical = pd(3f)))
        Text(text, color = C.text, fontSize = fs(13f), maxLines = 1, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
        Text("▸", color = C.text, fontSize = fs(15f), modifier = Modifier.clickable(onClick = onPlus).padding(horizontal = pd(8f), vertical = pd(3f)))
    }
}
