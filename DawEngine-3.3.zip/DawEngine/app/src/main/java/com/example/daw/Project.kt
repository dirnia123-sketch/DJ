package com.example.daw

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.min

/**
 * Project files (*.dawproj) are zip archives: project.json (tracks, clips, effects, mixer) + audio/<id>.wav (16-bit).
 * They live in the app's private storage and can be exported / imported through the system file picker.
 */
object Project {
    const val EXT = "dawproj"
    const val AUTOSAVE = "_autosave"

    fun dir(ctx: Context): File = File(ctx.filesDir, "projects").also { it.mkdirs() }
    fun list(ctx: Context): List<File> = dir(ctx).listFiles { f -> f.extension == EXT }?.sortedByDescending { it.lastModified() } ?: emptyList()
    private fun safe(n: String) = n.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").take(40).ifEmpty { "Untitled" }
    fun fileFor(ctx: Context, name: String) = File(dir(ctx), safe(name) + "." + EXT)

    // ------------------------------------------------------------------------------------------ writing
    private fun fxJson(f: FxInst) = JSONObject().put("t", f.type.id)
        .put("v", JSONArray().also { a -> f.v.forEach { a.put(it.toDouble()) } })
        .put("on", f.on).put("bp", f.bypass).put("c", f.collapsed)

    /** Must be called on the main thread (reads Compose state). */
    private fun snapshotJson(name: String): Pair<String, List<Int>> {
        val root = JSONObject().put("v", 1).put("name", name).put("bpm", S.BPM.toDouble())
            .put("masterVol", S.masterVol.toDouble()).put("masterMuted", S.masterMuted)
            .put("masterFx", JSONArray().also { a -> S.masterFx.forEach { a.put(fxJson(it)) } })
        val ta = JSONArray()
        for (t in S.tracks) {
            val ca = JSONArray()
            for (c in t.clips) {
                ca.put(JSONObject().put("s", c.sampleId).put("k", c.kind).put("st", c.start.toDouble()).put("ln", c.len.toDouble())
                    .put("of", c.offset.toDouble()).put("sl", c.srcLen.toDouble())
                    .put("n", JSONArray().also { na -> c.notes.forEach { n -> na.put(JSONArray().put(n.beat.toDouble()).put(n.len.toDouble()).put(n.pitch)) } }))
            }
            ta.put(JSONObject().put("slot", t.id).put("name", t.name).put("color", t.color.toArgb()).put("glyph", t.glyph.name)
                .put("vol", t.volume.toDouble()).put("pan", t.pan.toDouble()).put("mute", t.mute).put("solo", t.solo).put("h", t.h.toDouble())
                .put("fx", JSONArray().also { a -> t.fx.forEach { a.put(fxJson(it)) } }).put("clips", ca))
        }
        root.put("tracks", ta)
        return root.toString() to S.usedSampleIds()
    }

    private fun writeWav(out: OutputStream, data: FloatArray, frames: Int, sr: Int) {
        val bytes = frames * 4
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt(36 + bytes).put("WAVE".toByteArray()).put("fmt ".toByteArray()).putInt(16)
            .putShort(1).putShort(2).putInt(sr).putInt(sr * 4).putShort(4).putShort(16).put("data".toByteArray()).putInt(bytes)
        out.write(h.array())
        val chunk = 16384
        val buf = ByteBuffer.allocate(chunk * 4).order(ByteOrder.LITTLE_ENDIAN)
        var f = 0
        while (f < frames) {
            val n = min(chunk, frames - f)
            buf.clear()
            for (i in 0 until n * 2) buf.putShort((data[f * 2 + i].coerceIn(-1f, 1f) * 32767f).toInt().toShort())
            out.write(buf.array(), 0, n * 4)
            f += n
        }
    }

    private fun writeZip(target: File, json: String, ids: List<Int>): Boolean {
        val tmp = File(target.parentFile, target.name + ".tmp")
        return try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { z ->
                z.setLevel(Deflater.BEST_SPEED)
                z.putNextEntry(ZipEntry("project.json")); z.write(json.toByteArray(Charsets.UTF_8)); z.closeEntry()
                for (id in ids) {
                    val frames = NativeEngine.sampleFrames(id); val sr = NativeEngine.sampleRate(id)
                    if (frames <= 0 || sr <= 0) continue
                    val data = FloatArray(frames * 2)
                    if (!NativeEngine.copySample(id, data)) continue
                    z.putNextEntry(ZipEntry("audio/$id.wav")); writeWav(z, data, frames, sr); z.closeEntry()
                }
            }
            if (target.exists()) target.delete()
            tmp.renameTo(target)
        } catch (e: Throwable) { CrashLog.record("project save", e); tmp.delete(); false }
    }

    /** Call from the main thread. */
    suspend fun save(ctx: Context, name: String): Boolean {
        val (json, ids) = snapshotJson(name)
        return withContext(Dispatchers.IO) { writeZip(fileFor(ctx, name), json, ids) }
    }

    /** Called when the app goes to the background: a safety copy in a background thread. */
    fun autoSave(ctx: Context) {
        if (S.tracks.isEmpty()) return
        try {
            val (json, ids) = snapshotJson(AUTOSAVE)
            val f = fileFor(ctx, AUTOSAVE)
            Thread { writeZip(f, json, ids) }.start()
        } catch (e: Throwable) { CrashLog.record("autosave", e) }
    }

    // ------------------------------------------------------------------------------------------ reading
    private fun readWav(b: ByteArray): Triple<FloatArray, Int, Int>? {   // data, frames, sampleRate
        if (b.size < 44 || String(b, 0, 4) != "RIFF") return null
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        var pos = 12; var sr = 44100; var ch = 2; var bits = 16
        while (pos + 8 <= b.size) {
            val id = String(b, pos, 4); val size = bb.getInt(pos + 4)
            if (id == "fmt ") { ch = bb.getShort(pos + 10).toInt(); sr = bb.getInt(pos + 12); bits = bb.getShort(pos + 22).toInt() }
            if (id == "data") {
                if (bits != 16 || ch !in 1..2) return null
                val start = pos + 8; val n = min(size, b.size - start); val frames = n / (2 * ch)
                val out = FloatArray(frames * 2)
                for (i in 0 until frames) {
                    val l = bb.getShort(start + i * 2 * ch) / 32768f
                    val r = if (ch == 2) bb.getShort(start + i * 4 + 2) / 32768f else l
                    out[2 * i] = l; out[2 * i + 1] = r
                }
                return Triple(out, frames, sr)
            }
            pos += 8 + size + (size and 1)
        }
        return null
    }

    private fun fxFrom(o: JSONObject): FxInst? {
        val t = Fx.all.firstOrNull { it.id == o.optInt("t", -1) } ?: return null
        val inst = FxInst(t)
        val a = o.optJSONArray("v")
        if (a != null) for (i in 0 until min(a.length(), inst.v.size)) inst.v[i] = a.optDouble(i, inst.v[i].toDouble()).toFloat()
        inst.on = o.optBoolean("on", true); inst.bypass = o.optBoolean("bp", false); inst.collapsed = o.optBoolean("c", false)
        return inst
    }

    /** Decodes the file, then replaces the current project. */
    suspend fun load(file: File): Boolean {
        class Raw(val json: String, val ids: Map<Int, Int>)
        val raw: Raw? = withContext(Dispatchers.IO) {
            val ids = HashMap<Int, Int>()
            try {
                var json: String? = null
                ZipInputStream(file.inputStream().buffered()).use { z ->
                    while (true) {
                        val e = z.nextEntry ?: break
                        if (e.name == "project.json") json = String(z.readBytes(), Charsets.UTF_8)
                        else if (e.name.startsWith("audio/") && e.name.endsWith(".wav")) {
                            val old = e.name.removePrefix("audio/").removeSuffix(".wav").toIntOrNull() ?: continue
                            val w = readWav(z.readBytes()) ?: continue
                            val nid = NativeEngine.registerSample(w.first, w.second, w.third)
                            if (nid > 0) ids[old] = nid
                        }
                    }
                }
                if (json == null) { ids.values.forEach { NativeEngine.releaseSample(it) }; null } else Raw(json!!, ids)
            } catch (t: Throwable) {
                CrashLog.record("project load", t); ids.values.forEach { NativeEngine.releaseSample(it) }; null
            }
        }
        if (raw == null) return false
        return try { applyLoaded(raw.json, raw.ids); true } catch (t: Throwable) { CrashLog.record("project apply", t); false }
    }

    /** Main thread. */
    private fun applyLoaded(json: String, ids: Map<Int, Int>) {
        val root = JSONObject(json)
        S.resetProject()                                   // releases the OLD samples only; the new ones are not noted yet
        ids.values.forEach { S.noteSample(it) }
        S.projectName = root.optString("name", "Untitled")
        S.masterVol = root.optDouble("masterVol", 1.0).toFloat().coerceIn(0f, 1.5f)
        S.masterMuted = root.optBoolean("masterMuted", false)
        root.optJSONArray("masterFx")?.let { a -> for (i in 0 until min(a.length(), MAX_SLOTS)) fxFrom(a.getJSONObject(i))?.let { S.masterFx.add(it) } }
        val ta = root.optJSONArray("tracks") ?: JSONArray()
        val used = HashSet<Int>()
        for (i in 0 until min(ta.length(), S.MAX_TRACKS)) {
            val o = ta.getJSONObject(i)
            var slot = o.optInt("slot", i + 1)
            if (slot !in 1..S.MAX_TRACKS || slot in used) slot = (1..S.MAX_TRACKS).first { it !in used }
            used.add(slot)
            val glyph = try { G.valueOf(o.optString("glyph", "SINE")) } catch (e: Exception) { G.SINE }
            val t = Track(slot, o.optString("name", "TRACK ${i + 1}"), Color(o.optInt("color", S.colorIndex(i).toArgb())), glyph, o.optDouble("vol", 0.7).toFloat())
            t.pan = o.optDouble("pan", 0.0).toFloat(); t.mute = o.optBoolean("mute"); t.solo = o.optBoolean("solo")
            t.h = o.optDouble("h", 80.0).toFloat().coerceIn(40f, 140f)
            o.optJSONArray("fx")?.let { a -> for (k in 0 until min(a.length(), MAX_SLOTS)) fxFrom(a.getJSONObject(k))?.let { t.fx.add(it) } }
            val clips = ArrayList<Clip>()
            val ca = o.optJSONArray("clips") ?: JSONArray()
            for (k in 0 until ca.length()) {
                val c = ca.getJSONObject(k)
                val sid = ids[c.optInt("s", -1)] ?: continue
                val kind = c.optInt("k", 2)
                val notes = ArrayList<Note>()
                c.optJSONArray("n")?.let { na -> for (q in 0 until na.length()) { val n = na.getJSONArray(q); notes.add(Note(n.getDouble(0).toFloat(), n.getDouble(1).toFloat(), n.getInt(2))) } }
                var peaks: FloatArray? = null
                if (kind == 2) { peaks = FloatArray(240); NativeEngine.samplePeaks(sid, peaks) }
                clips.add(Clip(S.newClipId(), sid, kind, c.optDouble("sl", 1.0).toFloat(), c.optDouble("st", 0.0).toFloat(),
                    c.optDouble("ln", 1.0).toFloat(), c.optDouble("of", 0.0).toFloat(), notes, peaks))
            }
            t.clips = clips
            S.tracks.add(t)
        }
        S.bumpTrackSeq(S.tracks.size)
        S.clearHistory()
        S.selected = 0
        S.pushAll()
        S.seekBars(0f)
    }

    fun copyOut(ctx: Context, file: File, uri: android.net.Uri): Boolean = try {
        ctx.contentResolver.openOutputStream(uri)?.use { o -> file.inputStream().use { it.copyTo(o) } }; true
    } catch (e: Throwable) { CrashLog.record("export", e); false }

    fun copyIn(ctx: Context, uri: android.net.Uri): File? = try {
        val f = File(dir(ctx), "Imported_${System.currentTimeMillis() / 1000}.$EXT")
        ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { i.copyTo(it) } }
        f
    } catch (e: Throwable) { CrashLog.record("import", e); null }
}
