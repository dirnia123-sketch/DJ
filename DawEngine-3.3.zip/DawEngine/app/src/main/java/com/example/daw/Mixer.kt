package com.example.daw

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

private fun dbText(g: Float) = if (g <= 0.0005f) "-inf" else "%+.1f".format(20f * log10(g))
private fun meterFrac(v: Float): Float {   // -60 dB .. 0 dB -> 0..1
    if (v <= 0.001f) return 0f
    return ((20f * log10(v) + 60f) / 60f).coerceIn(0f, 1f)
}

/** Vertical fader: value 0..1 (top = 1). Tap or drag. The 0 dB mark is drawn at `zeroAt`. */
@Composable
private fun VFader(value: Float, color: Color, zeroAt: Float, modifier: Modifier, onChange: (Float) -> Unit) {
    val cb = rememberUpdatedState(onChange)
    fun toV(y: Float, h: Float): Float { val pad = h * 0.05f; return (1f - (y - pad) / (h - 2 * pad)).coerceIn(0f, 1f) }
    Canvas(
        modifier
            .pointerInput(Unit) { detectTapGestures { o -> cb.value(toV(o.y, size.height.toFloat())) } }
            .pointerInput(Unit) { detectDragGestures { ch, _ -> ch.consume(); cb.value(toV(ch.position.y, size.height.toFloat())) } }
    ) {
        val pad = size.height * 0.05f
        val cx = size.width / 2f
        val tw = size.width * 0.16f
        val top = pad; val bot = size.height - pad
        drawRoundRect(Color(0xFF0E1215), Offset(cx - tw / 2, top), Size(tw, bot - top), CornerRadius(tw / 2))
        val y = bot - (bot - top) * value
        drawRoundRect(color.copy(alpha = 0.8f), Offset(cx - tw / 2, y), Size(tw, bot - y), CornerRadius(tw / 2))
        val zy = bot - (bot - top) * zeroAt
        drawLine(Color(0xFF59636B), Offset(cx - size.width * 0.42f, zy), Offset(cx + size.width * 0.42f, zy), 2f)
        val kh = size.height * 0.07f; val kw = size.width * 0.78f
        drawRoundRect(Color(0xFFE8EDF1), Offset(cx - kw / 2, y - kh / 2), Size(kw, kh), CornerRadius(kh * 0.3f))
        drawLine(Color(0xFF30383F), Offset(cx - kw * 0.35f, y), Offset(cx + kw * 0.35f, y), 3f)
    }
}

@Composable
private fun Meter(vararg index: Int, modifier: Modifier) {
    Canvas(modifier.clip(RoundedCornerShape(pd(3f))).background(Color(0xFF0B0E10))) {
        val n = index.size
        val gap = size.width * 0.12f
        val w = (size.width - gap * (n + 1)) / n
        for ((k, i) in index.withIndex()) {
            val f = meterFrac(S.levels[i])
            val x = gap + k * (w + gap)
            val h = size.height * f
            val hot = size.height * meterFrac(0.89f)       // above -1 dB
            val mid = size.height * meterFrac(0.35f)       // above -9 dB
            // green / yellow / red segments
            val gTop = min(h, mid); drawRect(Color(0xFF58E07A), Offset(x, size.height - gTop), Size(w, gTop))
            if (h > mid) { val yT = min(h, hot); drawRect(Color(0xFFF5D04A), Offset(x, size.height - yT), Size(w, yT - mid)) }
            if (h > hot) drawRect(Color(0xFFE5534B), Offset(x, size.height - h), Size(w, h - hot))
        }
    }
}

@Composable
private fun StripShell(width: Float, accent: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.width(pd(width)).fillMaxHeight().padding(horizontal = pd(3f), vertical = pd(4f)).clip(RoundedCornerShape(pd(10f)))
            .background(Color(0xFF1B2126)).padding(pd(6f)),
        horizontalAlignment = Alignment.CenterHorizontally, content = content
    )
}

@Composable
private fun TrackStrip(t: Track, index: Int) {
    val selected = S.selected == index
    StripShell(116f, t.color) {
        Text(t.name, color = if (t.mute) C.dim else t.color, fontSize = fs(16f), fontWeight = FontWeight.Bold, maxLines = 1,
            modifier = Modifier.fillMaxWidth().clickable { S.selected = index }.padding(vertical = pd(2f)), textAlign = TextAlign.Center)
        Box(Modifier.fillMaxWidth().height(pd(3f)).background(if (selected) C.green else Color(0xFF1B2126)))
        Spacer(Modifier.height(pd(6f)))
        val panText = if (t.pan > 0.02f) "R%.0f".format(t.pan * 100f) else if (t.pan < -0.02f) "L%.0f".format(-t.pan * 100f) else "C"
        KnobCol("PAN", panText, (t.pan + 1f) / 2f, C.dim, Modifier.clickable { S.setPan(t, 0f) }) { S.setPan(t, it * 2f - 1f) }
        Spacer(Modifier.height(pd(4f)))
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            VFader(t.volume, t.color, 1f / 1.2f, Modifier.width(pd(52f)).fillMaxHeight()) { S.setVolume(t, it) }
            Meter(t.id - 1, modifier = Modifier.width(pd(16f)).fillMaxHeight().padding(vertical = pd(6f)))
        }
        Text(dbText(t.volume * 1.2f) + " dB", color = C.text, fontSize = fs(14f), maxLines = 1)
        Spacer(Modifier.height(pd(4f)))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(pd(4f))) {
            MiniBtn("M", t.mute, Modifier.weight(1f)) { S.toggleMute(t) }
            MiniBtn("S", t.solo, Modifier.weight(1f)) { S.toggleSolo(t) }
        }
        Spacer(Modifier.height(pd(4f)))
        MiniBtn("FX " + t.fx.size, false, Modifier.fillMaxWidth()) {
            S.selected = index; S.fxOnMaster = false; S.rackVisible = true; S.mixerOpen = false
        }
    }
}

@Composable
private fun MasterStrip() {
    StripShell(150f, C.orange) {
        Text("MASTER", color = C.orange, fontSize = fs(17f), fontWeight = FontWeight.Bold, maxLines = 1,
            modifier = Modifier.fillMaxWidth().padding(vertical = pd(2f)), textAlign = TextAlign.Center)
        Box(Modifier.fillMaxWidth().height(pd(3f)).background(C.orange))
        Spacer(Modifier.height(pd(10f)))
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            VFader(S.masterVol / 1.5f, C.orange, 1f / 1.5f, Modifier.width(pd(60f)).fillMaxHeight()) { S.setMasterVol(it * 1.5f) }
            Meter(32, 33, modifier = Modifier.width(pd(30f)).fillMaxHeight().padding(vertical = pd(6f)))
        }
        Text(dbText(S.masterGain()) + " dB", color = C.text, fontSize = fs(14f), maxLines = 1)
        Spacer(Modifier.height(pd(4f)))
        MiniBtn("MUTE", S.masterMuted, Modifier.fillMaxWidth()) { S.toggleMaster() }
        Spacer(Modifier.height(pd(4f)))
        MiniBtn("FX " + S.masterFx.size, false, Modifier.fillMaxWidth()) { S.fxOnMaster = true; S.rackVisible = true; S.mixerOpen = false }
    }
}

/** Mixer: one channel strip per track plus the master strip (volume, pan, mute, solo, level meters, effect count). */
@Composable
fun MixerScreen(modifier: Modifier) {
    Row(modifier.background(Color(0xFF12161A)).padding(pd(6f))) {
        Row(Modifier.weight(1f).fillMaxHeight().horizontalScroll(rememberScrollState())) {
            S.tracks.forEachIndexed { i, t -> TrackStrip(t, i) }
            if (S.tracks.isEmpty()) Text("No tracks yet. Close the mixer and tap + TRACK.", color = C.dim, fontSize = fs(20f), modifier = Modifier.padding(pd(24f)))
        }
        MasterStrip()
    }
}
