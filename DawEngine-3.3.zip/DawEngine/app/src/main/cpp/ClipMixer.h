#ifndef CLIP_MIXER_H
#define CLIP_MIXER_H
// Multi-clip timeline storage + mixing. No Oboe / Android dependency, so it is unit-testable on a PC.
//
// Threading model
//   control thread : addSample / removeSample / setClips / reap   (take m_)
//   audio thread   : clips(track) / audioTick() / mixClips()      (lock-free, allocation-free)
// A track's clip list is an immutable snapshot published with an atomic pointer swap. The old snapshot is
// retired and freed by the control thread only after the audio thread has finished at least one more callback.
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <vector>
#include "Reclaim.h"

constexpr int kMaxTracks = 32;

struct Sample {  // interleaved stereo float, immutable once published
    std::vector<float> data;
    int64_t frames = 0;
    int sampleRate = 44100;
};

struct ClipRef {
    const Sample *smp;
    double startSec;   // position on the timeline
    double offsetSec;  // trimmed from the start of the source
    double lenSec;     // audible length
};

struct ClipList {
    std::vector<ClipRef> clips;
    std::vector<std::shared_ptr<const Sample>> owners;  // keeps the samples alive while this snapshot is in use
    double endSec = 0.0;
};

class ClipStore {
public:
    explicit ClipStore(Reclaimer &rec) : rec_(rec) { for (auto &l : lists_) l.store(nullptr); }
    ~ClipStore() { for (auto &l : lists_) delete l.exchange(nullptr); }
    ClipStore(const ClipStore &) = delete;
    ClipStore &operator=(const ClipStore &) = delete;

    /** Returns a sample id (> 0) or 0 on failure. */
    int addSample(std::shared_ptr<const Sample> s) {
        if (!s || s->frames <= 0 || s->sampleRate <= 0) return 0;
        std::lock_guard<std::mutex> g(m_);
        int id = nextId_++;
        samples_[id] = std::move(s);
        return id;
    }

    /** Snapshots already published keep their own references, so this is always safe. */
    void removeSample(int id) {
        std::lock_guard<std::mutex> g(m_);
        samples_.erase(id);
    }

    /** Read access for project saving (control thread). */
    std::shared_ptr<const Sample> sample(int id) {
        std::lock_guard<std::mutex> g(m_);
        auto it = samples_.find(id);
        return it == samples_.end() ? nullptr : it->second;
    }

    /** params = {start, offset, len} seconds per clip. Unknown samples / empty clips are skipped. */
    bool setClips(int track, const int *ids, const double *params, int n) {
        if (track < 1 || track > kMaxTracks || n < 0) return false;
        auto *list = new ClipList();
        {
            std::lock_guard<std::mutex> g(m_);
            for (int i = 0; i < n; ++i) {
                auto it = samples_.find(ids[i]);
                if (it == samples_.end()) continue;
                const Sample *s = it->second.get();
                double start = std::max(0.0, params[3 * i]);
                double off = std::max(0.0, params[3 * i + 1]);
                double len = params[3 * i + 2];
                double srcSec = (double) s->frames / (double) s->sampleRate;
                if (off >= srcSec) continue;
                len = std::min(len, srcSec - off);
                if (len <= 1e-4) continue;
                list->owners.push_back(it->second);
                list->clips.push_back(ClipRef{s, start, off, len});
                list->endSec = std::max(list->endSec, start + len);
            }
        }
        ClipList *old = lists_[track - 1].exchange(list, std::memory_order_acq_rel);
        if (old) rec_.retire([old] { delete old; });
        return true;
    }

    void clearTrack(int track) { setClips(track, nullptr, nullptr, 0); }

    // ---- audio thread (lock-free) -------------------------------------------------------------------------
    const ClipList *clips(int track) const {
        return (track >= 1 && track <= kMaxTracks) ? lists_[track - 1].load(std::memory_order_acquire) : nullptr;
    }

private:
    Reclaimer &rec_;
    std::mutex m_;
    std::unordered_map<int, std::shared_ptr<const Sample>> samples_;
    std::atomic<ClipList *> lists_[kMaxTracks];
    int nextId_ = 1;
};

/** Adds every clip of one track that is sounding at timeline time `t` (seconds). Real-time safe. */
inline void mixClips(const ClipList *cl, double t, float &l, float &r) {
    if (!cl) return;
    constexpr double kFade = 0.0008;  // 0.8 ms edge fades remove clicks at cut points
    for (const ClipRef &c : cl->clips) {
        const double rel = t - c.startSec;
        if (rel < 0.0 || rel >= c.lenSec) continue;
        const double sp = (rel + c.offsetSec) * (double) c.smp->sampleRate;
        const int64_t i0 = (int64_t) sp;
        if (i0 + 1 >= c.smp->frames) continue;
        const float fr = (float) (sp - (double) i0);
        const float *d = c.smp->data.data() + 2 * i0;
        const float sl = d[0] + (d[2] - d[0]) * fr;
        const float sr = d[1] + (d[3] - d[1]) * fr;
        const double g = std::min(std::min(1.0, rel / kFade), std::min(1.0, (c.lenSec - rel) / kFade));
        l += sl * (float) g;
        r += sr * (float) g;
    }
}
#endif
