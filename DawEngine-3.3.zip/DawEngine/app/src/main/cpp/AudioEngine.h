#ifndef AUDIO_ENGINE_H
#define AUDIO_ENGINE_H
#include <oboe/Oboe.h>
#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <thread>
#include <vector>
#include "ClipMixer.h"
#include "FxChain.h"
#include "Recorder.h"

struct TrackParams {
    std::atomic<float> gain{0.8f};
    std::atomic<float> pan{0.f};
    std::atomic<bool> mute{false};
    std::atomic<bool> solo{false};
};

/** Layout of getMeters(): [0..kMaxTracks-1] track peaks, then masterL, masterR, input level. */
constexpr int kMeterCount = kMaxTracks + 3;

class AudioEngine : public oboe::AudioStreamDataCallback,
                    public oboe::AudioStreamErrorCallback,
                    public std::enable_shared_from_this<AudioEngine> {
public:
    AudioEngine();
    ~AudioEngine();

    // ---- output stream / configuration
    void setConfig(int perfMode, bool exclusive, int bursts);   // takes effect at the next openStream()
    bool openStream();
    void closeStream();
    /** out = {sampleRate, framesPerBurst, bufferFrames, exclusive(0/1), api(0 unknown,1 AAudio,2 OpenSL), isOpen} */
    void streamInfo(float *out, int n);

    // ---- clips / samples
    int registerSample(std::unique_ptr<Sample> s) { return clips_.addSample(std::shared_ptr<const Sample>(std::move(s))); }
    void releaseSample(int sampleId) { clips_.removeSample(sampleId); }
    std::shared_ptr<const Sample> sample(int sampleId) { return clips_.sample(sampleId); }
    bool setTrackClips(int id, const int *sampleIds, const double *params, int n) { return clips_.setClips(id, sampleIds, params, n); }
    void clearTrack(int id) { clips_.clearTrack(id); }
    TrackParams *track(int id) { return (id >= 1 && id <= kMaxTracks) ? &tracks_[id - 1] : nullptr; }

    // ---- insert effects (chain 0 = master, 1..kMaxTracks = tracks)
    bool setFx(int chain, int slot, int type, const float *p, int n, bool active) { return fx_.setSlot(chain, slot, type, p, n, active); }
    void setFxParams(int chain, int slot, const float *p, int n) { fx_.setParams(chain, slot, p, n); }
    void setFxActive(int chain, int slot, bool a) { fx_.setActive(chain, slot, a); }

    // ---- transport / master
    void setMasterGain(float g) { master_.store(g); }
    void seek(float sec) { seekReq_.store((int64_t) ((double) sec * sampleRate_.load())); }
    float position() const { return (float) ((double) posOut_.load() / sampleRate_.load()); }
    void getMeters(float *out, int n);
    std::atomic<bool> playing{false};

    // ---- recording (microphone / line input)
    bool startRecording();
    /** Returns the new sample id (0 when nothing was recorded). `compensateMs` < 0 = automatic latency compensation. */
    int stopRecording(float compensateMs);
    bool isRecording() const { return recording_.load(); }
    float recordingSeconds() const { return rec_.seconds(); }
    float lastLatencyMs() const { return lastLatencyMs_.load(); }

    oboe::DataCallbackResult onAudioReady(oboe::AudioStream *, void *, int32_t) override;
    void onErrorAfterClose(oboe::AudioStream *, oboe::Result) override;

private:
    struct InputCb;
    void closeLocked();
    void onInput(oboe::AudioStream *s, const float *in, int32_t frames);
    float estimateLatencyMs();

    std::mutex mutex_;  // stream lifecycle; never taken on the audio thread
    std::shared_ptr<oboe::AudioStream> stream_, inStream_;
    std::shared_ptr<InputCb> inCb_;
    Reclaimer rec_reclaim_;
    ClipStore clips_{rec_reclaim_};
    FxStore fx_{rec_reclaim_};
    TrackParams tracks_[kMaxTracks];

    std::atomic<float> master_{1.f};
    std::atomic<int64_t> seekReq_{-1}, posOut_{0};
    std::atomic<float> sampleRate_{48000.f};
    std::atomic<float> trackPk_[kMaxTracks], mPkL_{0.f}, mPkR_{0.f}, inPk_{0.f};

    // configuration (read when the stream is opened)
    std::atomic<int> cfgPerf_{0}, cfgBursts_{2};
    std::atomic<bool> cfgExclusive_{true};
    std::atomic<float> info_[6];

    // recording
    RecAccumulator rec_;
    std::thread recThread_;
    std::atomic<bool> recording_{false}, recRun_{false};
    std::atomic<float> lastLatencyMs_{0.f};

    // audio-thread-only
    int64_t pos_ = 0;
    float mg_ = 1.f;
    float smoothL_[kMaxTracks] = {}, smoothR_[kMaxTracks] = {};
};
#endif
