#ifndef EFFECTS_H
#define EFFECTS_H
// Insert effects. Every effect is stereo, processes one frame at a time and is created / destroyed on the control
// thread only; the audio thread just calls process(). Parameter layout (index -> meaning) per type:
//   EQ       0-4 freq Hz | 5-9 gain dB | 10-14 Q | 15 out dB
//   COMP     thresholdDb, ratio, attackMs, releaseMs, makeupDb, mix(0..1)
//   LIMITER  inputGainDb, ceilingDb, releaseMs
//   GATE     thresholdDb, attackMs, holdMs, releaseMs, rangeDb
//   REVERB   mix(0..1), decaySec, preDelayMs, size(0..1), room(0..3)
//   DELAY    timeMs, feedback, mix, width, hpHz, lpHz, pingPong(0/1)
//   CHORUS   rateHz, depth(0..1), mix(0..1), spread(0..1)
//   FLANGER  rateHz, depth(0..1), feedback(-0.95..0.95), mix(0..1)
//   PHASER   rateHz, depth(0..1), feedback(0..0.9), stages(0=4,1=6,2=8), mix(0..1)
//   DIST     driveDb, tone(0..1), type(0 soft,1 tube,2 hard,3 fold), mix(0..1), outDb
//   FILTER   type(0 LP,1 HP,2 BP,3 notch), cutoffHz, Q, mix(0..1)
//   TREMOLO  rateHz, depth(0..1), shape(0 sine,1 tri,2 square), mode(0 tremolo,1 auto-pan)
//   WIDTH    width(0..2), midDb, sideDb
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <memory>
#include <vector>
#include "ParamEQ.h"
#include "DelayEffect.h"
#include "ReverbEffect.h"
#include "Compressor.h"

constexpr int kMaxFxParams = 16;
constexpr int kMaxSlots = 8;

enum FxTypeId {
    FX_NONE = 0, FX_EQ, FX_COMP, FX_LIMITER, FX_GATE, FX_REVERB, FX_DELAY, FX_CHORUS,
    FX_FLANGER, FX_PHASER, FX_DIST, FX_FILTER, FX_TREMOLO, FX_WIDTH, FX_COUNT
};

class Effect {
public:
    virtual ~Effect() = default;
    virtual void setParams(const float *p) = 0;     // p has kMaxFxParams entries
    virtual void process(float &l, float &r) = 0;
};

namespace fxu {
constexpr float kPi = 3.14159265358979f;
constexpr float kTwoPi = 6.28318530717959f;
inline float clampf(float v, float lo, float hi) { return !(v >= lo) ? lo : (v > hi ? hi : v); }  // NaN -> lo
inline float dbToLin(float db) { return std::pow(10.f, clampf(db, -120.f, 60.f) / 20.f); }
inline float coef(float ms, float sr) { return std::exp(-1.f / (std::max(0.01f, ms) * 0.001f * sr)); }

/** Linear interpolated read `delay` samples behind write index w of a circular buffer. */
inline float readDelay(const std::vector<float> &b, size_t w, float delay) {
    const float cap = (float) b.size();
    float rp = (float) w - std::min(std::max(delay, 1.f), cap - 3.f);
    if (rp < 0.f) rp += cap;
    size_t i0 = (size_t) rp; if (i0 >= b.size()) i0 = 0;
    size_t i1 = i0 + 1; if (i1 >= b.size()) i1 = 0;
    float fr = rp - (float) i0;
    return b[i0] + (b[i1] - b[i0]) * fr;
}
}  // namespace fxu

// ------------------------------------------------------------------------------------------------ EQ
class EqFx : public Effect {
    ParamEQ l_, r_; float out_ = 1.f;
public:
    explicit EqFx(float sr) : l_(sr), r_(sr) {}
    void setParams(const float *p) override {
        for (int i = 0; i < 5; ++i) {
            float g = fxu::clampf(p[5 + i], -24.f, 24.f), q = fxu::clampf(p[10 + i], 0.1f, 18.f);
            l_.set(i, p[i], g, q); r_.set(i, p[i], g, q);
        }
        out_ = fxu::dbToLin(p[15]);
    }
    void process(float &l, float &r) override { l = l_.process(l) * out_; r = r_.process(r) * out_; }
};

// ------------------------------------------------------------------------------------------------ Compressor
class CompFx : public Effect {
    Compressor c_; float mix_ = 1.f;
public:
    explicit CompFx(float sr) { c_.prepare(sr); }
    void setParams(const float *p) override {
        c_.setParameters(fxu::clampf(p[0], -80.f, 0.f), fxu::clampf(p[1], 1.f, 40.f), fxu::clampf(p[2], 0.1f, 300.f),
                         fxu::clampf(p[3], 5.f, 3000.f), fxu::clampf(p[4], 0.f, 36.f));
        mix_ = fxu::clampf(p[5], 0.f, 1.f);
    }
    void process(float &l, float &r) override {
        const float dl = l, dr = r;
        c_.processStereo(l, r);
        l = dl + (l - dl) * mix_; r = dr + (r - dr) * mix_;
    }
};

// ------------------------------------------------------------------------------------------------ Look-ahead limiter
class LimiterFx : public Effect {
    static constexpr int kCap = 1024;
    float sr_, inG_ = 1.f, ceil_ = 0.966f, relC_ = 0.999f, gPrev_ = 1.f;
    int look_;
    std::vector<float> dl_, dr_, avg_, dqV_;
    std::vector<int64_t> dqI_;
    int di_ = 0, head_ = 0, tail_ = 0;
    int64_t n_ = 0;
    double avgSum_;
public:
    explicit LimiterFx(float sr) : sr_(sr), look_(std::min(400, std::max(8, (int) (0.0015f * sr)))),
        dl_(look_, 0.f), dr_(look_, 0.f), avg_(look_, 1.f), dqV_(kCap, 1.f), dqI_(kCap, 0), avgSum_((double) look_) {}
    void setParams(const float *p) override {
        inG_ = fxu::dbToLin(fxu::clampf(p[0], 0.f, 36.f));
        ceil_ = fxu::dbToLin(fxu::clampf(p[1], -24.f, 0.f));
        relC_ = fxu::coef(fxu::clampf(p[2], 5.f, 2000.f), sr_);
    }
    void process(float &l, float &r) override {
        const float il = l * inG_, ir = r * inG_;
        const float pk = std::max(std::fabs(il), std::fabs(ir));
        const float target = pk > ceil_ ? ceil_ / pk : 1.f;
        // sliding window minimum of the wanted gain over the look-ahead window
        while (tail_ > head_ && dqV_[(tail_ - 1) % kCap] >= target) --tail_;
        dqV_[tail_ % kCap] = target; dqI_[tail_ % kCap] = n_; ++tail_;
        while (dqI_[head_ % kCap] < n_ - look_) ++head_;
        const float m = dqV_[head_ % kCap];
        // box-filter the minimum so that gain changes are smooth but still reach the target in time
        const int ai = (int) (n_ % look_);
        avgSum_ += (double) m - (double) avg_[ai]; avg_[ai] = m;
        const float gAvg = (float) (avgSum_ / look_);
        const float g = gAvg < gPrev_ ? gAvg : gPrev_ + (gAvg - gPrev_) * (1.f - relC_);
        gPrev_ = g;
        const float ol = dl_[di_], orr = dr_[di_];
        dl_[di_] = il; dr_[di_] = ir;
        if (++di_ >= look_) di_ = 0;
        ++n_;
        l = fxu::clampf(ol * g, -ceil_, ceil_);
        r = fxu::clampf(orr * g, -ceil_, ceil_);
    }
};

// ------------------------------------------------------------------------------------------------ Noise gate
class GateFx : public Effect {
    float sr_, thr_ = 0.003f, atkC_ = 0.9f, relC_ = 0.999f, range_ = 0.f, env_ = 0.f, envRel_, g_ = 0.f;
    int hold_ = 0, holdCnt_ = 0; bool open_ = false;
public:
    explicit GateFx(float sr) : sr_(sr), envRel_(fxu::coef(10.f, sr)) {}
    void setParams(const float *p) override {
        thr_ = fxu::dbToLin(fxu::clampf(p[0], -90.f, 0.f));
        atkC_ = fxu::coef(fxu::clampf(p[1], 0.05f, 100.f), sr_);
        hold_ = (int) (fxu::clampf(p[2], 0.f, 1000.f) * 0.001f * sr_);
        relC_ = fxu::coef(fxu::clampf(p[3], 1.f, 2000.f), sr_);
        range_ = fxu::dbToLin(fxu::clampf(p[4], -90.f, 0.f));
    }
    void process(float &l, float &r) override {
        const float lvl = std::max(std::fabs(l), std::fabs(r));
        env_ = lvl > env_ ? lvl : env_ * envRel_;
        if (env_ > thr_) { open_ = true; holdCnt_ = hold_; }
        else if (env_ < thr_ * 0.7f) { if (holdCnt_ > 0) --holdCnt_; else open_ = false; }
        const float target = open_ ? 1.f : range_;
        const float c = target > g_ ? atkC_ : relC_;
        g_ = target + (g_ - target) * c;
        l *= g_; r *= g_;
    }
};

// ------------------------------------------------------------------------------------------------ Reverb / Delay wrappers
class ReverbFx : public Effect {
    ReverbEffect r_;
public:
    explicit ReverbFx(float sr) { r_.prepare(sr); }
    void setParams(const float *p) override {
        r_.setParams(fxu::clampf(p[0], 0.f, 1.f), fxu::clampf(p[1], 0.2f, 12.f), fxu::clampf(p[2], 0.f, 250.f),
                     fxu::clampf(p[3], 0.f, 1.f), (int) (p[4] + 0.5f));
    }
    void process(float &l, float &r) override { r_.processStereo(l, r); }
};

class DelayFx : public Effect {
    DelayEffect d_;
public:
    explicit DelayFx(float sr) { d_.prepare(sr); }
    void setParams(const float *p) override {
        d_.setParams(fxu::clampf(p[0], 20.f, 2000.f), p[1], p[2], fxu::clampf(p[3], 0.f, 2.f),
                     fxu::clampf(p[4], 10.f, 2000.f), fxu::clampf(p[5], 500.f, 20000.f), p[6] > 0.5f);
    }
    void process(float &l, float &r) override { d_.process(l, r); }
};

// ------------------------------------------------------------------------------------------------ Chorus
class ChorusFx : public Effect {
    std::vector<float> bl_, br_;
    size_t w_ = 0; float sr_, rate_ = 0.8f, depth_ = 0.5f, mix_ = 0.5f, spread_ = 0.8f, ph_ = 0.f;
public:
    explicit ChorusFx(float sr) : bl_((size_t) (sr * 0.05f) + 8, 0.f), br_(bl_.size(), 0.f), sr_(sr) {}
    void setParams(const float *p) override {
        rate_ = fxu::clampf(p[0], 0.02f, 10.f); depth_ = fxu::clampf(p[1], 0.f, 1.f);
        mix_ = fxu::clampf(p[2], 0.f, 1.f); spread_ = fxu::clampf(p[3], 0.f, 1.f);
    }
    void process(float &l, float &r) override {
        ph_ += rate_ / sr_; if (ph_ >= 1.f) ph_ -= 1.f;
        const float lfoL = std::sin(fxu::kTwoPi * ph_);
        const float lfoR = std::sin(fxu::kTwoPi * (ph_ + 0.5f * spread_));
        const float base = 0.014f * sr_, mod = depth_ * 0.006f * sr_;
        bl_[w_] = l; br_[w_] = r;
        const float wl = fxu::readDelay(bl_, w_, base + mod * lfoL);
        const float wr = fxu::readDelay(br_, w_, base + mod * lfoR);
        if (++w_ >= bl_.size()) w_ = 0;
        l = l * (1.f - mix_) + wl * mix_;
        r = r * (1.f - mix_) + wr * mix_;
    }
};

// ------------------------------------------------------------------------------------------------ Flanger
class FlangerFx : public Effect {
    std::vector<float> bl_, br_;
    size_t w_ = 0; float sr_, rate_ = 0.25f, depth_ = 0.7f, fb_ = 0.5f, mix_ = 0.5f, ph_ = 0.f, fl_ = 0.f, fr_ = 0.f;
public:
    explicit FlangerFx(float sr) : bl_((size_t) (sr * 0.02f) + 8, 0.f), br_(bl_.size(), 0.f), sr_(sr) {}
    void setParams(const float *p) override {
        rate_ = fxu::clampf(p[0], 0.02f, 10.f); depth_ = fxu::clampf(p[1], 0.f, 1.f);
        fb_ = fxu::clampf(p[2], -0.95f, 0.95f); mix_ = fxu::clampf(p[3], 0.f, 1.f);
    }
    void process(float &l, float &r) override {
        ph_ += rate_ / sr_; if (ph_ >= 1.f) ph_ -= 1.f;
        const float lfoL = 0.5f + 0.5f * std::sin(fxu::kTwoPi * ph_);
        const float lfoR = 0.5f + 0.5f * std::sin(fxu::kTwoPi * (ph_ + 0.25f));
        const float dL = (0.0005f + depth_ * 0.0035f * lfoL) * sr_, dR = (0.0005f + depth_ * 0.0035f * lfoR) * sr_;
        bl_[w_] = l + fb_ * fl_; br_[w_] = r + fb_ * fr_;
        const float wl = fxu::readDelay(bl_, w_, dL), wr = fxu::readDelay(br_, w_, dR);
        fl_ = wl; fr_ = wr;
        if (++w_ >= bl_.size()) w_ = 0;
        l = l * (1.f - mix_) + wl * mix_;
        r = r * (1.f - mix_) + wr * mix_;
    }
};

// ------------------------------------------------------------------------------------------------ Phaser
class PhaserFx : public Effect {
    static constexpr int kMaxSt = 8;
    float zL_[kMaxSt] = {}, zR_[kMaxSt] = {};
    float sr_, rate_ = 0.4f, depth_ = 0.7f, fb_ = 0.4f, mix_ = 0.5f, ph_ = 0.f, fbL_ = 0.f, fbR_ = 0.f;
    int stages_ = 4;
    static inline float ap(float x, float a, float &z) { float y = a * x + z; z = x - a * y; return y; }
public:
    explicit PhaserFx(float sr) : sr_(sr) {}
    void setParams(const float *p) override {
        rate_ = fxu::clampf(p[0], 0.02f, 10.f); depth_ = fxu::clampf(p[1], 0.f, 1.f);
        fb_ = fxu::clampf(p[2], 0.f, 0.9f);
        stages_ = p[3] < 0.5f ? 4 : (p[3] < 1.5f ? 6 : 8);
        mix_ = fxu::clampf(p[4], 0.f, 1.f);
    }
    void process(float &l, float &r) override {
        ph_ += rate_ / sr_; if (ph_ >= 1.f) ph_ -= 1.f;
        const float lo = 250.f, hi = lo + depth_ * 3500.f;
        const float lfoL = 0.5f + 0.5f * std::sin(fxu::kTwoPi * ph_), lfoR = 0.5f + 0.5f * std::sin(fxu::kTwoPi * (ph_ + 0.25f));
        const float fL = lo * std::pow(hi / lo, lfoL), fR = lo * std::pow(hi / lo, lfoR);
        const float tL = std::tan(fxu::kPi * std::min(fL, sr_ * 0.45f) / sr_), tR = std::tan(fxu::kPi * std::min(fR, sr_ * 0.45f) / sr_);
        const float aL = (tL - 1.f) / (tL + 1.f), aR = (tR - 1.f) / (tR + 1.f);
        float xl = l + fb_ * fbL_, xr = r + fb_ * fbR_;
        for (int s = 0; s < stages_; ++s) { xl = ap(xl, aL, zL_[s]); xr = ap(xr, aR, zR_[s]); }
        fbL_ = xl; fbR_ = xr;
        l = l * (1.f - mix_) + xl * mix_;
        r = r * (1.f - mix_) + xr * mix_;
    }
};

// ------------------------------------------------------------------------------------------------ Distortion / saturation
class DistFx : public Effect {
    float sr_, drive_ = 4.f, toneA_ = 0.5f, mix_ = 1.f, out_ = 0.5f; int type_ = 0;
    float dcXl_ = 0, dcYl_ = 0, dcXr_ = 0, dcYr_ = 0, lpL_ = 0, lpR_ = 0;
    inline float shape(float x) const {
        switch (type_) {
            case 1: return x >= 0.f ? std::tanh(x) : std::tanh(x * 0.6f) * 1.15f;          // tube-like asymmetry
            case 2: return std::min(1.f, std::max(-1.f, x));                                // hard clip
            case 3: return std::sin(x * 1.2f);                                              // wave-folder
            default: return std::tanh(x);                                                   // soft
        }
    }
public:
    explicit DistFx(float sr) : sr_(sr) {}
    void setParams(const float *p) override {
        drive_ = fxu::dbToLin(fxu::clampf(p[0], 0.f, 48.f));
        const float hz = 800.f * std::pow(20.f, fxu::clampf(p[1], 0.f, 1.f));
        toneA_ = 1.f - std::exp(-fxu::kTwoPi * std::min(hz, sr_ * 0.45f) / sr_);
        type_ = std::min(3, std::max(0, (int) (p[2] + 0.5f)));
        mix_ = fxu::clampf(p[3], 0.f, 1.f);
        out_ = fxu::dbToLin(fxu::clampf(p[4], -36.f, 12.f));
    }
    void process(float &l, float &r) override {
        float wl = shape(l * drive_), wr = shape(r * drive_);
        // DC blocker (asymmetric shapes create an offset)
        float yl = wl - dcXl_ + 0.995f * dcYl_; dcXl_ = wl; dcYl_ = yl;
        float yr = wr - dcXr_ + 0.995f * dcYr_; dcXr_ = wr; dcYr_ = yr;
        lpL_ += toneA_ * (yl - lpL_); lpR_ += toneA_ * (yr - lpR_);
        l = l * (1.f - mix_) + lpL_ * out_ * mix_;
        r = r * (1.f - mix_) + lpR_ * out_ * mix_;
    }
};

// ------------------------------------------------------------------------------------------------ State-variable filter
class FilterFx : public Effect {
    float sr_, g_ = 0.1f, k_ = 1.414f, a1_ = 1.f, a2_ = 0.f, a3_ = 0.f, mix_ = 1.f;
    int type_ = 0;
    float ic1L_ = 0, ic2L_ = 0, ic1R_ = 0, ic2R_ = 0;
    inline float run(float x, float &ic1, float &ic2) const {
        const float v3 = x - ic2, v1 = a1_ * ic1 + a2_ * v3, v2 = ic2 + a2_ * ic1 + a3_ * v3;
        ic1 = 2.f * v1 - ic1; ic2 = 2.f * v2 - ic2;
        const float low = v2, band = v1, high = x - k_ * v1 - v2;
        switch (type_) { case 1: return high; case 2: return band * k_; case 3: return low + high; default: return low; }
    }
public:
    explicit FilterFx(float sr) : sr_(sr) { setup(1000.f, 0.707f); }
    void setup(float fc, float q) {
        fc = fxu::clampf(fc, 20.f, std::min(20000.f, sr_ * 0.45f)); q = fxu::clampf(q, 0.4f, 24.f);
        g_ = std::tan(fxu::kPi * fc / sr_); k_ = 1.f / q;
        a1_ = 1.f / (1.f + g_ * (g_ + k_)); a2_ = g_ * a1_; a3_ = g_ * a2_;
    }
    void setParams(const float *p) override {
        type_ = std::min(3, std::max(0, (int) (p[0] + 0.5f)));
        setup(p[1], p[2]); mix_ = fxu::clampf(p[3], 0.f, 1.f);
    }
    void process(float &l, float &r) override {
        const float wl = run(l, ic1L_, ic2L_), wr = run(r, ic1R_, ic2R_);
        l = l * (1.f - mix_) + wl * mix_; r = r * (1.f - mix_) + wr * mix_;
    }
};

// ------------------------------------------------------------------------------------------------ Tremolo / auto-pan
class TremoloFx : public Effect {
    float sr_, rate_ = 4.f, depth_ = 0.6f, ph_ = 0.f, sq_ = 1.f; int shape_ = 0, mode_ = 0;
    inline float lfo(float ph) {
        switch (shape_) {
            case 1: return 1.f - std::fabs(2.f * ph - 1.f);
            case 2: { float t = ph < 0.5f ? 1.f : 0.f; sq_ += 0.02f * (t - sq_); return sq_; }
            default: return 0.5f + 0.5f * std::sin(fxu::kTwoPi * ph);
        }
    }
public:
    explicit TremoloFx(float sr) : sr_(sr) {}
    void setParams(const float *p) override {
        rate_ = fxu::clampf(p[0], 0.05f, 30.f); depth_ = fxu::clampf(p[1], 0.f, 1.f);
        shape_ = std::min(2, std::max(0, (int) (p[2] + 0.5f))); mode_ = p[3] > 0.5f ? 1 : 0;
    }
    void process(float &l, float &r) override {
        ph_ += rate_ / sr_; if (ph_ >= 1.f) ph_ -= 1.f;
        const float v = lfo(ph_);
        if (mode_ == 0) { const float g = 1.f - depth_ * (1.f - v); l *= g; r *= g; }
        else { l *= 1.f - depth_ * v; r *= 1.f - depth_ * (1.f - v); }
    }
};

// ------------------------------------------------------------------------------------------------ Stereo width (mid/side)
class WidthFx : public Effect {
    float width_ = 1.f, mid_ = 1.f, side_ = 1.f;
public:
    explicit WidthFx(float) {}
    void setParams(const float *p) override {
        width_ = fxu::clampf(p[0], 0.f, 2.f); mid_ = fxu::dbToLin(fxu::clampf(p[1], -24.f, 12.f)); side_ = fxu::dbToLin(fxu::clampf(p[2], -24.f, 12.f));
    }
    void process(float &l, float &r) override {
        const float m = 0.5f * (l + r) * mid_, s = 0.5f * (l - r) * width_ * side_;
        l = m + s; r = m - s;
    }
};

inline std::unique_ptr<Effect> makeEffect(int type, float sr) {
    switch (type) {
        case FX_EQ: return std::make_unique<EqFx>(sr);
        case FX_COMP: return std::make_unique<CompFx>(sr);
        case FX_LIMITER: return std::make_unique<LimiterFx>(sr);
        case FX_GATE: return std::make_unique<GateFx>(sr);
        case FX_REVERB: return std::make_unique<ReverbFx>(sr);
        case FX_DELAY: return std::make_unique<DelayFx>(sr);
        case FX_CHORUS: return std::make_unique<ChorusFx>(sr);
        case FX_FLANGER: return std::make_unique<FlangerFx>(sr);
        case FX_PHASER: return std::make_unique<PhaserFx>(sr);
        case FX_DIST: return std::make_unique<DistFx>(sr);
        case FX_FILTER: return std::make_unique<FilterFx>(sr);
        case FX_TREMOLO: return std::make_unique<TremoloFx>(sr);
        case FX_WIDTH: return std::make_unique<WidthFx>(sr);
        default: return nullptr;
    }
}
#endif
