#include "AudioEngine.h"
#include <algorithm>
#include <chrono>
#include <cmath>

struct AudioEngine::InputCb : public oboe::AudioStreamDataCallback {
    AudioEngine *e = nullptr;
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream *s, void *data, int32_t frames) override {
        e->onInput(s, static_cast<const float *>(data), frames);
        return oboe::DataCallbackResult::Continue;
    }
};

AudioEngine::AudioEngine() {
    for (auto &p : trackPk_) p.store(0.f);
    for (auto &i : info_) i.store(0.f);
}

AudioEngine::~AudioEngine() {
    closeStream();
    stopRecording(0.f);
}

void AudioEngine::setConfig(int perfMode, bool exclusive, int bursts) {
    cfgPerf_.store(std::min(2, std::max(0, perfMode)));
    cfgExclusive_.store(exclusive);
    cfgBursts_.store(std::min(16, std::max(1, bursts)));
}

void AudioEngine::closeLocked() {
    if (stream_) { stream_->stop(); stream_->close(); stream_.reset(); }
    for (auto &i : info_) i.store(0.f);
    rec_reclaim_.releaseAll();  // the stream is closed: no audio callback can still be reading retired objects
}

bool AudioEngine::openStream() {
    std::lock_guard<std::mutex> lock(mutex_);
    closeLocked();
    const int perf = cfgPerf_.load();
    oboe::PerformanceMode pm = perf == 0 ? oboe::PerformanceMode::LowLatency
                              : (perf == 1 ? oboe::PerformanceMode::None : oboe::PerformanceMode::PowerSaving);
    bool exclusive = cfgExclusive_.load();
    oboe::Result res = oboe::Result::ErrorInternal;
    for (int attempt = 0; attempt < 2; ++attempt) {
        oboe::AudioStreamBuilder b;
        b.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(pm)
            ->setSharingMode(exclusive ? oboe::SharingMode::Exclusive : oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(oboe::ChannelCount::Stereo)
            ->setUsage(oboe::Usage::Media)
            ->setDataCallback(shared_from_this())
            ->setErrorCallback(shared_from_this());
        res = b.openStream(stream_);
        if (res == oboe::Result::OK) break;
        stream_.reset();
        exclusive = false;   // some devices refuse exclusive mode: retry shared
    }
    if (res != oboe::Result::OK) return false;
    const int burst = std::max(1, stream_->getFramesPerBurst());
    const int want = burst * cfgBursts_.load();
    const int cap = stream_->getBufferCapacityInFrames();
    stream_->setBufferSizeInFrames(cap > 0 ? std::min(want, cap) : want);
    sampleRate_.store((float) stream_->getSampleRate());
    fx_.setSampleRate((float) stream_->getSampleRate());
    info_[0].store((float) stream_->getSampleRate());
    info_[1].store((float) burst);
    info_[2].store((float) stream_->getBufferSizeInFrames());
    info_[3].store(stream_->getSharingMode() == oboe::SharingMode::Exclusive ? 1.f : 0.f);
    info_[4].store(stream_->getAudioApi() == oboe::AudioApi::AAudio ? 1.f : 2.f);
    info_[5].store(1.f);
    return stream_->requestStart() == oboe::Result::OK;
}

void AudioEngine::closeStream() { std::lock_guard<std::mutex> lock(mutex_); closeLocked(); }

void AudioEngine::streamInfo(float *out, int n) {
    for (int i = 0; i < n && i < 6; ++i) out[i] = info_[i].load();
}

void AudioEngine::onErrorAfterClose(oboe::AudioStream *, oboe::Result error) {
    if (error == oboe::Result::ErrorDisconnected) openStream();
}

void AudioEngine::getMeters(float *out, int n) {
    for (int i = 0; i < kMaxTracks && i < n; ++i) out[i] = trackPk_[i].load(std::memory_order_relaxed);
    if (n > kMaxTracks) out[kMaxTracks] = mPkL_.load(std::memory_order_relaxed);
    if (n > kMaxTracks + 1) out[kMaxTracks + 1] = mPkR_.load(std::memory_order_relaxed);
    if (n > kMaxTracks + 2) out[kMaxTracks + 2] = inPk_.load(std::memory_order_relaxed);
}

static inline float softClip(float x) {
    float a = std::fabs(x);
    if (a <= 0.9f) return x;
    float y = 0.9f + 0.1f * std::tanh((a - 0.9f) * 10.f);
    return x < 0.f ? -y : y;
}

oboe::DataCallbackResult AudioEngine::onAudioReady(oboe::AudioStream *stream, void *data, int32_t numFrames) {
    // REAL-TIME RULES: no allocation, no locks, no I/O, no logging.
    auto *out = static_cast<float *>(data);
    const int ch = stream->getChannelCount();
    const float sr = (float) stream->getSampleRate();
    const float masterT = master_.load(std::memory_order_relaxed);

    int64_t seek = seekReq_.exchange(-1, std::memory_order_acq_rel);
    if (seek >= 0) pos_ = seek;
    const bool isPlaying = playing.load(std::memory_order_relaxed);

    // snapshot everything that is constant for this block
    FxStore::View masterView;
    fx_.collect(0, masterView);
    FxStore::View trackView[kMaxTracks];
    const ClipList *cl[kMaxTracks];
    float tL[kMaxTracks], tR[kMaxTracks], blkPk[kMaxTracks];
    bool anySolo = false;
    for (int t = 0; t < kMaxTracks; ++t) anySolo |= tracks_[t].solo.load(std::memory_order_relaxed);
    double projEnd = 0.0;
    for (int t = 0; t < kMaxTracks; ++t) {
        cl[t] = clips_.clips(t + 1);
        fx_.collect(t + 1, trackView[t]);
        blkPk[t] = 0.f;
        if (cl[t]) projEnd = std::max(projEnd, cl[t]->endSec);
        const bool audible = !tracks_[t].mute.load(std::memory_order_relaxed) &&
                             (!anySolo || tracks_[t].solo.load(std::memory_order_relaxed));
        const float g = audible ? tracks_[t].gain.load(std::memory_order_relaxed) : 0.f;
        const float p = std::min(1.f, std::max(-1.f, tracks_[t].pan.load(std::memory_order_relaxed)));
        const float a = (p + 1.f) * 0.78539816f;  // constant-power pan
        tL[t] = g * std::cos(a) * 1.41421356f;
        tR[t] = g * std::sin(a) * 1.41421356f;
    }
    const int64_t projLen = (int64_t) (projEnd * (double) sr);
    float pkL = 0.f, pkR = 0.f;

    for (int i = 0; i < numFrames; ++i) {
        float mL = 1e-18f, mR = 1e-18f;  // tiny offset avoids denormals in filters
        if (isPlaying && projLen > 0) {
            if (pos_ >= projLen) pos_ = 0;  // loop the whole arrangement
            const double now = (double) pos_ / (double) sr;
            for (int t = 0; t < kMaxTracks; ++t) {
                if (!cl[t]) continue;
                float l = 0.f, r = 0.f;
                mixClips(cl[t], now, l, r);
                if (trackView[t].any) FxStore::run(trackView[t], l, r);
                smoothL_[t] += (tL[t] - smoothL_[t]) * 0.002f;   // de-zipper
                smoothR_[t] += (tR[t] - smoothR_[t]) * 0.002f;
                l *= smoothL_[t]; r *= smoothR_[t];
                blkPk[t] = std::max(blkPk[t], std::max(std::fabs(l), std::fabs(r)));
                mL += l; mR += r;
            }
            ++pos_;
        }
        if (masterView.any) FxStore::run(masterView, mL, mR);
        mg_ += (masterT - mg_) * 0.002f;
        const float oL = softClip(mL * mg_), oR = softClip(mR * mg_);
        pkL = std::max(pkL, std::fabs(oL)); pkR = std::max(pkR, std::fabs(oR));
        out[0] = oL;
        out[1] = oR;
        for (int c = 2; c < ch; ++c) out[c] = 0.f;
        out += ch;
    }
    posOut_.store(pos_, std::memory_order_relaxed);
    for (int t = 0; t < kMaxTracks; ++t) {   // peak with a fast fall-back so the UI never misses short peaks
        const float old = trackPk_[t].load(std::memory_order_relaxed);
        trackPk_[t].store(std::max(blkPk[t], old * 0.9f), std::memory_order_relaxed);
    }
    mPkL_.store(std::max(pkL, mPkL_.load(std::memory_order_relaxed) * 0.9f), std::memory_order_relaxed);
    mPkR_.store(std::max(pkR, mPkR_.load(std::memory_order_relaxed) * 0.9f), std::memory_order_relaxed);
    rec_reclaim_.tick();  // lets the control thread free retired clip lists / effects
    return oboe::DataCallbackResult::Continue;
}

// ------------------------------------------------------------------------------------------------ recording
void AudioEngine::onInput(oboe::AudioStream *s, const float *in, int32_t frames) {
    const int ch = std::max(1, s->getChannelCount());
    float tmp[512 * 2];
    float pk = 0.f;
    int32_t done = 0;
    while (done < frames) {
        const int n = std::min<int32_t>(512, frames - done);
        for (int i = 0; i < n; ++i) {
            const float *f = in + (size_t) (done + i) * ch;
            const float l = f[0], r = ch > 1 ? f[1] : f[0];
            tmp[2 * i] = l; tmp[2 * i + 1] = r;
            pk = std::max(pk, std::max(std::fabs(l), std::fabs(r)));
        }
        rec_.push(tmp, n);
        done += n;
    }
    inPk_.store(std::max(pk, inPk_.load(std::memory_order_relaxed) * 0.9f), std::memory_order_relaxed);
}

float AudioEngine::estimateLatencyMs() {
    double ms = 0.0; bool measured = false;
    if (inStream_ && stream_) {
        auto a = inStream_->calculateLatencyMillis();
        auto b = stream_->calculateLatencyMillis();
        if (a && b) { ms = a.value() + b.value(); measured = true; }
    }
    if (!measured) {   // fall back to the buffer sizes
        if (inStream_) ms += 1000.0 * inStream_->getBufferSizeInFrames() / std::max(1, inStream_->getSampleRate());
        if (stream_) ms += 1000.0 * stream_->getBufferSizeInFrames() / std::max(1, stream_->getSampleRate());
    }
    return (float) std::min(400.0, std::max(0.0, ms));
}

bool AudioEngine::startRecording() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (recording_.load()) return true;
    auto cb = std::make_shared<InputCb>();
    cb->e = this;
    oboe::Result res = oboe::Result::ErrorInternal;
    for (int attempt = 0; attempt < 2; ++attempt) {
        oboe::AudioStreamBuilder b;
        b.setDirection(oboe::Direction::Input)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(oboe::ChannelCount::Mono)
            ->setInputPreset(attempt == 0 ? oboe::InputPreset::Unprocessed : oboe::InputPreset::Generic)
            ->setFormatConversionAllowed(true)
            ->setChannelConversionAllowed(true)
            ->setDataCallback(cb);
        res = b.openStream(inStream_);
        if (res == oboe::Result::OK) break;
        inStream_.reset();
    }
    if (res != oboe::Result::OK) return false;
    inCb_ = cb;
    rec_.begin(inStream_->getSampleRate(), (int64_t) inStream_->getSampleRate() * 300);   // max 5 minutes
    recRun_.store(true);
    recThread_ = std::thread([this] {
        while (recRun_.load()) { rec_.drain(); std::this_thread::sleep_for(std::chrono::milliseconds(4)); }
        rec_.drain();
    });
    recording_.store(true);
    if (inStream_->requestStart() != oboe::Result::OK) {
        recRun_.store(false); recThread_.join(); recording_.store(false);
        inStream_->close(); inStream_.reset(); inCb_.reset();
        return false;
    }
    return true;
}

int AudioEngine::stopRecording(float compensateMs) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!recording_.load()) return 0;
    const float lat = compensateMs >= 0.f ? std::min(400.f, compensateMs) : estimateLatencyMs();
    lastLatencyMs_.store(lat);
    if (inStream_) { inStream_->stop(); inStream_->close(); inStream_.reset(); }
    recRun_.store(false);
    if (recThread_.joinable()) recThread_.join();
    recording_.store(false);
    inCb_.reset();
    inPk_.store(0.f);
    auto s = rec_.finish((int64_t) ((double) lat * 0.001 * rec_.sampleRate()));
    if (!s) return 0;
    return clips_.addSample(std::shared_ptr<const Sample>(std::move(s)));
}
