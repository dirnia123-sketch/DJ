#ifndef RECORDER_H
#define RECORDER_H
// Recording buffer: the audio (input) thread pushes interleaved stereo frames into a lock-free single-producer /
// single-consumer ring; a normal thread drains the ring into a growing buffer (allocation is allowed there).
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <memory>
#include <vector>
#include "ClipMixer.h"   // Sample

class RecAccumulator {
public:
    static constexpr size_t kRingFrames = 1u << 17;   // ~2.7 s at 48 kHz, power of two

    RecAccumulator() : ring_(kRingFrames * 2, 0.f) {}

    /** Control thread, before the input stream starts. */
    void begin(int sampleRate, int64_t maxFrames) {
        sr_ = sampleRate; maxFrames_ = maxFrames;
        data_.clear(); data_.reserve((size_t) sampleRate * 2 * 10);
        head_.store(0, std::memory_order_relaxed); tail_.store(0, std::memory_order_relaxed);
        overruns_.store(0, std::memory_order_relaxed); frames_.store(0, std::memory_order_relaxed);
        full_.store(false, std::memory_order_relaxed);
    }

    /** Audio thread. `frames` of interleaved stereo. Never blocks, never allocates. */
    void push(const float *stereo, int frames) {
        size_t h = head_.load(std::memory_order_relaxed);
        const size_t t = tail_.load(std::memory_order_acquire);
        if (kRingFrames - (h - t) < (size_t) frames) { overruns_.fetch_add(1, std::memory_order_relaxed); return; }
        for (int i = 0; i < frames; ++i) {
            const size_t k = ((h + (size_t) i) & (kRingFrames - 1)) * 2;
            ring_[k] = stereo[2 * i]; ring_[k + 1] = stereo[2 * i + 1];
        }
        head_.store(h + (size_t) frames, std::memory_order_release);
    }

    /** Drain thread. Moves everything currently in the ring to the growing buffer. */
    void drain() {
        const size_t h = head_.load(std::memory_order_acquire);
        size_t t = tail_.load(std::memory_order_relaxed);
        while (t != h) {
            if ((int64_t) (data_.size() / 2) >= maxFrames_) { full_.store(true, std::memory_order_relaxed); t = h; break; }
            const size_t k = (t & (kRingFrames - 1)) * 2;
            data_.push_back(ring_[k]); data_.push_back(ring_[k + 1]);
            ++t;
        }
        tail_.store(t, std::memory_order_release);
        frames_.store((int64_t) (data_.size() / 2), std::memory_order_relaxed);
    }

    /** After the drain thread has stopped. Returns null when nothing was recorded. trimFrames removes latency. */
    std::unique_ptr<Sample> finish(int64_t trimFrames) {
        drain();
        const int64_t total = (int64_t) (data_.size() / 2);
        trimFrames = std::max<int64_t>(0, std::min(trimFrames, total - 1));
        if (total - trimFrames < 16) { data_.clear(); return nullptr; }
        auto s = std::make_unique<Sample>();
        s->sampleRate = sr_; s->frames = total - trimFrames;
        s->data.assign(data_.begin() + trimFrames * 2, data_.end());
        data_.clear(); data_.shrink_to_fit();
        return s;
    }

    float seconds() const { return sr_ > 0 ? (float) ((double) frames_.load(std::memory_order_relaxed) / sr_) : 0.f; }
    bool full() const { return full_.load(std::memory_order_relaxed); }
    int overruns() const { return overruns_.load(std::memory_order_relaxed); }
    int sampleRate() const { return sr_; }

private:
    std::vector<float> ring_, data_;
    std::atomic<size_t> head_{0}, tail_{0};
    std::atomic<int> overruns_{0};
    std::atomic<int64_t> frames_{0};
    std::atomic<bool> full_{false};
    int sr_ = 48000; int64_t maxFrames_ = 0;
};
#endif
