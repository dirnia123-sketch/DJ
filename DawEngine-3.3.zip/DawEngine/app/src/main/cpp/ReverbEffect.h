#ifndef REVERB_EFFECT_H
#define REVERB_EFFECT_H
#include <vector>
#include <cmath>
#include <algorithm>

// Freeverb-style stereo reverb with decay time, pre-delay, size and room types.
class ReverbEffect {
    struct Line { std::vector<float> b; size_t i = 0, len = 8; float base = 8.f, store = 0.f; };
    static constexpr int kComb = 8, kAP = 4;
    Line comb_[2][kComb], ap_[2][kAP];
    std::vector<float> pd_;
    size_t pw_ = 0, pre_ = 0;
    float sr_ = 48000.f, mix_ = 0.2f, fb_ = 0.84f, damp_ = 0.2f;
public:
    void prepare(float sr) {
        static const int ct[kComb] = {1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617};
        static const int apt[kAP] = {556, 441, 341, 225};
        sr_ = sr; float k = sr / 44100.f;
        for (int c = 0; c < 2; ++c) {
            int sp = c ? 23 : 0;
            for (int i = 0; i < kComb; ++i) { Line &L = comb_[c][i]; L.base = (ct[i] + sp) * k; L.b.assign((size_t) (L.base * 1.75f) + 8, 0.f); L.len = (size_t) L.base; L.i = 0; L.store = 0; }
            for (int i = 0; i < kAP; ++i) { Line &L = ap_[c][i]; L.base = (apt[i] + sp) * k; L.b.assign((size_t) (L.base * 1.75f) + 8, 0.f); L.len = (size_t) L.base; L.i = 0; }
        }
        pd_.assign((size_t) (sr * 0.26f) + 4, 0.f); pw_ = 0;
        setParams(0.2f, 2.4f, 20.f, 0.5f, 1);
    }
    // decaySec: RT60; preMs: 0..250; size 0..1; room 0 Room,1 Hall,2 Plate,3 Cathedral
    void setParams(float mix, float decaySec, float preMs, float size, int room) {
        static const float roomSize[4] = {0.7f, 1.0f, 0.85f, 1.35f}, roomDamp[4] = {0.35f, 0.2f, 0.1f, 0.15f};
        room = std::min(3, std::max(0, room));
        mix_ = std::min(1.f, std::max(0.f, mix));
        float sf = std::min(1.7f, std::max(0.4f, (0.6f + size * 0.9f) * roomSize[room]));
        for (int c = 0; c < 2; ++c) {
            for (auto &L : comb_[c]) L.len = std::max<size_t>(8, std::min(L.b.size() - 1, (size_t) (L.base * sf)));
            for (auto &L : ap_[c]) L.len = std::max<size_t>(8, std::min(L.b.size() - 1, (size_t) (L.base * sf)));
        }
        fb_ = std::min(0.985f, std::pow(10.f, -3.f * 0.03f * sf / std::max(0.1f, decaySec)));
        damp_ = roomDamp[room];
        pre_ = std::min(pd_.size() - 1, (size_t) (std::max(0.f, preMs) * 0.001f * sr_));
    }
    inline void processStereo(float &l, float &r) {
        float in = (l + r) * 0.015f;
        pd_[pw_] = in;
        in = pd_[(pw_ + pd_.size() - pre_) % pd_.size()];
        if (++pw_ >= pd_.size()) pw_ = 0;
        float wet[2];
        for (int c = 0; c < 2; ++c) {
            float acc = 0.f;
            for (int i = 0; i < kComb; ++i) {
                Line &L = comb_[c][i];
                float o = L.b[L.i];
                L.store = o * (1.f - damp_) + L.store * damp_;
                L.b[L.i] = in + L.store * fb_;
                if (++L.i >= L.len) L.i = 0;
                acc += o;
            }
            for (int i = 0; i < kAP; ++i) {
                Line &A = ap_[c][i];
                float bo = A.b[A.i], o = -acc + bo;
                A.b[A.i] = acc + bo * 0.5f;
                if (++A.i >= A.len) A.i = 0;
                acc = o;
            }
            wet[c] = acc;
        }
        l = l * (1.f - mix_ * 0.5f) + wet[0] * mix_ * 3.f;
        r = r * (1.f - mix_ * 0.5f) + wet[1] * mix_ * 3.f;
    }
};
#endif
