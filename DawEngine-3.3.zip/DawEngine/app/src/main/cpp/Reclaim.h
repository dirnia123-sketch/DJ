#ifndef RECLAIM_H
#define RECLAIM_H
// Deferred deletion for objects that the audio thread may still be reading (RCU-style, epoch based).
//   audio thread  : tick() once at the end of every callback            (lock-free)
//   control thread: retire(deleter) after unpublishing an object
// An object retired at epoch e can be freed once the audio thread has completed one more callback (epoch >= e + 1).
#include <algorithm>
#include <atomic>
#include <cstdint>
#include <functional>
#include <mutex>
#include <vector>

class Reclaimer {
public:
    ~Reclaimer() { releaseAll(); }
    void tick() { epoch_.store(epoch_.load(std::memory_order_relaxed) + 1, std::memory_order_release); }

    void retire(std::function<void()> del) {
        std::lock_guard<std::mutex> g(m_);
        items_.push_back(Item{std::move(del), epoch_.load(std::memory_order_acquire)});
        reapLocked();
    }
    void reap() { std::lock_guard<std::mutex> g(m_); reapLocked(); }
    /** Only while the audio stream is stopped / closed. */
    void releaseAll() {
        std::vector<Item> tmp;
        { std::lock_guard<std::mutex> g(m_); tmp.swap(items_); }
        for (auto &i : tmp) i.del();
    }
    size_t count() { std::lock_guard<std::mutex> g(m_); return items_.size(); }

private:
    struct Item { std::function<void()> del; uint64_t epoch; };
    void reapLocked() {
        const uint64_t e = epoch_.load(std::memory_order_acquire);
        std::vector<Item> keep;
        for (auto &i : items_) { if (i.epoch + 1 <= e) i.del(); else keep.push_back(std::move(i)); }
        items_.swap(keep);
    }
    std::mutex m_;
    std::vector<Item> items_;
    std::atomic<uint64_t> epoch_{0};
};
#endif
