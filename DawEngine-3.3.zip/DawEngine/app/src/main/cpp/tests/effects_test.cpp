// Host test: g++ -std=c++17 -O1 -pthread -I.. tests/effects_test.cpp -o /tmp/fx_test && /tmp/fx_test
#include "FxChain.h"
#include <cstdio>
#include <random>
#include <thread>

static int fails = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static const float SR = 48000.f;

static std::unique_ptr<Effect> mk(int type, std::initializer_list<float> p) {
    float buf[kMaxFxParams] = {};
    int i = 0; for (float v : p) buf[i++] = v;
    auto e = makeEffect(type, SR); e->setParams(buf); return e;
}
// RMS (dB) of a processed sine, ignoring the first `skip` seconds
static float sineGainDb(Effect &e, float hz, float amp, float secs = 1.5f, float skip = 0.7f) {
    double in = 0, out = 0; int n = (int) (secs * SR), s0 = (int) (skip * SR);
    for (int i = 0; i < n; ++i) {
        float x = amp * std::sin(6.2831853f * hz * i / SR), l = x, r = x;
        e.process(l, r);
        if (!std::isfinite(l) || !std::isfinite(r)) return -999.f;
        if (i >= s0) { in += x * x; out += l * l; }
    }
    return 10.f * std::log10((float) ((out + 1e-20) / (in + 1e-20)));
}

int main() {
    // ---------- every effect: finite and bounded on loud noise, with wild parameters
    std::mt19937 rng(1); std::uniform_real_distribution<float> U(-1.f, 1.f);
    for (int t = FX_EQ; t < FX_COUNT; ++t) {
        for (int round = 0; round < 3; ++round) {
            float p[kMaxFxParams];
            for (int i = 0; i < kMaxFxParams; ++i) p[i] = round == 0 ? 0.f : (round == 1 ? 1000.f * U(rng) : 50.f * U(rng));
            auto e = makeEffect(t, SR); e->setParams(p);
            bool ok = true; float peak = 0;
            for (int i = 0; i < (int) SR; ++i) {
                float l = U(rng), r = U(rng); e->process(l, r);
                if (!std::isfinite(l) || !std::isfinite(r)) { ok = false; break; }
                peak = std::max(peak, std::max(std::fabs(l), std::fabs(r)));
            }
            if (!ok || peak > 1e6f) std::printf("type %d round %d unstable (peak %g)\n", t, round, peak);
            CHECK(ok && peak < 1e6f);
        }
    }

    // ---------- EQ: +12 dB at 1 kHz
    { auto e = mk(FX_EQ, {60,200,1000,5000,12000, 0,0,12,0,0, 1,1,1,1,1, 0});
      float g = sineGainDb(*e, 1000.f, 0.1f); std::printf("EQ +12dB@1k -> %.2f dB\n", g); CHECK(std::fabs(g - 12.f) < 1.5f);
      float g2 = sineGainDb(*e, 100.f, 0.1f); CHECK(std::fabs(g2) < 1.5f); }

    // ---------- compressor reduces a loud sine, mix=0 is transparent
    { auto e = mk(FX_COMP, {-20, 4, 5, 100, 0, 1}); float g = sineGainDb(*e, 440.f, 0.9f); std::printf("COMP -> %.2f dB\n", g); CHECK(g < -8.f && g > -25.f);
      auto d = mk(FX_COMP, {-20, 4, 5, 100, 0, 0}); CHECK(std::fabs(sineGainDb(*d, 440.f, 0.9f)) < 0.01f); }

    // ---------- limiter: hard ceiling
    { auto e = mk(FX_LIMITER, {0, -3, 100}); float ceilv = std::pow(10.f, -3.f / 20.f); float peak = 0; bool ok = true;
      for (int i = 0; i < (int) SR * 2; ++i) { float x = (i % 24000 < 12000 ? 4.f : 0.1f) * std::sin(6.2831853f * 220.f * i / SR), l = x, r = x;
          e->process(l, r); if (!std::isfinite(l)) ok = false; peak = std::max(peak, std::fabs(l)); }
      std::printf("LIMITER peak %.4f (ceiling %.4f)\n", peak, ceilv); CHECK(ok && peak <= ceilv * 1.001f);
      auto q = mk(FX_LIMITER, {0, -3, 100}); CHECK(std::fabs(sineGainDb(*q, 440.f, 0.05f)) < 0.3f); }   // quiet signal untouched

    // ---------- gate
    { auto e = mk(FX_GATE, {-40, 1, 20, 50, -80}); float lo = sineGainDb(*e, 300.f, 0.002f), hi = sineGainDb(*e, 300.f, 0.5f);
      std::printf("GATE quiet %.1f dB, loud %.2f dB\n", lo, hi); CHECK(lo < -30.f); CHECK(std::fabs(hi) < 0.5f); }

    // ---------- filter
    { auto lp = mk(FX_FILTER, {0, 500, 0.707f, 1}); float pass = sineGainDb(*lp, 100.f, 0.3f), stop = sineGainDb(*lp, 5000.f, 0.3f);
      std::printf("LP500: 100Hz %.2f dB, 5k %.2f dB\n", pass, stop); CHECK(std::fabs(pass) < 1.f && stop < -30.f);
      auto hp = mk(FX_FILTER, {1, 500, 0.707f, 1}); CHECK(sineGainDb(*hp, 100.f, 0.3f) < -20.f); CHECK(std::fabs(sineGainDb(*hp, 5000.f, 0.3f)) < 1.f);
      auto bp = mk(FX_FILTER, {2, 1000, 4, 1}); CHECK(sineGainDb(*bp, 1000.f, 0.3f) > -1.5f); CHECK(sineGainDb(*bp, 100.f, 0.3f) < -15.f); }

    // ---------- distortion bounded, hard clip flat-tops
    { auto e = mk(FX_DIST, {24, 1, 2, 1, 0}); float peak = 0;
      for (int i = 0; i < 48000; ++i) { float l = 0.8f * std::sin(0.05f * i), r = l; e->process(l, r); peak = std::max(peak, std::fabs(l)); }
      std::printf("DIST hard peak %.3f\n", peak); CHECK(peak < 1.4f && peak > 0.5f); }

    // ---------- tremolo depth 1 reaches near-silence
    { auto e = mk(FX_TREMOLO, {5, 1, 0, 0}); float mn = 9, mx = 0;
      for (int i = 0; i < (int) SR; ++i) { float l = 1.f, r = 1.f; e->process(l, r); if (i > 100) { mn = std::min(mn, l); mx = std::max(mx, l); } }
      CHECK(mn < 0.02f && mx > 0.98f); }

    // ---------- stereo width
    { auto e = mk(FX_WIDTH, {0, 0, 0}); float l = 0.7f, r = -0.2f; e->process(l, r); CHECK(std::fabs(l - r) < 1e-6f);
      auto n = mk(FX_WIDTH, {1, 0, 0}); l = 0.7f; r = -0.2f; n->process(l, r); CHECK(std::fabs(l - 0.7f) < 1e-5f && std::fabs(r + 0.2f) < 1e-5f); }

    // ---------- modulation / space effects do something and leave a tail
    for (int t : {(int) FX_CHORUS, (int) FX_FLANGER, (int) FX_PHASER, (int) FX_DELAY, (int) FX_REVERB}) {
        auto e = t == FX_CHORUS ? mk(t, {1.f, 0.8f, 0.6f, 0.8f}) : t == FX_FLANGER ? mk(t, {0.5f, 0.8f, 0.5f, 0.6f}) :
                 t == FX_PHASER ? mk(t, {0.5f, 0.8f, 0.5f, 1, 0.6f}) : t == FX_DELAY ? mk(t, {100, 0.5f, 0.5f, 1, 20, 18000, 0}) : mk(t, {0.5f, 2.f, 10, 0.5f, 1});
        double diff = 0; for (int i = 0; i < 48000; ++i) { float x = 0.5f * std::sin(0.03f * i), l = x, r = x; e->process(l, r); diff += std::fabs(l - x); }
        std::printf("fx %d diff %.1f\n", t, diff); CHECK(diff > 10.0);
    }

    // ---------- chain store: set / replace / params / collect + concurrency
    { Reclaimer rec; FxStore st(rec);
      float p[3] = {0, -3, 100};
      CHECK(st.setSlot(0, 0, FX_LIMITER, p, 3, true) && st.setSlot(5, 2, FX_FILTER, nullptr, 0, true));
      CHECK(!st.setSlot(99, 0, FX_EQ, p, 3, true) && !st.setSlot(0, 9, FX_EQ, p, 3, true) && !st.setSlot(0, 0, 99, p, 3, true));
      FxStore::View v; st.collect(0, v); CHECK(v.any && v.fx[0] && !v.fx[1]);
      st.setActive(0, 0, false); st.collect(0, v); CHECK(!v.any);
      st.setActive(0, 0, true);
      st.setSlot(0, 0, FX_NONE, nullptr, 0, true); st.collect(0, v); CHECK(!v.any);
      st.setSampleRate(44100.f);   // rebuild path
      st.collect(5, v); CHECK(v.fx[2] != nullptr);

      std::atomic<bool> stop{false}; std::atomic<long> calls{0};
      std::thread audio([&] { while (!stop) { for (int c = 0; c < 6; ++c) { FxStore::View vv; st.collect(c, vv);
              for (int i = 0; i < 64; ++i) { float l = 0.3f, r = -0.3f; FxStore::run(vv, l, r); if (!std::isfinite(l)) std::abort(); } } rec.tick(); ++calls; } });
      for (int i = 0; i < 4000; ++i) {
          float pp[8] = {5.f * (i % 5), 0.5f, 0.3f, 0.5f, 0, 0, 0, 0};
          st.setSlot(i % 6, i % 8, 1 + (i % (FX_COUNT - 1)), pp, 8, true);
          st.setParams(i % 6, (i + 3) % 8, pp, 8); st.setActive(i % 6, i % 8, (i & 1) != 0);
      }
      stop = true; audio.join(); rec.tick(); rec.tick(); rec.reap();
      std::printf("chain stress: audio callbacks %ld, retired left %zu\n", calls.load(), rec.count()); CHECK(rec.count() <= 1); }

    std::printf(fails ? "FAILED (%d)\n" : "ALL OK\n", fails);
    return fails ? 1 : 0;
}
