// Host test (no Android needed):  g++ -std=c++17 -O2 -pthread -I.. tests/clip_mixer_test.cpp -o /tmp/clip_test && /tmp/clip_test
#include "ClipMixer.h"
#include <cstdio>
#include <thread>

static int fails = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

static std::shared_ptr<Sample> ramp(int frames, int sr, float v) {   // constant value signal
    auto s = std::make_shared<Sample>(); s->frames = frames; s->sampleRate = sr;
    s->data.assign((size_t) frames * 2, v); return s;
}

int main() {
    Reclaimer rec;
    ClipStore st(rec);
    const int sr = 1000;                       // 1 sample = 1 ms keeps the arithmetic obvious
    int a = st.addSample(ramp(1000, sr, 0.5f)); // 1 s
    int b = st.addSample(ramp(1000, sr, 0.25f));
    CHECK(a > 0 && b > 0 && a != b);

    // clip A: starts at 2.0 s, plays 0.5 s ; clip B: starts at 2.25 s (overlap) with 0.1 s trimmed
    int ids[2] = {a, b};
    double p[6] = {2.0, 0.0, 0.5,   2.25, 0.1, 0.5};
    CHECK(st.setClips(1, ids, p, 2));
    const ClipList *cl = st.clips(1);
    CHECK(cl && cl->clips.size() == 2);
    CHECK(std::fabs(cl->endSec - 2.75) < 1e-9);

    float l = 0, r = 0;
    mixClips(cl, 1.9, l, r);   CHECK(l == 0.f && r == 0.f);                      // before the clip
    l = r = 0; mixClips(cl, 2.2, l, r);  CHECK(std::fabs(l - 0.5f) < 1e-4f);     // only A
    l = r = 0; mixClips(cl, 2.3, l, r);  CHECK(std::fabs(l - 0.75f) < 1e-4f);    // A + B overlap
    l = r = 0; mixClips(cl, 2.6, l, r);  CHECK(std::fabs(l - 0.25f) < 1e-4f);    // only B
    l = r = 0; mixClips(cl, 2.8, l, r);  CHECK(l == 0.f);                        // after everything
    l = r = 0; mixClips(cl, 2.0, l, r);  CHECK(l < 0.01f);                       // fade-in at the very first sample
    l = r = 0; mixClips(cl, 2.4999, l, r); CHECK(std::fabs(l - 0.3125f) < 0.005f); // B full (0.25) + A almost faded out (0.5*0.125)

    // len is clamped to what the source really has; trim past the end is dropped
    double q[6] = {0.0, 0.8, 5.0,   0.0, 1.5, 1.0};
    CHECK(st.setClips(2, ids, q, 2));
    CHECK(st.clips(2)->clips.size() == 1);
    CHECK(std::fabs(st.clips(2)->clips[0].lenSec - 0.2) < 1e-9);

    // unknown sample id + empty list
    int bad[1] = {999}; double bp[3] = {0, 0, 1};
    CHECK(st.setClips(3, bad, bp, 1) && st.clips(3)->clips.empty());
    st.clearTrack(1); CHECK(st.clips(1)->clips.empty());
    CHECK(!st.setClips(0, nullptr, nullptr, 0) && !st.setClips(kMaxTracks + 1, nullptr, nullptr, 0));

    // retired snapshots are freed only after the "audio thread" ticks
    size_t before = rec.count();
    CHECK(before >= 1);
    rec.tick(); rec.tick(); rec.reap();
    CHECK(rec.count() == 0);

    // stress: audio thread reads while the control thread republishes constantly (run with -fsanitize=thread/address to be strict)
    std::atomic<bool> stop{false};
    std::atomic<long> reads{0};
    std::thread audio([&] {
        while (!stop.load()) {
            for (int t = 1; t <= 4; ++t) { const ClipList *c = st.clips(t); float x = 0, y = 0; mixClips(c, 0.3, x, y); reads++; }
            rec.tick();
        }
    });
    for (int i = 0; i < 20000; ++i) {
        double pp[3] = {0.0, 0.0, 0.5 + (i % 7) * 0.05};
        int one[1] = {(i & 1) ? a : b};
        st.setClips(1 + (i % 4), one, pp, 1);
    }
    stop = true; audio.join();
    rec.tick(); rec.reap();
    CHECK(rec.count() <= 2);
    std::printf("reads during stress: %ld, retired left: %zu\n", reads.load(), rec.count());
    std::printf(fails ? "FAILED (%d)\n" : "ALL OK\n", fails);
    return fails ? 1 : 0;
}
