// g++ -std=c++17 -O1 -pthread -I.. tests/recorder_test.cpp -o /tmp/rec_test && /tmp/rec_test
#include "Recorder.h"
#include <cstdio>
#include <thread>
static int fails = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
    RecAccumulator r; r.begin(48000, 48000 * 4);
    std::atomic<bool> run{true};
    std::thread drain([&] { while (run) { r.drain(); std::this_thread::sleep_for(std::chrono::milliseconds(2)); } });
    const int total = 48000 * 3, blk = 192;
    float buf[blk * 2];
    for (int done = 0; done < total; done += blk) {
        for (int i = 0; i < blk; ++i) { buf[2*i] = (float) (done + i); buf[2*i+1] = -(float) (done + i); }
        r.push(buf, blk);
        std::this_thread::sleep_for(std::chrono::microseconds(300));   // roughly real time-ish, never overruns the 2.7 s ring
    }
    run = false; drain.join();
    auto s = r.finish(100);
    CHECK(s != nullptr);
    CHECK(s && s->frames == total - 100 - r.overruns() * blk);
    if (s && r.overruns() == 0) {
        CHECK(s->data[0] == 100.f && s->data[1] == -100.f);                       // first kept frame is #100
        CHECK(s->data[2 * (s->frames - 1)] == (float) (total - 1));               // nothing lost / reordered
    }
    std::printf("frames %lld overruns %d seconds-before-finish ok\n", s ? (long long) s->frames : -1, r.overruns());
    // cap
    RecAccumulator c; c.begin(1000, 500); float one[2] = {1, 1};
    for (int i = 0; i < 2000; ++i) { c.push(one, 1); c.drain(); }
    CHECK(c.full()); auto cs = c.finish(0); CHECK(cs && cs->frames == 500);
    std::printf(fails ? "FAILED\n" : "ALL OK\n"); return fails;
}
