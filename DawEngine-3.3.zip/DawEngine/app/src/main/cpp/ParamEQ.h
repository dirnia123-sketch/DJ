#ifndef PARAM_EQ_H
#define PARAM_EQ_H
#include "ParametricEQ.h"   // BiquadFilter
// 5-band EQ: low shelf, 3 peaking bands, high shelf.
class ParamEQ {
    BiquadFilter b_[5];
    float sr_;
public:
    explicit ParamEQ(float sr = 48000.f) : sr_(sr) {}
    void set(int i, float f, float gainDb, float q) {
        f = std::min(std::max(f, 20.f), std::min(20000.f, sr_ * 0.45f));
        q = std::min(std::max(q, 0.1f), 18.f);
        if (i == 0) b_[0].setLowShelf(sr_, f, gainDb);
        else if (i == 4) b_[4].setHighShelf(sr_, f, gainDb);
        else b_[i].setPeaking(sr_, f, gainDb, q);
    }
    inline float process(float s) {
        for (int i = 0; i < 5; ++i) s = b_[i].process(s);
        return s;
    }
};
#endif
