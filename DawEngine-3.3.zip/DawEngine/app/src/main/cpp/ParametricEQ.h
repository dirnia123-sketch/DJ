#ifndef PARAMETRIC_EQ_H
#define PARAMETRIC_EQ_H

#include <cmath>
#include <algorithm>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

class BiquadFilter {
private:
    float a0, a1, a2, b0, b1, b2;
    float x1, x2, y1, y2;

public:
    BiquadFilter() : a0(1), a1(0), a2(0), b0(1), b1(0), b2(0), x1(0), x2(0), y1(0), y2(0) {}

    void setLowShelf(float sampleRate, float cutoffFreq, float gainDb) {
        float A = std::pow(10.0f, gainDb / 40.0f);
        float w0 = 2.0f * M_PI * cutoffFreq / sampleRate;
        float alpha = std::sin(w0) / 2.0f * std::sqrt(2.0f);
        float cosw0 = std::cos(w0);

        b0 = A * ((A + 1) - (A - 1) * cosw0 + 2 * std::sqrt(A) * alpha);
        b1 = 2 * A * ((A - 1) - (A + 1) * cosw0);
        b2 = A * ((A + 1) - (A - 1) * cosw0 - 2 * std::sqrt(A) * alpha);
        a0 = (A + 1) + (A - 1) * cosw0 + 2 * std::sqrt(A) * alpha;
        a1 = -2 * ((A - 1) + (A + 1) * cosw0);
        a2 = (A + 1) + (A - 1) * cosw0 - 2 * std::sqrt(A) * alpha;

        b0 /= a0; b1 /= a0; b2 /= a0; a1 /= a0; a2 /= a0;
    }

    void setPeaking(float sampleRate, float centerFreq, float gainDb, float Q = 1.2f) {
        float A = std::pow(10.0f, gainDb / 40.0f);
        float w0 = 2.0f * M_PI * centerFreq / sampleRate;
        float alpha = std::sin(w0) / (2.0f * Q);
        float cosw0 = std::cos(w0);

        b0 = 1.0f + alpha * A;
        b1 = -2.0f * cosw0;
        b2 = 1.0f - alpha * A;
        a0 = 1.0f + alpha / A;
        a1 = -2.0f * cosw0;
        a2 = 1.0f - alpha / A;

        b0 /= a0; b1 /= a0; b2 /= a0; a1 /= a0; a2 /= a0;
    }

    void setHighShelf(float sampleRate, float cutoffFreq, float gainDb) {
        float A = std::pow(10.0f, gainDb / 40.0f);
        float w0 = 2.0f * M_PI * cutoffFreq / sampleRate;
        float alpha = std::sin(w0) / 2.0f * std::sqrt(2.0f);
        float cosw0 = std::cos(w0);

        b0 = A * ((A + 1) + (A - 1) * cosw0 + 2 * std::sqrt(A) * alpha);
        b1 = -2 * A * ((A - 1) + (A + 1) * cosw0);
        b2 = A * ((A + 1) + (A - 1) * cosw0 - 2 * std::sqrt(A) * alpha);
        a0 = (A + 1) - (A - 1) * cosw0 + 2 * std::sqrt(A) * alpha;
        a1 = 2 * ((A - 1) - (A + 1) * cosw0);
        a2 = (A + 1) - (A - 1) * cosw0 - 2 * std::sqrt(A) * alpha;

        b0 /= a0; b1 /= a0; b2 /= a0; a1 /= a0; a2 /= a0;
    }

    float process(float sample) {
        float out = b0 * sample + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
        x2 = x1; x1 = sample; y2 = y1; y1 = out;
        return out;
    }
};

class ParametricEQ {
private:
    float sampleRate;
    BiquadFilter subFilter;
    BiquadFilter lowFilter;
    BiquadFilter midFilter;
    BiquadFilter highFilter;
    BiquadFilter airFilter;

public:
    ParametricEQ(float sampleRate = 44100.0f) : sampleRate(sampleRate) {
        setGains(0, 0, 0, 0, 0);
    }

    void setGains(float sub, float low, float mid, float high, float air) {
        subFilter.setLowShelf(sampleRate, 60.0f, sub);
        lowFilter.setPeaking(sampleRate, 250.0f, low, 1.0f);
        midFilter.setPeaking(sampleRate, 1200.0f, mid, 1.2f);
        highFilter.setPeaking(sampleRate, 4500.0f, high, 1.0f);
        airFilter.setHighShelf(sampleRate, 10000.0f, air);
    }

    inline float process(float s) {
        s = subFilter.process(s);
        s = lowFilter.process(s);
        s = midFilter.process(s);
        s = highFilter.process(s);
        return airFilter.process(s);
    }

    void processBuffer(float* buffer, size_t numFrames) {
        for (size_t i = 0; i < numFrames; ++i) {
            float sample = buffer[i];
            sample = subFilter.process(sample);
            sample = lowFilter.process(sample);
            sample = midFilter.process(sample);
            sample = highFilter.process(sample);
            sample = airFilter.process(sample);
            buffer[i] = sample;
        }
    }
};

#endif
