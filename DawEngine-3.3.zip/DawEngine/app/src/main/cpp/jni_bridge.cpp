#include <jni.h>
#include <algorithm>
#include <cmath>
#include <vector>
#include "AudioEngine.h"

static std::shared_ptr<AudioEngine> gEngine = std::make_shared<AudioEngine>();
#define FN(name) Java_com_example_daw_NativeEngine_##name

extern "C" {
// ---- stream / transport
JNIEXPORT jboolean JNICALL FN(openStream)(JNIEnv *, jobject) { return gEngine->openStream(); }
JNIEXPORT void JNICALL FN(closeStream)(JNIEnv *, jobject) { gEngine->closeStream(); }
JNIEXPORT void JNICALL FN(setAudioConfig)(JNIEnv *, jobject, jint perf, jboolean exclusive, jint bursts) { gEngine->setConfig(perf, exclusive == JNI_TRUE, bursts); }
JNIEXPORT void JNICALL FN(getStreamInfo)(JNIEnv *env, jobject, jfloatArray out) {
    jsize n = env->GetArrayLength(out); if (n > 6) n = 6;
    float tmp[6] = {}; gEngine->streamInfo(tmp, (int) n);
    env->SetFloatArrayRegion(out, 0, n, tmp);
}
JNIEXPORT void JNICALL FN(startEngine)(JNIEnv *, jobject) { gEngine->playing.store(true); }
JNIEXPORT void JNICALL FN(stopEngine)(JNIEnv *, jobject) { gEngine->playing.store(false); }
JNIEXPORT void JNICALL FN(seek)(JNIEnv *, jobject, jfloat sec) { gEngine->seek(sec); }
JNIEXPORT jfloat JNICALL FN(getPosition)(JNIEnv *, jobject) { return gEngine->position(); }
JNIEXPORT void JNICALL FN(getMeters)(JNIEnv *env, jobject, jfloatArray out) {
    jsize n = env->GetArrayLength(out); if (n > kMeterCount) n = kMeterCount;
    float tmp[kMeterCount] = {}; gEngine->getMeters(tmp, (int) n);
    env->SetFloatArrayRegion(out, 0, n, tmp);
}

// ---- samples & clips
// Copies decoded audio into the engine and returns a sample id (> 0), or 0 on failure.
JNIEXPORT jint JNICALL FN(registerSample)(JNIEnv *env, jobject, jfloatArray arr, jint frames, jint sr) {
    if (frames <= 0 || sr <= 0 || env->GetArrayLength(arr) < frames * 2) return 0;
    auto s = std::make_unique<Sample>();
    s->frames = frames; s->sampleRate = sr;
    s->data.resize((size_t) frames * 2);
    env->GetFloatArrayRegion(arr, 0, frames * 2, s->data.data());
    return gEngine->registerSample(std::move(s));
}
JNIEXPORT void JNICALL FN(releaseSample)(JNIEnv *, jobject, jint sampleId) { gEngine->releaseSample(sampleId); }
JNIEXPORT jint JNICALL FN(sampleFrames)(JNIEnv *, jobject, jint id) { auto s = gEngine->sample(id); return s ? (jint) s->frames : 0; }
JNIEXPORT jint JNICALL FN(sampleRate)(JNIEnv *, jobject, jint id) { auto s = gEngine->sample(id); return s ? (jint) s->sampleRate : 0; }
// Copies the sample (interleaved stereo) into `out`, which must hold at least frames * 2 floats.
JNIEXPORT jboolean JNICALL FN(copySample)(JNIEnv *env, jobject, jint id, jfloatArray out) {
    auto s = gEngine->sample(id);
    if (!s || env->GetArrayLength(out) < (jsize) (s->frames * 2)) return JNI_FALSE;
    env->SetFloatArrayRegion(out, 0, (jsize) (s->frames * 2), s->data.data());
    return JNI_TRUE;
}
// Normalised peak envelope of a sample, `bins` = out.length.
JNIEXPORT void JNICALL FN(samplePeaks)(JNIEnv *env, jobject, jint id, jfloatArray out) {
    auto s = gEngine->sample(id);
    const jsize bins = env->GetArrayLength(out);
    if (!s || bins <= 0) return;
    std::vector<float> pk((size_t) bins, 0.f);
    const int64_t per = std::max<int64_t>(1, s->frames / bins);
    for (int64_t i = 0; i < s->frames; ++i) {
        const int64_t b = std::min<int64_t>(bins - 1, i / per);
        const float v = std::max(std::fabs(s->data[2 * i]), std::fabs(s->data[2 * i + 1]));
        if (v > pk[b]) pk[b] = v;
    }
    float mx = 0.f; for (float v : pk) mx = std::max(mx, v);
    if (mx > 0.f) for (auto &v : pk) v /= mx;
    env->SetFloatArrayRegion(out, 0, bins, pk.data());
}
// Replaces ALL clips of a track. params = {startSec, offsetSec, lenSec} per clip, in the same order as sampleIds.
JNIEXPORT jboolean JNICALL FN(setTrackClips)(JNIEnv *env, jobject, jint id, jintArray ids, jdoubleArray params) {
    const jsize n = env->GetArrayLength(ids);
    if (env->GetArrayLength(params) < n * 3) return JNI_FALSE;
    std::vector<jint> a((size_t) n);
    std::vector<jdouble> p((size_t) n * 3);
    if (n > 0) {
        env->GetIntArrayRegion(ids, 0, n, a.data());
        env->GetDoubleArrayRegion(params, 0, n * 3, p.data());
    }
    return gEngine->setTrackClips(id, a.data(), p.data(), (int) n) ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT void JNICALL FN(clearTrack)(JNIEnv *, jobject, jint id) { gEngine->clearTrack(id); }

// ---- mixer
JNIEXPORT void JNICALL FN(setTrackVolume)(JNIEnv *, jobject, jint id, jfloat v) { if (auto *t = gEngine->track(id)) t->gain.store(v); }
JNIEXPORT void JNICALL FN(setTrackMute)(JNIEnv *, jobject, jint id, jboolean v) { if (auto *t = gEngine->track(id)) t->mute.store(v == JNI_TRUE); }
JNIEXPORT void JNICALL FN(setTrackSolo)(JNIEnv *, jobject, jint id, jboolean v) { if (auto *t = gEngine->track(id)) t->solo.store(v == JNI_TRUE); }
JNIEXPORT void JNICALL FN(setTrackPan)(JNIEnv *, jobject, jint id, jfloat v) { if (auto *t = gEngine->track(id)) t->pan.store(v); }
JNIEXPORT void JNICALL FN(setMasterGain)(JNIEnv *, jobject, jfloat g) { gEngine->setMasterGain(g); }

// ---- insert effects. chain 0 = master, 1..32 = track slot id. type 0 clears the slot.
JNIEXPORT jboolean JNICALL FN(setFx)(JNIEnv *env, jobject, jint chain, jint slot, jint type, jfloatArray params, jboolean active) {
    float p[kMaxFxParams] = {};
    jsize n = params ? env->GetArrayLength(params) : 0; if (n > kMaxFxParams) n = kMaxFxParams;
    if (n > 0) env->GetFloatArrayRegion(params, 0, n, p);
    return gEngine->setFx(chain, slot, type, p, (int) n, active == JNI_TRUE) ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT void JNICALL FN(setFxParams)(JNIEnv *env, jobject, jint chain, jint slot, jfloatArray params) {
    float p[kMaxFxParams] = {};
    jsize n = env->GetArrayLength(params); if (n > kMaxFxParams) n = kMaxFxParams;
    if (n > 0) env->GetFloatArrayRegion(params, 0, n, p);
    gEngine->setFxParams(chain, slot, p, (int) n);
}
JNIEXPORT void JNICALL FN(setFxActive)(JNIEnv *, jobject, jint chain, jint slot, jboolean on) { gEngine->setFxActive(chain, slot, on == JNI_TRUE); }

// ---- recording
JNIEXPORT jboolean JNICALL FN(startRecording)(JNIEnv *, jobject) { return gEngine->startRecording() ? JNI_TRUE : JNI_FALSE; }
JNIEXPORT jint JNICALL FN(stopRecording)(JNIEnv *, jobject, jfloat compensateMs) { return gEngine->stopRecording(compensateMs); }
JNIEXPORT jboolean JNICALL FN(isRecording)(JNIEnv *, jobject) { return gEngine->isRecording() ? JNI_TRUE : JNI_FALSE; }
JNIEXPORT jfloat JNICALL FN(recordingSeconds)(JNIEnv *, jobject) { return gEngine->recordingSeconds(); }
JNIEXPORT jfloat JNICALL FN(lastLatencyMs)(JNIEnv *, jobject) { return gEngine->lastLatencyMs(); }
}
