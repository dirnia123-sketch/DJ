#ifndef DELAY_EFFECT_H
#define DELAY_EFFECT_H
#include <vector>
#include <cmath>
#include <algorithm>

// Stereo delay: ping-pong or parallel, tempo-sync time set from outside, HP/LP filtered feedback.
class DelayEffect {
    std::vector<float> bl_, br_;
    size_t cap_ = 0, w_ = 0;
    float sr_ = 48000.f, tCur_ = 12000.f, tTgt_ = 12000.f;
    float fb_ = 0.4f, mix_ = 0.15f, width_ = 1.f, hpA_ = 0.001f, lpA_ = 0.9f;
    bool ping_ = true;
    float hpL_ = 0, hpR_ = 0, lpL_ = 0, lpR_ = 0;
public:
    void prepare(float sr) {
        sr_ = sr; cap_ = (size_t) (sr * 2.5f) + 4;
        bl_.assign(cap_, 0.f); br_.assign(cap_, 0.f);
        w_ = 0; tCur_ = tTgt_ = 0.25f * sr;
    }
    void setParams(float timeMs, float fb, float mix, float width, float hpHz, float lpHz, bool ping) {
        tTgt_ = std::min(std::max(timeMs * 0.001f * sr_, 32.f), (float) (cap_ - 4));
        fb_ = std::min(std::max(fb, 0.f), 0.95f);
        mix_ = std::min(std::max(mix, 0.f), 1.f);
        width_ = width; ping_ = ping;
        lpHz = std::min(lpHz, sr_ * 0.45f);
        hpA_ = 1.f - std::exp(-6.2831853f * hpHz / sr_);
        lpA_ = 1.f - std::exp(-6.2831853f * lpHz / sr_);
    }
    inline void process(float &l, float &r) {
        tCur_ += (tTgt_ - tCur_) * 0.0005f;
        float rp = (float) w_ - tCur_;
        if (rp < 0.f) rp += (float) cap_;
        size_t i0 = (size_t) rp; if (i0 >= cap_) i0 -= cap_;
        size_t i1 = i0 + 1; if (i1 >= cap_) i1 = 0;
        float fr = rp - (float) i0;
        float dl = bl_[i0] + (bl_[i1] - bl_[i0]) * fr;
        float dr = br_[i0] + (br_[i1] - br_[i0]) * fr;
        hpL_ += hpA_ * (dl - hpL_); float fl = dl - hpL_; lpL_ += lpA_ * (fl - lpL_); fl = lpL_;
        hpR_ += hpA_ * (dr - hpR_); float fR = dr - hpR_; lpR_ += lpA_ * (fR - lpR_); fR = lpR_;
        if (ping_) { float in = 0.5f * (l + r); bl_[w_] = in + fb_ * fR; br_[w_] = fb_ * fl; }
        else { bl_[w_] = l + fb_ * fl; br_[w_] = r + fb_ * fR; }
        if (++w_ >= cap_) w_ = 0;
        float m = 0.5f * (dl + dr), s = 0.5f * (dl - dr) * width_;
        l += (m + s) * mix_; r += (m - s) * mix_;
    }
};
#endif
