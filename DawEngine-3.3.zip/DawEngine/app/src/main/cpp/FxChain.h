#ifndef FX_CHAIN_H
#define FX_CHAIN_H
// Insert-effect chains: chain 0 = master, chains 1..kMaxTracks = one per track, kMaxSlots effects each.
// Effects are created / replaced on the control thread and published with an atomic pointer swap.
#include <atomic>
#include <memory>
#include <mutex>
#include "ClipMixer.h"   // kMaxTracks, Reclaimer
#include "Effects.h"

constexpr int kChains = kMaxTracks + 1;

struct FxSlot {
    std::atomic<Effect *> fx{nullptr};
    std::atomic<bool> active{true};
    std::atomic<bool> dirty{false};
    std::atomic<float> p[kMaxFxParams];
    int type = 0;                       // control side only (guarded by FxStore::m_)
    float cur[kMaxFxParams] = {};       // control side copy, used to rebuild after a sample-rate change
    FxSlot() { for (auto &a : p) a.store(0.f); }
};

class FxStore {
public:
    explicit FxStore(Reclaimer &r) : rec_(r) {}
    ~FxStore() { for (auto &c : chains_) for (auto &s : c) delete s.fx.exchange(nullptr); }
    FxStore(const FxStore &) = delete;
    FxStore &operator=(const FxStore &) = delete;

    /** Rebuilds every effect for a new sample rate. Only while the stream is stopped. */
    void setSampleRate(float sr) {
        std::lock_guard<std::mutex> g(m_);
        if (sr == sr_) return;
        sr_ = sr;
        for (auto &c : chains_) for (auto &s : c) if (s.type != 0) publishLocked(s, s.type, s.cur);
    }

    bool setSlot(int chain, int slot, int type, const float *params, int n, bool active) {
        if (chain < 0 || chain >= kChains || slot < 0 || slot >= kMaxSlots || type < 0 || type >= FX_COUNT) return false;
        float buf[kMaxFxParams] = {};
        for (int i = 0; i < n && i < kMaxFxParams; ++i) buf[i] = params[i];
        std::lock_guard<std::mutex> g(m_);
        FxSlot &s = chains_[chain][slot];
        s.active.store(active, std::memory_order_relaxed);
        publishLocked(s, type, buf);
        return true;
    }

    void setParams(int chain, int slot, const float *params, int n) {
        if (chain < 0 || chain >= kChains || slot < 0 || slot >= kMaxSlots) return;
        std::lock_guard<std::mutex> g(m_);
        FxSlot &s = chains_[chain][slot];
        for (int i = 0; i < n && i < kMaxFxParams; ++i) { s.cur[i] = params[i]; s.p[i].store(params[i], std::memory_order_relaxed); }
        s.dirty.store(true, std::memory_order_release);
    }

    void setActive(int chain, int slot, bool a) {
        if (chain < 0 || chain >= kChains || slot < 0 || slot >= kMaxSlots) return;
        chains_[chain][slot].active.store(a, std::memory_order_relaxed);
    }

    // ---- audio thread ----------------------------------------------------------------------------------
    struct View { Effect *fx[kMaxSlots]; bool any; };
    /** Applies pending parameter changes and returns the active effects of a chain. */
    void collect(int chain, View &v) {
        v.any = false;
        for (int s = 0; s < kMaxSlots; ++s) {
            FxSlot &sl = chains_[chain][s];
            Effect *e = sl.fx.load(std::memory_order_acquire);
            if (e && sl.dirty.exchange(false, std::memory_order_acq_rel)) {
                float tmp[kMaxFxParams];
                for (int i = 0; i < kMaxFxParams; ++i) tmp[i] = sl.p[i].load(std::memory_order_relaxed);
                e->setParams(tmp);
            }
            v.fx[s] = (e && sl.active.load(std::memory_order_relaxed)) ? e : nullptr;
            v.any |= v.fx[s] != nullptr;
        }
    }
    static inline void run(const View &v, float &l, float &r) {
        for (int s = 0; s < kMaxSlots; ++s) if (v.fx[s]) v.fx[s]->process(l, r);
    }

private:
    void publishLocked(FxSlot &s, int type, const float *params) {
        Effect *neu = nullptr;
        if (type != 0) {
            auto e = makeEffect(type, sr_);
            if (e) { e->setParams(params); neu = e.release(); }
        }
        s.type = neu ? type : 0;
        for (int i = 0; i < kMaxFxParams; ++i) { s.cur[i] = params[i]; s.p[i].store(params[i], std::memory_order_relaxed); }
        s.dirty.store(false, std::memory_order_relaxed);
        Effect *old = s.fx.exchange(neu, std::memory_order_acq_rel);
        if (old) rec_.retire([old] { delete old; });
    }

    Reclaimer &rec_;
    std::mutex m_;
    float sr_ = 48000.f;
    FxSlot chains_[kChains][kMaxSlots];
};
#endif
