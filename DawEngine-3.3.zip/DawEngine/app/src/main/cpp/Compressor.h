#ifndef COMPRESSOR_H
#define COMPRESSOR_H
#include <cmath>
#include <algorithm>

// Stereo-linked feed-forward compressor (no per-sample pow/log10 -> exp/log only).
class Compressor {
    float sr = 48000.f, thr = -12.f, ratio = 3.f, atk = 10.f, rel = 120.f, makeup = 1.5f;
    float env = 0.f, ac = 0.f, rc = 0.f;
    void update() {
        ac = std::exp(-1.f / (sr * atk * 0.001f));
        rc = std::exp(-1.f / (sr * rel * 0.001f));
    }
public:
    void prepare(float sampleRate) { sr = sampleRate; env = 0.f; update(); }
    void setParameters(float threshold, float r, float attack, float release, float makeupDb) {
        thr = threshold; ratio = std::max(1.f, r); atk = std::max(0.1f, attack);
        rel = std::max(1.f, release); makeup = makeupDb; update();
    }
    inline void processStereo(float &l, float &r) {
        float in = std::max(std::fabs(l), std::fabs(r));
        float c = in > env ? ac : rc;
        env = c * env + (1.f - c) * in;
        float db = 8.685889f * std::log(std::max(env, 1e-6f));   // 20*log10(x)
        float g = db > thr ? (thr - db) * (1.f - 1.f / ratio) : 0.f;
        float lin = std::exp((g + makeup) * 0.11512925f);        // 10^(x/20)
        l *= lin; r *= lin;
    }
};
#endif
